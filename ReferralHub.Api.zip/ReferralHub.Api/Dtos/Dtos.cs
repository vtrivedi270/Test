using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Dtos;

// ----- Requests -----
public record CreateRequisitionDto(
    string Title, int DepartmentId, int LocationId, string? EmploymentType, short NoOfPositions,
    string? ExperienceRequired, DateOnly HireByDate, string Summary, string Requirements, List<string>? Skills);

public record DecisionDto(string? Comments);
public record RejectDto(string Reason);

/// <summary>The SPFx web part uploads the resume to a SharePoint library first, then sends its details here.</summary>
public record ResumeDto(string FileName, string ContentType, long SizeBytes, string StorageUrl);

public record SubmitReferralDto(
    string CandidateName, string CandidateEmail, string CandidatePhone, decimal TotalExperienceYears,
    string? CurrentCompany, string? NoticePeriod, string? Relationship, string? ReferrerNote, ResumeDto Resume);

public record ScheduleDto(int InterviewerEmployeeId, DateTime ScheduledAt, string? Mode, string? MeetingLink);
public record FeedbackDto(byte Rating, string Recommendation, string Comments);

// ----- Responses -----
public record PositionDto(
    int Id, string Title, string Department, string Location, string EmploymentType, int Openings,
    string? Experience, DateOnly HireBy, string Summary, string Requirements, List<string> Skills, int ReferralCount)
{
    public int DaysLeft => HireBy.DayNumber - Clock.Today.DayNumber;
}

public record ApprovalStepDto(byte StepNo, string Role, string Approver, string Status, DateTime? ActedOn, string? Comments);

public record RequisitionDto(
    int Id, string Title, string Department, string Location, int Positions, string? Experience, DateOnly HireBy,
    string Summary, string Status, string RequestedBy, DateTime CreatedOn, string? RejectionReason,
    List<ApprovalStepDto> Steps);

public record MyReferralDto(int Id, string Candidate, string Position, DateTime ReferredOn, byte StageId, string Outcome)
{
    public string Stage => Stages.Name(StageId);
}

public record PipelineRowDto(
    int Id, string Candidate, string Position, string ReferredBy, DateTime ReferredOn, byte StageId, string Outcome,
    double? AvgRating, DateTime? NextInterviewAt)
{
    public string Stage => Stages.Name(StageId);
}

public record ResumeInfo(string FileName, string Url);
public record FeedbackView(byte Rating, string Recommendation, string Comments, string By, DateTime On);
public record InterviewView(
    int Id, byte Round, int InterviewerId, string Interviewer, DateTime ScheduledAt, string Mode,
    string? MeetingLink, string Status, FeedbackView? Feedback);
public record FinalView(string Role, string Decision, string? By, DateTime? On, string? Comments);
public record TimelineItem(string Type, string By, string? Notes, DateTime On);

public record ReferralDetailDto(
    int Id, string Candidate, string Email, string Phone, decimal ExperienceYears, string? Company,
    string? NoticePeriod, string? Relationship, string? ReferrerNote, int RequisitionId, string Position,
    string ReferredBy, DateTime ReferredOn, byte StageId, string Stage, string Outcome, string? ClosedReason,
    ResumeInfo? Resume, List<InterviewView> Interviews, List<FinalView> FinalApprovals, List<TimelineItem> Timeline);

public record LookupItem(int Id, string Name);
