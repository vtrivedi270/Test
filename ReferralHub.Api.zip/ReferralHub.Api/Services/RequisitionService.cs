using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Job requisition life cycle:
///   manager submits -> step 1 Dept head -> step 2 Div head -> step 3 HR head -> status Open (visible to all employees).
/// Any rejection ends the requisition with a reason.
/// </summary>
public class RequisitionService(AppDbContext db, CurrentUser me, Notifier notify)
{
    static readonly string[] EmploymentTypes = ["FullTime", "PartTime", "Contract"];

    static readonly Expression<Func<JobRequisition, RequisitionDto>> ToDto = j => new RequisitionDto(
        j.RequisitionId, j.Title, j.Department!.Name, j.Location!.Name, j.NoOfPositions, j.ExperienceRequired,
        j.HireByDate, j.Summary, j.Status, j.RequestedBy!.DisplayName, j.CreatedOn, j.RejectionReason,
        j.Approvals.OrderBy(a => a.StepNo)
            .Select(a => new ApprovalStepDto(a.StepNo, a.ApproverRole, a.Approver!.DisplayName, a.Status, a.ActedOn, a.Comments))
            .ToList());

    // ---------- Commands ----------

    public async Task<int> CreateAsync(CreateRequisitionDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Manager, ct);
        var user = await me.GetAsync(ct);

        var title = d.Title?.Trim();
        if (string.IsNullOrEmpty(title)) throw new DomainException("Enter a job title.");
        if (title.Length > 200) throw new DomainException("The job title is too long.");
        if (d.NoOfPositions < 1) throw new DomainException("Number of positions must be at least 1.");
        if (d.HireByDate < Clock.Today) throw new DomainException("The hire-by date cannot be in the past.");
        if (string.IsNullOrWhiteSpace(d.Summary) || string.IsNullOrWhiteSpace(d.Requirements))
            throw new DomainException("Add the role summary and the requirements.");
        var type = d.EmploymentType ?? "FullTime";
        if (!EmploymentTypes.Contains(type)) throw new DomainException("Choose a valid employment type.");

        var dept = await db.Departments.Include(x => x.Division)
                       .FirstOrDefaultAsync(x => x.DepartmentId == d.DepartmentId, ct)
                   ?? throw new DomainException("Choose a valid department.");
        if (!await db.Locations.AnyAsync(x => x.LocationId == d.LocationId, ct))
            throw new DomainException("Choose a valid location.");

        // Approval chain: Dept head of the chosen department, Div head of its division, then the HR head
        var hrHeadId = await db.EmployeeRoles
            .Where(x => x.Role!.Code == Roles.HrHead && x.Employee!.IsActive)
            .Select(x => x.EmployeeId).FirstOrDefaultAsync(ct);
        if (hrHeadId == 0) throw new DomainException("No HR head is set up. Ask an administrator to assign the HR_HEAD role.");

        var now = Clock.Now;
        var req = new JobRequisition
        {
            Title = title, DepartmentId = dept.DepartmentId, LocationId = d.LocationId, EmploymentType = type,
            NoOfPositions = d.NoOfPositions, ExperienceRequired = d.ExperienceRequired?.Trim(), HireByDate = d.HireByDate,
            Summary = d.Summary.Trim(), Requirements = d.Requirements.Trim(), RequestedByEmployeeId = user.EmployeeId,
            Status = ReqStatus.PendingApproval, CreatedOn = now, UpdatedOn = now
        };

        req.Approvals.Add(new RequisitionApproval { StepNo = 1, ApproverRole = Roles.DeptHead, ApproverEmployeeId = dept.DepartmentHeadEmployeeId, Status = StepStatus.Pending });
        req.Approvals.Add(new RequisitionApproval { StepNo = 2, ApproverRole = Roles.DivHead, ApproverEmployeeId = dept.Division!.DivisionHeadEmployeeId, Status = StepStatus.Waiting });
        req.Approvals.Add(new RequisitionApproval { StepNo = 3, ApproverRole = Roles.HrHead, ApproverEmployeeId = hrHeadId, Status = StepStatus.Waiting });

        // Skills: reuse existing rows (case-insensitive), create the rest
        var names = (d.Skills ?? []).Select(s => s.Trim()).Where(s => s.Length > 0 && s.Length <= 80)
            .Distinct(StringComparer.OrdinalIgnoreCase).Take(10).ToList();
        var existing = await db.Skills.Where(s => names.Contains(s.Name)).ToListAsync(ct);
        foreach (var n in names)
        {
            var skill = existing.FirstOrDefault(x => x.Name.Equals(n, StringComparison.OrdinalIgnoreCase)) ?? new Skill { Name = n };
            req.Skills.Add(new JobRequisitionSkill { Skill = skill });
        }

        db.Requisitions.Add(req);
        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.SaveChangesAsync(ct);   // gets RequisitionId
        notify.Queue(dept.DepartmentHeadEmployeeId, $"Approval needed: {title}",
            $"{user.DisplayName} raised a requisition for {title}. Please review and approve.", "Requisition", req.RequisitionId);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return req.RequisitionId;
    }

    public async Task ApproveAsync(int id, string? comments, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var req = await LoadPending(id, ct);
        var step = CurrentStep(req, user);

        step.Status = StepStatus.Approved;
        step.ActedOn = Clock.Now;
        step.Comments = comments?.Trim();

        var next = req.Approvals.Where(a => a.StepNo > step.StepNo).OrderBy(a => a.StepNo).FirstOrDefault();
        if (next != null)
        {
            next.Status = StepStatus.Pending;
            notify.Queue(next.ApproverEmployeeId, $"Approval needed: {req.Title}",
                $"{user.DisplayName} approved the requisition for {req.Title}. It is now waiting for you.", "Requisition", req.RequisitionId);
        }
        else
        {
            // Third approval: the job goes live for every employee
            req.Status = ReqStatus.Open;
            req.PublishedOn = Clock.Now;
            notify.Queue(req.RequestedByEmployeeId, $"Approved: {req.Title}",
                "All three approvals are done. The position is now open for employee referrals.", "Requisition", req.RequisitionId);
        }
        req.UpdatedOn = Clock.Now;
        await db.SaveChangesAsync(ct);
    }

    public async Task RejectAsync(int id, string reason, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(reason)) throw new DomainException("Add a reason so the requester knows what to change.");
        var user = await me.GetAsync(ct);
        var req = await LoadPending(id, ct);
        var step = CurrentStep(req, user);

        step.Status = StepStatus.Rejected;
        step.ActedOn = Clock.Now;
        step.Comments = reason.Trim();
        req.Status = ReqStatus.Rejected;
        req.RejectionReason = reason.Trim();
        req.UpdatedOn = Clock.Now;
        notify.Queue(req.RequestedByEmployeeId, $"Rejected: {req.Title}", $"{user.DisplayName}: {reason.Trim()}", "Requisition", req.RequisitionId);
        await db.SaveChangesAsync(ct);
    }

    async Task<JobRequisition> LoadPending(int id, CancellationToken ct)
    {
        var req = await db.Requisitions.Include(x => x.Approvals).FirstOrDefaultAsync(x => x.RequisitionId == id, ct)
                  ?? throw new NotFoundException("Requisition not found.");
        if (req.Status != ReqStatus.PendingApproval) throw new DomainException("This requisition is not waiting for approval.");
        return req;
    }

    static RequisitionApproval CurrentStep(JobRequisition req, Employee user)
    {
        var step = req.Approvals.OrderBy(a => a.StepNo).FirstOrDefault(a => a.Status == StepStatus.Pending)
                   ?? throw new DomainException("This requisition has no step waiting for approval.");
        if (step.ApproverEmployeeId != user.EmployeeId) throw new ForbiddenException("This step is assigned to someone else.");
        return step;
    }

    // ---------- Queries ----------

    /// <summary>Approved positions that every employee can see and refer candidates for.</summary>
    public async Task<List<PositionDto>> OpenPositionsAsync(string? department, string? q, CancellationToken ct)
    {
        await me.GetAsync(ct);
        var today = Clock.Today;
        var query = db.Requisitions.AsNoTracking()
            .Where(j => j.Status == ReqStatus.Open && j.HireByDate >= today && j.PositionsFilled < j.NoOfPositions);
        if (!string.IsNullOrWhiteSpace(department)) query = query.Where(j => j.Department!.Name == department);
        if (!string.IsNullOrWhiteSpace(q))
            query = query.Where(j => j.Title.Contains(q) || j.Skills.Any(s => s.Skill!.Name.Contains(q)));

        return await query.OrderBy(j => j.HireByDate)
            .Select(j => new PositionDto(
                j.RequisitionId, j.Title, j.Department!.Name, j.Location!.Name, j.EmploymentType,
                j.NoOfPositions - j.PositionsFilled, j.ExperienceRequired, j.HireByDate, j.Summary, j.Requirements,
                j.Skills.Select(s => s.Skill!.Name).ToList(),
                db.Referrals.Count(r => r.RequisitionId == j.RequisitionId)))
            .ToListAsync(ct);
    }

    public async Task<List<RequisitionDto>> MineAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Requisitions.AsNoTracking()
            .Where(j => j.RequestedByEmployeeId == user.EmployeeId)
            .OrderByDescending(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }

    public async Task<List<RequisitionDto>> AllAsync(CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        return await db.Requisitions.AsNoTracking().OrderByDescending(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }

    /// <summary>Requisitions where it is currently my turn to approve.</summary>
    public async Task<List<RequisitionDto>> InboxAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Requisitions.AsNoTracking()
            .Where(j => j.Status == ReqStatus.PendingApproval &&
                        j.Approvals.Any(a => a.ApproverEmployeeId == user.EmployeeId && a.Status == StepStatus.Pending))
            .OrderBy(j => j.CreatedOn).Select(ToDto).ToListAsync(ct);
    }
}
