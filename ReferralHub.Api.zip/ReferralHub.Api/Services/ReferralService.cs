using System.Net.Mail;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;

namespace ReferralHub.Api.Services;

/// <summary>
/// Referral life cycle (stage ids in brackets):
///   Referred [1] -> HR review [2] -> Interview 1 [3] -> Interview 2 [4] -> Interview 3 [5] -> Final approval [6] -> Selected
/// Every interview needs feedback before the next round unlocks. A "Reject" recommendation or an HR close ends the referral.
/// Final approval needs BOTH the Division head and the HR head.
/// Every change also updates Referral.UpdatedOn so the rowversion check stops two people saving over each other.
/// </summary>
public class ReferralService(AppDbContext db, CurrentUser me, Notifier notify)
{
    const long MaxResumeBytes = 5 * 1024 * 1024;
    static readonly string[] ResumeExtensions = [".pdf", ".doc", ".docx"];

    // ---------- Employee: submit and track ----------

    public async Task<int> SubmitAsync(int requisitionId, SubmitReferralDto d, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var req = await db.Requisitions.FirstOrDefaultAsync(x => x.RequisitionId == requisitionId, ct)
                  ?? throw new NotFoundException("Position not found.");
        if (req.Status != ReqStatus.Open || req.HireByDate < Clock.Today || req.PositionsFilled >= req.NoOfPositions)
            throw new DomainException("This position is no longer open for referrals.");

        var name = Text(d.CandidateName, 150, "the candidate's name");
        var email = Text(d.CandidateEmail, 256, "the candidate's email");
        if (!MailAddress.TryCreate(email, out _)) throw new DomainException("Enter a valid email address for the candidate.");
        var phone = Text(d.CandidatePhone, 30, "the candidate's phone number");
        if (d.TotalExperienceYears < 0 || d.TotalExperienceYears > 60) throw new DomainException("Enter the candidate's experience in years.");

        var file = d.Resume ?? throw new DomainException("Attach the candidate's resume.");
        var ext = Path.GetExtension(file.FileName ?? "").ToLowerInvariant();
        if (!ResumeExtensions.Contains(ext)) throw new DomainException("The resume must be a PDF or Word file.");
        if (file.SizeBytes < 1 || file.SizeBytes > MaxResumeBytes) throw new DomainException("The resume must be 5 MB or smaller.");
        if (!Uri.TryCreate(file.StorageUrl, UriKind.Absolute, out var uri) || uri.Scheme != Uri.UriSchemeHttps)
            throw new DomainException("The resume link is not valid. Upload the file again.");

        if (await db.Referrals.AnyAsync(r => r.RequisitionId == requisitionId && r.CandidateEmail == email, ct))
            throw new DomainException("This candidate has already been referred for this position.");

        var now = Clock.Now;
        var referral = new Referral
        {
            RequisitionId = requisitionId, ReferredByEmployeeId = user.EmployeeId,
            CandidateName = name, CandidateEmail = email, CandidatePhone = phone,
            TotalExperienceYears = d.TotalExperienceYears, CurrentCompany = Opt(d.CurrentCompany, 150),
            NoticePeriod = Opt(d.NoticePeriod, 20), Relationship = Opt(d.Relationship, 60), ReferrerNote = Opt(d.ReferrerNote, 1000),
            CurrentStageId = Stages.Referred, Outcome = Outcomes.Active, ReferredOn = now, UpdatedOn = now
        };
        referral.Documents.Add(new ReferralDocument
        {
            FileName = Path.GetFileName(file.FileName!), ContentType = Opt(file.ContentType, 100) ?? "application/octet-stream",
            SizeBytes = file.SizeBytes, StorageUrl = file.StorageUrl, UploadedOn = now
        });
        referral.Activities.Add(new ReferralActivity { ActivityType = "Submitted", ActorEmployeeId = user.EmployeeId, CreatedOn = now });
        db.Referrals.Add(referral);

        await using var tx = await db.Database.BeginTransactionAsync(ct);
        await db.SaveChangesAsync(ct);   // gets ReferralId
        foreach (var hr in await IdsWithRole([Roles.Hr], ct))
            notify.Queue(hr, $"New referral: {name}", $"{user.DisplayName} referred {name} for {req.Title}.", "Referral", referral.ReferralId);
        await db.SaveChangesAsync(ct);
        await tx.CommitAsync(ct);
        return referral.ReferralId;
    }

    /// <summary>What the referring employee sees: status only. Interview feedback stays with HR and the panel.</summary>
    public async Task<List<MyReferralDto>> MineAsync(CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        return await db.Referrals.AsNoTracking()
            .Where(r => r.ReferredByEmployeeId == user.EmployeeId)
            .OrderByDescending(r => r.ReferredOn)
            .Select(r => new MyReferralDto(r.ReferralId, r.CandidateName, r.Requisition!.Title, r.ReferredOn, r.CurrentStageId, r.Outcome))
            .ToListAsync(ct);
    }

    // ---------- HR: pipeline and stage moves ----------

    public async Task<List<PipelineRowDto>> PipelineAsync(byte? stage, string? outcome, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var q = db.Referrals.AsNoTracking().AsQueryable();
        if (stage.HasValue) q = q.Where(r => r.CurrentStageId == stage.Value);
        if (!string.IsNullOrWhiteSpace(outcome)) q = q.Where(r => r.Outcome == outcome);
        return await ProjectRows(q).ToListAsync(ct);
    }

    /// <summary>Candidates waiting for a final decision from me (Division head and/or HR head).</summary>
    public async Task<List<PipelineRowDto>> HiringInboxAsync(CancellationToken ct)
    {
        var roles = (await me.RolesAsync(ct)).Where(r => r is Roles.DivHead or Roles.HrHead).ToList();
        if (roles.Count == 0) throw new ForbiddenException("Only the division head or HR head can see final approvals.");
        var q = db.Referrals.AsNoTracking()
            .Where(r => r.Outcome == Outcomes.Active && r.CurrentStageId == Stages.FinalApproval
                        && r.FinalApprovals.Any(f => f.Decision == Decisions.Pending && roles.Contains(f.ApproverRole)));
        return await ProjectRows(q).ToListAsync(ct);
    }

    static IQueryable<PipelineRowDto> ProjectRows(IQueryable<Referral> q) => q
        .OrderByDescending(r => r.UpdatedOn)
        .Select(r => new PipelineRowDto(
            r.ReferralId, r.CandidateName, r.Requisition!.Title, r.ReferredBy!.DisplayName, r.ReferredOn,
            r.CurrentStageId, r.Outcome,
            r.Interviews.SelectMany(i => i.Feedback).Select(f => (double?)f.Rating).Average(),
            r.Interviews.Where(i => i.Status == InterviewStatuses.Scheduled).Select(i => (DateTime?)i.ScheduledAt).Min()));

    /// <summary>HR marks the first call as done: Referred -> HR review.</summary>
    public async Task ContactAsync(int id, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        if (r.CurrentStageId != Stages.Referred) throw new DomainException("This candidate has already been contacted.");
        r.CurrentStageId = Stages.HrReview;
        r.AssignedHrEmployeeId = user.EmployeeId;
        Touch(r, "Contacted", user, null);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>HR review -> Interview 1 (ready to schedule).</summary>
    public async Task ShortlistAsync(int id, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        if (r.CurrentStageId != Stages.HrReview) throw new DomainException("Mark the candidate as contacted before shortlisting.");
        r.CurrentStageId = Stages.Interview1;
        Touch(r, "Shortlisted", user, null);
        notify.Queue(r.ReferredByEmployeeId, $"{r.CandidateName} is shortlisted", $"HR shortlisted {r.CandidateName} for {r.Requisition!.Title}.", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    /// <summary>HR closes the referral at any active stage.</summary>
    public async Task CloseAsync(int id, string reason, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        if (string.IsNullOrWhiteSpace(reason)) throw new DomainException("Add a reason for closing this referral.");
        var user = await me.GetAsync(ct);
        var r = await LoadActive(id, ct);
        r.Outcome = Outcomes.Rejected;
        r.ClosedReason = reason.Trim();
        Touch(r, "Closed", user, reason.Trim());
        notify.Queue(r.ReferredByEmployeeId, $"Update on {r.CandidateName}", $"The referral for {r.Requisition!.Title} is closed.", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    // ---------- Interviews ----------

    /// <summary>Schedule (or reschedule) round 1, 2 or 3. A round only unlocks after the previous round has feedback.</summary>
    public async Task<int> ScheduleAsync(int id, int round, ScheduleDto d, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var user = await me.GetAsync(ct);
        if (round is < 1 or > 3) throw new DomainException("Interview round must be 1, 2 or 3.");
        var r = await LoadActive(id, ct, withInterviews: true);
        if (r.CurrentStageId != Stages.ForRound(round))
            throw new DomainException($"Interview {round} cannot be scheduled yet.");
        if (d.ScheduledAt <= Clock.Now) throw new DomainException("Pick a date and time in the future.");
        if (!await db.Employees.AnyAsync(e => e.EmployeeId == d.InterviewerEmployeeId && e.IsActive, ct))
            throw new DomainException("Choose a valid interviewer.");

        var iv = r.Interviews.FirstOrDefault(x => x.RoundNo == round);
        if (iv == null)
        {
            iv = new Interview { RoundNo = (byte)round, ScheduledByEmployeeId = user.EmployeeId, CreatedOn = Clock.Now };
            r.Interviews.Add(iv);
        }
        else if (iv.Status == InterviewStatuses.Completed) throw new DomainException("This interview is already completed.");

        iv.InterviewerEmployeeId = d.InterviewerEmployeeId;
        iv.ScheduledAt = d.ScheduledAt;
        iv.Mode = d.Mode == "OnSite" ? "OnSite" : "Online";
        iv.MeetingLink = Opt(d.MeetingLink, 500);
        iv.Status = InterviewStatuses.Scheduled;

        Touch(r, "InterviewScheduled", user, $"Interview {round}");
        notify.Queue(d.InterviewerEmployeeId, $"Interview {round}: {r.CandidateName}",
            $"You are interviewing {r.CandidateName} for {r.Requisition!.Title} on {d.ScheduledAt:dd MMM yyyy HH:mm} UTC.", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
        return iv.InterviewId;
    }

    /// <summary>
    /// Feedback closes the round. Proceed unlocks the next round (or final approval after round 3).
    /// Reject ends the referral. Allowed for the interviewer or HR.
    /// </summary>
    public async Task SubmitFeedbackAsync(int interviewId, FeedbackDto d, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var iv = await db.Interviews.Include(x => x.Feedback)
                     .Include(x => x.Referral).ThenInclude(r => r!.Requisition)
                     .FirstOrDefaultAsync(x => x.InterviewId == interviewId, ct)
                 ?? throw new NotFoundException("Interview not found.");
        var r = iv.Referral!;

        var isHr = await me.HasAsync(Roles.Hr, ct);
        if (iv.InterviewerEmployeeId != user.EmployeeId && !isHr)
            throw new ForbiddenException("Only the interviewer or HR can submit feedback.");
        if (r.Outcome != Outcomes.Active) throw new DomainException("This referral is already closed.");
        if (iv.Status != InterviewStatuses.Scheduled) throw new DomainException("Feedback was already submitted for this interview.");
        if (r.CurrentStageId != Stages.ForRound(iv.RoundNo)) throw new DomainException("This round is not the current interview.");

        if (d.Rating < 1 || d.Rating > 5) throw new DomainException("Rating must be between 1 and 5.");
        if (d.Recommendation is not ("Proceed" or "Reject")) throw new DomainException("Choose Proceed or Reject.");
        var comments = Text(d.Comments, 2000, "your feedback");

        iv.Feedback.Add(new InterviewFeedback
        {
            SubmittedByEmployeeId = user.EmployeeId, Rating = d.Rating, Recommendation = d.Recommendation,
            Comments = comments, SubmittedOn = Clock.Now
        });
        iv.Status = InterviewStatuses.Completed;

        var round = iv.RoundNo;
        if (d.Recommendation == "Reject")
        {
            r.Outcome = Outcomes.Rejected;
            r.ClosedReason = $"Not moving forward after interview {round}";
        }
        else if (round < 3)
        {
            r.CurrentStageId = Stages.ForRound(round + 1);    // next round is now ready to schedule
        }
        else
        {
            // All three rounds done: open the final approval for Division head and HR head
            r.CurrentStageId = Stages.FinalApproval;
            r.FinalApprovals.Add(new FinalApproval { ApproverRole = Roles.DivHead });
            r.FinalApprovals.Add(new FinalApproval { ApproverRole = Roles.HrHead });
            foreach (var head in await IdsWithRole([Roles.DivHead, Roles.HrHead], ct))
                notify.Queue(head, $"Final approval: {r.CandidateName}", $"{r.CandidateName} finished all three interviews for {r.Requisition!.Title}.", "Referral", r.ReferralId);
        }

        Touch(r, "FeedbackSubmitted", user, $"Interview {round}: {d.Recommendation}");
        if (!isHr && r.AssignedHrEmployeeId.HasValue)
            notify.Queue(r.AssignedHrEmployeeId.Value, $"Feedback added: {r.CandidateName}", $"Interview {round}: {d.Recommendation}.", "Referral", r.ReferralId);
        await db.SaveChangesAsync(ct);
    }

    // ---------- Final approval ----------

    /// <summary>
    /// The division head and the HR head each record a decision. One rejection closes the referral.
    /// When both approve, the candidate is Selected and the requisition's filled count goes up.
    /// If one person holds both roles, both rows are recorded with one click.
    /// </summary>
    public async Task FinalDecisionAsync(int id, bool approve, string? comments, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var myRoles = (await me.RolesAsync(ct)).Where(x => x is Roles.DivHead or Roles.HrHead).ToList();
        if (myRoles.Count == 0) throw new ForbiddenException("Only the division head or HR head can give final approval.");

        var r = await db.Referrals.Include(x => x.FinalApprovals).Include(x => x.Requisition)
                    .FirstOrDefaultAsync(x => x.ReferralId == id, ct)
                ?? throw new NotFoundException("Referral not found.");
        if (r.Outcome != Outcomes.Active || r.CurrentStageId != Stages.FinalApproval)
            throw new DomainException("This candidate is not waiting for final approval.");

        var mine = r.FinalApprovals.Where(f => f.Decision == Decisions.Pending && myRoles.Contains(f.ApproverRole)).ToList();
        if (mine.Count == 0) throw new DomainException("You have already recorded your decision.");
        if (!approve && string.IsNullOrWhiteSpace(comments)) throw new DomainException("Add a reason when you reject.");

        foreach (var f in mine)
        {
            f.Decision = approve ? Decisions.Approved : Decisions.Rejected;
            f.DecidedByEmployeeId = user.EmployeeId;
            f.DecidedOn = Clock.Now;
            f.Comments = comments?.Trim();
        }

        if (!approve)
        {
            r.Outcome = Outcomes.Rejected;
            r.ClosedReason = $"Not approved at final stage: {comments!.Trim()}";
            Touch(r, "FinalRejected", user, comments.Trim());
            notify.Queue(r.ReferredByEmployeeId, $"Update on {r.CandidateName}", $"The referral for {r.Requisition!.Title} is closed.", "Referral", r.ReferralId);
        }
        else if (r.FinalApprovals.All(f => f.Decision == Decisions.Approved))
        {
            r.Outcome = Outcomes.Selected;
            var req = r.Requisition!;
            req.PositionsFilled++;
            if (req.PositionsFilled >= req.NoOfPositions) req.Status = ReqStatus.Filled;
            req.UpdatedOn = Clock.Now;
            Touch(r, "Selected", user, null);
            notify.Queue(r.ReferredByEmployeeId, $"{r.CandidateName} is selected", $"{r.CandidateName} was approved for {req.Title}. Thank you for the referral.", "Referral", r.ReferralId);
            foreach (var hr in await IdsWithRole([Roles.Hr], ct))
                notify.Queue(hr, $"Selected: {r.CandidateName}", $"Both approvals are in. Proceed with the offer for {req.Title}.", "Referral", r.ReferralId);
        }
        else
        {
            Touch(r, "FinalApproved", user, null);   // waiting for the other head
        }
        await db.SaveChangesAsync(ct);
    }

    // ---------- Detail ----------

    /// <summary>Full detail with interview feedback: HR, Division head, HR head, or an interviewer on this referral.</summary>
    public async Task<ReferralDetailDto> GetAsync(int id, CancellationToken ct)
    {
        var user = await me.GetAsync(ct);
        var r = await db.Referrals.AsNoTracking().AsSplitQuery()
                    .Include(x => x.Requisition).Include(x => x.ReferredBy).Include(x => x.Documents)
                    .Include(x => x.Interviews).ThenInclude(i => i.Interviewer)
                    .Include(x => x.Interviews).ThenInclude(i => i.Feedback).ThenInclude(f => f.SubmittedBy)
                    .Include(x => x.FinalApprovals).ThenInclude(f => f.DecidedBy)
                    .Include(x => x.Activities).ThenInclude(a => a.Actor)
                    .FirstOrDefaultAsync(x => x.ReferralId == id, ct)
                ?? throw new NotFoundException("Referral not found.");

        var roles = await me.RolesAsync(ct);
        var allowed = roles.Any(x => x is Roles.Hr or Roles.DivHead or Roles.HrHead)
                      || r.Interviews.Any(i => i.InterviewerEmployeeId == user.EmployeeId);
        if (!allowed) throw new ForbiddenException("You do not have access to this candidate.");

        var doc = r.Documents.OrderByDescending(x => x.UploadedOn).FirstOrDefault();
        return new ReferralDetailDto(
            r.ReferralId, r.CandidateName, r.CandidateEmail, r.CandidatePhone, r.TotalExperienceYears, r.CurrentCompany,
            r.NoticePeriod, r.Relationship, r.ReferrerNote, r.RequisitionId, r.Requisition!.Title,
            r.ReferredBy!.DisplayName, r.ReferredOn, r.CurrentStageId, Stages.Name(r.CurrentStageId), r.Outcome, r.ClosedReason,
            doc == null ? null : new ResumeInfo(doc.FileName, doc.StorageUrl),
            r.Interviews.OrderBy(i => i.RoundNo).Select(i =>
            {
                var f = i.Feedback.FirstOrDefault();
                return new InterviewView(i.InterviewId, i.RoundNo, i.InterviewerEmployeeId, i.Interviewer!.DisplayName,
                    i.ScheduledAt, i.Mode, i.MeetingLink, i.Status,
                    f == null ? null : new FeedbackView(f.Rating, f.Recommendation, f.Comments, f.SubmittedBy!.DisplayName, f.SubmittedOn));
            }).ToList(),
            r.FinalApprovals.OrderBy(f => f.ApproverRole).Select(f => new FinalView(f.ApproverRole, f.Decision, f.DecidedBy?.DisplayName, f.DecidedOn, f.Comments)).ToList(),
            r.Activities.OrderBy(a => a.CreatedOn).Select(a => new TimelineItem(a.ActivityType, a.Actor!.DisplayName, a.Notes, a.CreatedOn)).ToList());
    }

    // ---------- Helpers ----------

    async Task<Referral> LoadActive(int id, CancellationToken ct, bool withInterviews = false)
    {
        IQueryable<Referral> q = db.Referrals.Include(x => x.Requisition);
        if (withInterviews) q = q.Include(x => x.Interviews);
        var r = await q.FirstOrDefaultAsync(x => x.ReferralId == id, ct) ?? throw new NotFoundException("Referral not found.");
        if (r.Outcome != Outcomes.Active) throw new DomainException("This referral is already closed.");
        return r;
    }

    void Touch(Referral r, string type, Employee actor, string? notes)
    {
        r.UpdatedOn = Clock.Now;   // also bumps the rowversion, which guards against concurrent changes
        r.Activities.Add(new ReferralActivity { ActivityType = type, ActorEmployeeId = actor.EmployeeId, Notes = notes, CreatedOn = r.UpdatedOn });
    }

    Task<List<int>> IdsWithRole(string[] codes, CancellationToken ct) =>
        db.EmployeeRoles.Where(x => codes.Contains(x.Role!.Code) && x.Employee!.IsActive)
            .Select(x => x.EmployeeId).Distinct().ToListAsync(ct);

    static string Text(string? s, int max, string what)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) throw new DomainException($"Enter {what}.");
        if (v.Length > max) throw new DomainException($"{what} is too long (maximum {max} characters).");
        return v;
    }

    static string? Opt(string? s, int max)
    {
        var v = s?.Trim();
        if (string.IsNullOrEmpty(v)) return null;
        return v.Length > max ? v[..max] : v;
    }
}
