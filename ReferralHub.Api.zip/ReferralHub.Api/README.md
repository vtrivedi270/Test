# Referral Hub API (.NET 8, EF Core, SQL Server)

Backend for the SPFx (React) referral portal. Not compiled in the authoring environment: run `dotnet build` first and fix any typos.

## Run it
1. Run `ReferralHub_schema.sql` on SQL Server (creates database `ReferralHub`, schema `rp`).
2. Run the seed script below with your own emails (first users and roles).
3. Edit `appsettings.json`: connection string, `AzureAd` values, `Cors:Origins` (your SharePoint tenant URL).
4. `dotnet run` then open `/swagger` (Development only).

## Entra ID setup (once)
- Register an app for the API. Under **Expose an API** set the Application ID URI (`api://<client-id>`) and add the scope `access_as_user`.
- In the SPFx solution, `config/package-solution.json`:
  `"webApiPermissionRequests": [{ "resource": "<API app name>", "scope": "access_as_user" }]`
  then approve it in SharePoint admin center > Advanced > API access.
- In the web part, call the API with `AadHttpClient` using the API's Application ID URI as the resource.

## How a request is handled
Token (Entra ID) -> `CurrentUser` finds the row in `rp.Employee` by UPN -> roles come from `rp.EmployeeRole` -> service checks the role and the stage -> one `SaveChanges` (one transaction) writes the change, the timeline entry and the notification.

## Endpoints
| Who | Method and route | What it does |
|---|---|---|
| Everyone | GET `/api/me` | Name and roles (drives which screens the web part shows) |
| Everyone | GET `/api/lookups` | Departments and locations |
| Everyone | GET `/api/positions?department=&q=` | Approved, open positions |
| Everyone | POST `/api/positions/{id}/referrals` | Submit a referral (candidate details + resume link) |
| Everyone | GET `/api/referrals/mine` | My referrals, status only |
| Manager | POST `/api/requisitions` | Raise a requisition (starts the 3-step approval) |
| Manager | GET `/api/requisitions/mine` | My requisitions with approval steps |
| Approver | GET `/api/approvals/requisitions` | Requisitions waiting for me |
| Approver | POST `/api/requisitions/{id}/approve` or `/reject` | Approve, or reject with a reason |
| HR | GET `/api/requisitions` | All requisitions |
| HR | GET `/api/referrals?stage=&outcome=` | Candidate pipeline |
| HR, heads, interviewers | GET `/api/referrals/{id}` | Detail with feedback and timeline |
| HR | POST `/api/referrals/{id}/contact` | Referred -> HR review |
| HR | POST `/api/referrals/{id}/shortlist` | HR review -> Interview 1 |
| HR | POST `/api/referrals/{id}/close` | Close with a reason |
| HR | PUT `/api/referrals/{id}/interviews/{round}` | Schedule or reschedule round 1, 2 or 3 |
| Interviewer, HR | POST `/api/interviews/{id}/feedback` | Rating, Proceed or Reject, comments |
| Div head, HR head | GET `/api/approvals/hiring` | Candidates waiting for my final decision |
| Div head, HR head | POST `/api/referrals/{id}/final-approval/approve` or `/reject` | Final decision |
| HR | GET `/api/employees?q=` | Interviewer picker |

## Rules the services enforce
- Requisition: Dept head -> Div head -> HR head, in order. The third approval sets status `Open`. Any rejection needs a reason and ends it.
- Referral only for `Open` positions that are before the hire-by date and not filled. The same candidate email cannot be referred twice for one job.
- Interview round N can be scheduled only when the referral is at stage N + 2, so round 2 unlocks after round 1 feedback.
- Feedback `Reject` closes the referral. `Proceed` opens the next round, and after round 3 opens final approval.
- Final approval needs both the Division head and the HR head. One rejection closes it. Two approvals set `Selected` and add 1 to `PositionsFilled` (the requisition becomes `Filled` at the limit).
- `Referral.UpdatedOn` and `JobRequisition.UpdatedOn` change on every action, so the `rowversion` check returns HTTP 409 if two people act at the same moment.

## Seed script (edit the emails)
```sql
USE ReferralHub;
INSERT rp.Employee(Email, DisplayName, JobTitle) VALUES
 ('mahesh@yourtenant.com','Mahesh Vaghela','Department Head'),
 ('kavita@yourtenant.com','Kavita Rao','Division Head'),
 ('suresh@yourtenant.com','Suresh Iyer','HR Head'),
 ('neha@yourtenant.com','Neha Trivedi','HR Manager'),
 ('sanjay@yourtenant.com','Sanjay Bhatt','Engineering Manager'),
 ('riya@yourtenant.com','Riya Desai','Software Engineer');

INSERT rp.Division(Name, DivisionHeadEmployeeId)
 SELECT 'Technology', EmployeeId FROM rp.Employee WHERE Email='kavita@yourtenant.com';
INSERT rp.Department(DivisionId, Name, DepartmentHeadEmployeeId)
 SELECT d.DivisionId, 'Engineering', e.EmployeeId
 FROM rp.Division d CROSS JOIN rp.Employee e WHERE d.Name='Technology' AND e.Email='mahesh@yourtenant.com';
UPDATE rp.Employee SET DepartmentId = (SELECT DepartmentId FROM rp.Department WHERE Name='Engineering');

INSERT rp.EmployeeRole(EmployeeId, RoleId)
 SELECT e.EmployeeId, r.RoleId
 FROM (VALUES
   ('mahesh@yourtenant.com','DEPT_HEAD'),('kavita@yourtenant.com','DIV_HEAD'),('suresh@yourtenant.com','HR_HEAD'),
   ('neha@yourtenant.com','HR'),('sanjay@yourtenant.com','MANAGER')) v(Email, Code)
 JOIN rp.Employee e ON e.Email = v.Email JOIN rp.AppRole r ON r.Code = v.Code;
-- everyone is also an employee
INSERT rp.EmployeeRole(EmployeeId, RoleId)
 SELECT EmployeeId, (SELECT RoleId FROM rp.AppRole WHERE Code='EMPLOYEE') FROM rp.Employee;
```

## Next steps
- A background worker (or a Power Automate flow) that sends `rp.Notification` rows with status `Queued` by email or Teams, then marks them `Sent`.
- Resume upload from the web part to a SharePoint library, then send the file URL to the referral endpoint.
- Unit tests for the stage rules in `ReferralService`.
