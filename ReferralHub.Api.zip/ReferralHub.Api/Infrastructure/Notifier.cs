using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Infrastructure;

/// <summary>
/// Adds a row to rp.Notification in the same SaveChanges as the business change (outbox pattern).
/// A background worker or Power Automate flow picks up 'Queued' rows and sends the email or Teams message.
/// </summary>
public class Notifier(AppDbContext db)
{
    public void Queue(int recipientEmployeeId, string subject, string body, string? entity = null, int? id = null)
        => db.Notifications.Add(new Notification
        {
            RecipientEmployeeId = recipientEmployeeId,
            Subject = subject.Length > 200 ? subject[..200] : subject,
            Body = body,
            RelatedEntity = entity,
            RelatedId = id,
            CreatedOn = Clock.Now
        });
}
