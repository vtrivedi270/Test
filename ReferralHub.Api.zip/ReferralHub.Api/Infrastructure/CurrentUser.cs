using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;

namespace ReferralHub.Api.Infrastructure;

/// <summary>Maps the signed-in Entra ID user (from the SPFx token) to a row in rp.Employee and its roles.</summary>
public class CurrentUser(IHttpContextAccessor http, AppDbContext db)
{
    Employee? _employee;

    public async Task<Employee> GetAsync(CancellationToken ct = default)
    {
        if (_employee != null) return _employee;

        var p = http.HttpContext?.User;
        var upn = p?.FindFirst("preferred_username")?.Value
                  ?? p?.FindFirst(ClaimTypes.Upn)?.Value
                  ?? p?.FindFirst(ClaimTypes.Email)?.Value
                  ?? p?.FindFirst("upn")?.Value;
        if (string.IsNullOrWhiteSpace(upn)) throw new ForbiddenException("Sign in to continue.");

        _employee = await db.Employees
            .Include(e => e.Roles).ThenInclude(r => r.Role)
            .FirstOrDefaultAsync(e => e.Email == upn && e.IsActive, ct)
            ?? throw new ForbiddenException("Your account is not set up in Referral Hub. Ask HR to add you.");
        return _employee;
    }

    public async Task<IReadOnlyCollection<string>> RolesAsync(CancellationToken ct = default)
        => (await GetAsync(ct)).Roles.Select(r => r.Role!.Code).ToList();

    public async Task<bool> HasAsync(string role, CancellationToken ct = default)
        => (await RolesAsync(ct)).Contains(role);

    public async Task RequireAsync(string role, CancellationToken ct = default)
    {
        if (!await HasAsync(role, ct)) throw new ForbiddenException("You do not have access to this action.");
    }
}
