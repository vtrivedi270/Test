using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web.Resource;
using ReferralHub.Api.Data;
using ReferralHub.Api.Domain;
using ReferralHub.Api.Dtos;
using ReferralHub.Api.Infrastructure;
using ReferralHub.Api.Services;

namespace ReferralHub.Api.Controllers;

// All endpoints need a valid Entra ID token that carries the access_as_user scope.

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class MeController(CurrentUser me, AppDbContext db) : ControllerBase
{
    /// <summary>Who am I and which roles do I have. The web part uses this to decide which screens to show.</summary>
    [HttpGet("me")]
    public async Task<object> Me(CancellationToken ct)
    {
        var e = await me.GetAsync(ct);
        return new { e.EmployeeId, e.DisplayName, e.Email, e.JobTitle, Roles = await me.RolesAsync(ct) };
    }

    [HttpGet("lookups")]
    public async Task<object> Lookups(CancellationToken ct)
    {
        await me.GetAsync(ct);
        return new
        {
            Departments = await db.Departments.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.DepartmentId, x.Name)).ToListAsync(ct),
            Locations = await db.Locations.AsNoTracking().OrderBy(x => x.Name).Select(x => new LookupItem(x.LocationId, x.Name)).ToListAsync(ct)
        };
    }

    /// <summary>Interviewer picker for HR when scheduling a round.</summary>
    [HttpGet("employees")]
    public async Task<List<LookupItem>> Employees([FromQuery] string? q, CancellationToken ct)
    {
        await me.RequireAsync(Roles.Hr, ct);
        var query = db.Employees.AsNoTracking().Where(x => x.IsActive);
        if (!string.IsNullOrWhiteSpace(q)) query = query.Where(x => x.DisplayName.Contains(q) || x.Email.Contains(q));
        return await query.OrderBy(x => x.DisplayName).Take(20).Select(x => new LookupItem(x.EmployeeId, x.DisplayName)).ToListAsync(ct);
    }
}

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class RequisitionsController(RequisitionService svc) : ControllerBase
{
    /// <summary>Approved, open positions for all employees.</summary>
    [HttpGet("positions")]
    public Task<List<PositionDto>> Positions([FromQuery] string? department, [FromQuery] string? q, CancellationToken ct)
        => svc.OpenPositionsAsync(department, q, ct);

    /// <summary>Manager raises a requisition. It starts with the department head.</summary>
    [HttpPost("requisitions")]
    public async Task<IActionResult> Create(CreateRequisitionDto dto, CancellationToken ct)
        => Ok(new { id = await svc.CreateAsync(dto, ct) });

    [HttpGet("requisitions/mine")]
    public Task<List<RequisitionDto>> Mine(CancellationToken ct) => svc.MineAsync(ct);

    [HttpGet("requisitions")]
    public Task<List<RequisitionDto>> All(CancellationToken ct) => svc.AllAsync(ct);

    /// <summary>Requisitions waiting for my approval (Dept head, Div head or HR head).</summary>
    [HttpGet("approvals/requisitions")]
    public Task<List<RequisitionDto>> Inbox(CancellationToken ct) => svc.InboxAsync(ct);

    [HttpPost("requisitions/{id:int}/approve")]
    public async Task<IActionResult> Approve(int id, DecisionDto? dto, CancellationToken ct)
    { await svc.ApproveAsync(id, dto?.Comments, ct); return NoContent(); }

    [HttpPost("requisitions/{id:int}/reject")]
    public async Task<IActionResult> Reject(int id, RejectDto dto, CancellationToken ct)
    { await svc.RejectAsync(id, dto.Reason, ct); return NoContent(); }
}

[ApiController, Authorize, RequiredScope("access_as_user"), Route("api")]
public class ReferralsController(ReferralService svc) : ControllerBase
{
    /// <summary>Any employee refers a candidate against an open position.</summary>
    [HttpPost("positions/{requisitionId:int}/referrals")]
    public async Task<IActionResult> Submit(int requisitionId, SubmitReferralDto dto, CancellationToken ct)
        => Ok(new { id = await svc.SubmitAsync(requisitionId, dto, ct) });

    [HttpGet("referrals/mine")]
    public Task<List<MyReferralDto>> Mine(CancellationToken ct) => svc.MineAsync(ct);

    /// <summary>HR pipeline. Optional filters: stage id (1-6) and outcome (Active, Selected, Rejected).</summary>
    [HttpGet("referrals")]
    public Task<List<PipelineRowDto>> Pipeline([FromQuery] byte? stage, [FromQuery] string? outcome, CancellationToken ct)
        => svc.PipelineAsync(stage, outcome, ct);

    [HttpGet("referrals/{id:int}")]
    public Task<ReferralDetailDto> Detail(int id, CancellationToken ct) => svc.GetAsync(id, ct);

    [HttpPost("referrals/{id:int}/contact")]
    public async Task<IActionResult> Contact(int id, CancellationToken ct) { await svc.ContactAsync(id, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/shortlist")]
    public async Task<IActionResult> Shortlist(int id, CancellationToken ct) { await svc.ShortlistAsync(id, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/close")]
    public async Task<IActionResult> Close(int id, RejectDto dto, CancellationToken ct) { await svc.CloseAsync(id, dto.Reason, ct); return NoContent(); }

    /// <summary>Schedule or reschedule interview round 1, 2 or 3.</summary>
    [HttpPut("referrals/{id:int}/interviews/{round:int}")]
    public async Task<IActionResult> Schedule(int id, int round, ScheduleDto dto, CancellationToken ct)
        => Ok(new { interviewId = await svc.ScheduleAsync(id, round, dto, ct) });

    /// <summary>Feedback after every round (interviewer or HR).</summary>
    [HttpPost("interviews/{interviewId:int}/feedback")]
    public async Task<IActionResult> Feedback(int interviewId, FeedbackDto dto, CancellationToken ct)
    { await svc.SubmitFeedbackAsync(interviewId, dto, ct); return NoContent(); }

    /// <summary>Candidates waiting for my final decision (Division head or HR head).</summary>
    [HttpGet("approvals/hiring")]
    public Task<List<PipelineRowDto>> HiringInbox(CancellationToken ct) => svc.HiringInboxAsync(ct);

    [HttpPost("referrals/{id:int}/final-approval/approve")]
    public async Task<IActionResult> FinalApprove(int id, DecisionDto? dto, CancellationToken ct)
    { await svc.FinalDecisionAsync(id, true, dto?.Comments, ct); return NoContent(); }

    [HttpPost("referrals/{id:int}/final-approval/reject")]
    public async Task<IActionResult> FinalReject(int id, RejectDto dto, CancellationToken ct)
    { await svc.FinalDecisionAsync(id, false, dto.Reason, ct); return NoContent(); }
}
