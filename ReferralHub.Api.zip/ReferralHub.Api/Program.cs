using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using ReferralHub.Api.Data;
using ReferralHub.Api.Infrastructure;
using ReferralHub.Api.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("ReferralHub")));

// Validates the Entra ID token that the SPFx web part gets through AadHttpClient
builder.Services.AddMicrosoftIdentityWebApiAuthentication(builder.Configuration, "AzureAd");

builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<CurrentUser>();
builder.Services.AddScoped<Notifier>();
builder.Services.AddScoped<RequisitionService>();
builder.Services.AddScoped<ReferralService>();

builder.Services.AddCors(o => o.AddPolicy("spfx", p => p
    .WithOrigins(builder.Configuration.GetSection("Cors:Origins").Get<string[]>() ?? [])
    .AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseMiddleware<ErrorMiddleware>();
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseHttpsRedirection();
app.UseCors("spfx");
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();
app.Run();
