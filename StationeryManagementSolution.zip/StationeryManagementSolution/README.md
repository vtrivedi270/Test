# Stationery Management System — Source Package

Stack:
- SQL Server 2019+ (schema + seed data)
- ASP.NET Core .NET 8 Web API (EF Core, Swagger, JWT configuration)
- SharePoint Framework (SPFx) React + TypeScript client

## Important scope note
This is a source-code starter package. It includes working CRUD-oriented API patterns, SQL schema/seed data, and a functional SPFx UI shell with demo data. It is **not** a fully validated production deployment: configure identity, SharePoint tenant settings, email delivery, permissions, and your environment before production use.

## Folder structure
- `database/01_schema.sql` — tables, constraints, indexes
- `database/02_seed.sql` — sample departments, divisions, items, vendors, users
- `api/Stationery.Api/` — .NET 8 API
- `spfx/stationery-management/` — SPFx React TypeScript client
- `docs/DEPLOYMENT.md` — setup and deployment steps

## Prerequisites
- SQL Server 2019+ and SSMS/Azure Data Studio
- .NET 8 SDK
- Node.js 18.18.x for the SPFx toolchain used here
- SharePoint Framework generator/tooling compatible with SPFx 1.20
- SharePoint Online tenant and app catalog for SPFx deployment

## 1. Create the database
Run `database/01_schema.sql`, then `database/02_seed.sql` in SQL Server.
The scripts create a database named `StationeryManagement`; change the first script if you need a different name.

## 2. Configure and run the API
From `api/Stationery.Api`:
1. Edit `appsettings.json` connection string.
2. Configure JWT issuer/audience/signing key or replace the development authentication setup with Microsoft Entra ID validation.
3. Run:
   ```bash
   dotnet restore
   dotnet run
   ```
4. Open the Swagger URL printed by the application (typically `/swagger`).

Development note: the sample uses a configurable JWT bearer scheme. Never use a sample signing key or permissive development settings in production.

## 3. Configure the SPFx client
The SPFx source is in `spfx/stationery-management`.
1. Install compatible SPFx dependencies for your tenant/toolchain. The package versions are pinned in `package.json`.
2. Set `apiBaseUrl` in `src/webparts/stationeryManagement/StationeryManagementWebPart.ts`.
3. Run `npm install`, `gulp serve`.
4. For packaging: `gulp bundle --ship`, then `gulp package-solution --ship`.
5. Upload the `.sppkg` from `sharepoint/solution` to your tenant app catalog.

If your organization uses SharePoint context authentication, configure the API for Entra ID access tokens and add the correct API permissions. Do not place client secrets in SPFx code.

## Workflow model
Requestor → Reporting Manager → Department Head → Division Head → HRAD → Procurement/Order → Receipt/Inventory → Handover → Requestor close/partial close.

Approvals can approve, reject, or request amendment. The schema retains workflow actions and audit history.

## Production checklist
- Replace development JWT configuration with Entra ID / organizational identity.
- Enforce role and record-level access on every API route.
- Configure CORS to your SharePoint origin only.
- Add real email service and templates; use retry/outbox for reliable delivery.
- Configure file storage and malware scanning for uploaded documents.
- Add tests, logging/monitoring, backups, retention, and operational support.
- Review SQL permissions and run scripts through your database change process.
