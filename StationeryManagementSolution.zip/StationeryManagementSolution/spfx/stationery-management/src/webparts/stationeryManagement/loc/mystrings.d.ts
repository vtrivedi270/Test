declare interface IStationeryManagementWebPartStrings { PropertyPaneDescription: string; ApiBaseUrlFieldLabel: string; }
declare module 'StationeryManagementWebPartStrings' { const strings: IStationeryManagementWebPartStrings; export = strings; }
