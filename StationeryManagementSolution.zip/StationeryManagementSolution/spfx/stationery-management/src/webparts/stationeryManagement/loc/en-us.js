define([], function() { return { 'PropertyPaneDescription': 'Stationery Management settings', 'ApiBaseUrlFieldLabel': 'API base URL' }; });
