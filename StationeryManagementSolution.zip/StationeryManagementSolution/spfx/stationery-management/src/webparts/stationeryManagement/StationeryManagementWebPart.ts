import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as React from 'react';
import * as ReactDom from 'react-dom';
import StationeryApp from './components/StationeryApp';
import { IStationeryAppProps } from './components/IStationeryAppProps';
import * as strings from 'StationeryManagementWebPartStrings';

export interface IStationeryManagementWebPartProps { description: string; apiBaseUrl: string; }

export default class StationeryManagementWebPart extends BaseClientSideWebPart<IStationeryManagementWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IStationeryAppProps> = React.createElement(StationeryApp, {
      description: this.properties.description,
      apiBaseUrl: this.properties.apiBaseUrl || 'https://localhost:7001',
      context: this.context
    });
    ReactDom.render(element, this.domElement);
  }
  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('1.0'); }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return { pages: [{ header: { description: strings.PropertyPaneDescription }, groups: [{ groupName: 'API configuration', groupFields: [
      PropertyPaneTextField('apiBaseUrl', { label: strings.ApiBaseUrlFieldLabel }),
      PropertyPaneTextField('description', { label: 'Description' })
    ] }] }] };
  }
}
