import { WebPartContext } from '@microsoft/sp-webpart-base';
export interface IStationeryAppProps { description: string; apiBaseUrl: string; context: WebPartContext; }
