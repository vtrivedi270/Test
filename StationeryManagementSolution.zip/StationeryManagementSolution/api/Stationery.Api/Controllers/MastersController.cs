using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stationery.Api.Data;
using Stationery.Api.Models;

namespace Stationery.Api.Controllers;

[ApiController]
[Route("api/masters")]
public sealed class MastersController(StationeryDbContext db) : ControllerBase
{
    [HttpGet("items")]
    public Task<List<StationeryItem>> Items(CancellationToken ct) => db.Items.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.ItemName).ToListAsync(ct);

    [HttpPost("items")]
    public async Task<IActionResult> CreateItem(StationeryItem item, CancellationToken ct)
    {
        item.ItemId = 0;
        if (string.IsNullOrWhiteSpace(item.ItemCode) || string.IsNullOrWhiteSpace(item.ItemName)) return BadRequest(new { message = "ItemCode and ItemName are required." });
        if (item.DefaultUnitPrice < 0 || item.ReorderLevel < 0) return BadRequest(new { message = "Price and reorder level cannot be negative." });
        db.Items.Add(item); await db.SaveChangesAsync(ct);
        return Created($"/api/masters/items/{item.ItemId}", item);
    }

    [HttpGet("vendors")]
    public Task<List<Vendor>> Vendors(CancellationToken ct) => db.Vendors.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.VendorName).ToListAsync(ct);

    [HttpGet("departments")]
    public Task<List<Department>> Departments(CancellationToken ct) => db.Departments.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.DepartmentName).ToListAsync(ct);

    [HttpGet("divisions")]
    public Task<List<Division>> Divisions(CancellationToken ct) => db.Divisions.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.DivisionName).ToListAsync(ct);

    [HttpGet("employees")]
    public Task<List<Employee>> Employees(CancellationToken ct) => db.Employees.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.DisplayName).ToListAsync(ct);
}
