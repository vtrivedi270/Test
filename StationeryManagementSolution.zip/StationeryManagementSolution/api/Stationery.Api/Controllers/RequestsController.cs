using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stationery.Api.Data;
using Stationery.Api.Models;

namespace Stationery.Api.Controllers;

[ApiController]
[Route("api/requests")]
public sealed class RequestsController(StationeryDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] string? status, [FromQuery] int? requestorEmployeeId, CancellationToken ct)
    {
        var q = db.Requests.AsNoTracking().Include(x => x.Lines).AsQueryable();
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(x => x.Status == status);
        if (requestorEmployeeId.HasValue) q = q.Where(x => x.RequestorEmployeeId == requestorEmployeeId.Value);
        return Ok(await q.OrderByDescending(x => x.CreatedAt).Take(500).ToListAsync(ct));
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id, CancellationToken ct)
    {
        var entity = await db.Requests.AsNoTracking().Include(x => x.Lines).FirstOrDefaultAsync(x => x.RequestId == id, ct);
        return entity is null ? NotFound() : Ok(entity);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateRequestInput input, CancellationToken ct)
    {
        if (input.Lines is null || input.Lines.Count == 0) return BadRequest(new { message = "At least one line item is required." });
        if (input.Lines.Any(x => x.Quantity <= 0)) return BadRequest(new { message = "Quantity must be greater than zero." });
        var itemIds = input.Lines.Select(x => x.ItemId).Distinct().ToArray();
        var items = await db.Items.Where(x => itemIds.Contains(x.ItemId) && x.IsActive).ToDictionaryAsync(x => x.ItemId, ct);
        if (items.Count != itemIds.Length) return BadRequest(new { message = "One or more items are invalid or inactive." });

        var request = new RequestHeader {
            RequestorEmployeeId = input.RequestorEmployeeId,
            DepartmentId = input.DepartmentId,
            RequestDate = input.RequestDate?.Date ?? DateTime.Today,
            Remarks = input.Remarks,
            Status = "Draft",
            Lines = input.Lines.Select(x => new RequestLineItem {
                ItemId = x.ItemId, Quantity = x.Quantity,
                UnitPrice = x.UnitPrice ?? items[x.ItemId].DefaultUnitPrice,
                Remarks = x.Remarks
            }).ToList()
        };
        request.TotalAmount = request.Lines.Sum(x => x.Quantity * x.UnitPrice);
        db.Requests.Add(request);
        await db.SaveChangesAsync(ct);
        return CreatedAtAction(nameof(Get), new { id = request.RequestId }, request);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, UpdateRequestInput input, CancellationToken ct)
    {
        var request = await db.Requests.Include(x => x.Lines).FirstOrDefaultAsync(x => x.RequestId == id, ct);
        if (request is null) return NotFound();
        if (request.Status is not ("Draft" or "Amendment Required")) return Conflict(new { message = "Only draft or amendment-required requests can be edited." });
        if (input.Lines is null || input.Lines.Count == 0 || input.Lines.Any(x => x.Quantity <= 0))
            return BadRequest(new { message = "Provide at least one line item with a positive quantity." });

        var ids = input.Lines.Select(x => x.ItemId).Distinct().ToArray();
        var items = await db.Items.Where(x => ids.Contains(x.ItemId) && x.IsActive).ToDictionaryAsync(x => x.ItemId, ct);
        if (items.Count != ids.Length) return BadRequest(new { message = "One or more items are invalid or inactive." });

        request.DepartmentId = input.DepartmentId;
        request.Remarks = input.Remarks;
        db.RequestLines.RemoveRange(request.Lines);
        request.Lines = input.Lines.Select(x => new RequestLineItem {
            RequestId = request.RequestId, ItemId = x.ItemId, Quantity = x.Quantity,
            UnitPrice = x.UnitPrice ?? items[x.ItemId].DefaultUnitPrice, Remarks = x.Remarks
        }).ToList();
        request.TotalAmount = request.Lines.Sum(x => x.Quantity * x.UnitPrice);
        request.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        return Ok(request);
    }

    [HttpPost("{id:int}/submit")]
    public async Task<IActionResult> Submit(int id, CancellationToken ct)
    {
        var request = await db.Requests.Include(x => x.Lines).FirstOrDefaultAsync(x => x.RequestId == id, ct);
        if (request is null) return NotFound();
        if (request.Status is not ("Draft" or "Amendment Required")) return Conflict(new { message = "Request cannot be submitted from its current status." });
        if (request.Lines.Count == 0) return BadRequest(new { message = "A request must contain line items." });
        var old = request.Status;
        request.Status = "In Review"; request.CurrentStageOrder = 1;
        request.SubmittedAt = DateTime.UtcNow; request.UpdatedAt = DateTime.UtcNow;
        db.WorkflowActions.Add(new WorkflowActionLog { RequestId = id, Action = "Submit", FromStatus = old, ToStatus = request.Status, Comments = "Submitted for approval" });
        await db.SaveChangesAsync(ct);
        return Ok(request);
    }

    [HttpPost("{id:int}/workflow-action")]
    public async Task<IActionResult> WorkflowAction(int id, WorkflowActionInput input, CancellationToken ct)
    {
        var request = await db.Requests.FirstOrDefaultAsync(x => x.RequestId == id, ct);
        if (request is null) return NotFound();
        var action = input.Action.Trim().ToLowerInvariant();
        var from = request.Status;
        switch (action)
        {
            case "approve":
                if (request.Status == "In Review" && request.CurrentStageOrder < 3) request.CurrentStageOrder++;
                else if (request.Status == "In Review" && request.CurrentStageOrder >= 3) request.Status = "HR Approval";
                else if (request.Status == "HR Approval") request.Status = "HR Approval";
                else return Conflict(new { message = "This request is not awaiting an approval action." });
                break;
            case "reject": request.Status = "Rejected"; break;
            case "amendment": request.Status = "Amendment Required"; break;
            default: return BadRequest(new { message = "Action must be approve, reject, or amendment." });
        }
        request.UpdatedAt = DateTime.UtcNow;
        db.WorkflowActions.Add(new WorkflowActionLog { RequestId = id, Action = action, FromStatus = from, ToStatus = request.Status, Comments = input.Comments });
        await db.SaveChangesAsync(ct);
        return Ok(new { request.RequestId, request.Status, request.CurrentStageOrder });
    }

    [HttpGet("{id:int}/history")]
    public async Task<IActionResult> History(int id, CancellationToken ct)
    {
        if (!await db.Requests.AnyAsync(x => x.RequestId == id, ct)) return NotFound();
        return Ok(await db.WorkflowActions.AsNoTracking().Where(x => x.RequestId == id).OrderByDescending(x => x.ActionAt).ToListAsync(ct));
    }
}
