using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Stationery.Api.Data;
using Stationery.Api.Models;

namespace Stationery.Api.Controllers;

[ApiController]
[Route("api")]
public sealed class OperationsController(StationeryDbContext db) : ControllerBase
{
    [HttpGet("approvals/my-queue")]
    public async Task<IActionResult> ApprovalQueue(CancellationToken ct) =>
        Ok(await db.Requests.AsNoTracking().Include(x => x.Lines).Where(x => x.Status == "In Review" || x.Status == "HR Approval")
            .OrderBy(x => x.SubmittedAt).Take(250).ToListAsync(ct));

    [HttpGet("inventory")]
    public async Task<IActionResult> Inventory(CancellationToken ct)
    {
        var rows = await db.Items.AsNoTracking().Select(i => new {
            i.ItemId, i.ItemCode, i.ItemName, i.Unit, i.ReorderLevel,
            OnHand = db.InventoryTransactions.Where(t => t.ItemId == i.ItemId).Sum(t => (decimal?)(t.QuantityIn - t.QuantityOut)) ?? 0
        }).OrderBy(x => x.ItemName).ToListAsync(ct);
        return Ok(rows);
    }

    [HttpPost("inventory/transactions")]
    public async Task<IActionResult> AddInventory(CreateInventoryTransactionInput input, CancellationToken ct)
    {
        if (input.QuantityIn < 0 || input.QuantityOut < 0 || (input.QuantityIn == 0 && input.QuantityOut == 0))
            return BadRequest(new { message = "Enter a positive quantity in or out." });
        if (!await db.Items.AnyAsync(x => x.ItemId == input.ItemId, ct)) return BadRequest(new { message = "Unknown item." });
        var transaction = new InventoryTransaction { ItemId = input.ItemId, TransactionType = input.TransactionType, QuantityIn = input.QuantityIn, QuantityOut = input.QuantityOut, Notes = input.Notes };
        db.InventoryTransactions.Add(transaction);
        await db.SaveChangesAsync(ct);
        return Ok(transaction);
    }

    [HttpGet("reports/summary")]
    public async Task<IActionResult> Summary(CancellationToken ct)
    {
        var statusCounts = await db.Requests.AsNoTracking().GroupBy(x => x.Status).Select(g => new { Status = g.Key, Count = g.Count() }).ToListAsync(ct);
        var total = await db.Requests.AsNoTracking().SumAsync(x => (decimal?)x.TotalAmount, ct) ?? 0;
        var inventory = await db.Items.CountAsync(ct);
        return Ok(new { totalRequests = await db.Requests.CountAsync(ct), totalAmount = total, activeItems = inventory, statusCounts });
    }

    [HttpPost("procurement")]
    public async Task<IActionResult> CreateProcurement(ProcurementInput input, CancellationToken ct)
    {
        var request = await db.Requests.FirstOrDefaultAsync(x => x.RequestId == input.RequestId, ct);
        if (request is null) return NotFound(new { message = "Request not found." });
        if (!await db.Vendors.AnyAsync(x => x.VendorId == input.VendorId && x.IsActive, ct)) return BadRequest(new { message = "Vendor is invalid or inactive." });
        request.Status = "Ordered";
        request.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        return Ok(new { request.RequestId, request.Status, input.VendorId, input.PurchaseOrderNumber, input.ExpectedDeliveryDate, note = "Persist procurement header/lines through a dedicated procurement repository before production use." });
    }
}
public sealed record ProcurementInput(int RequestId, int VendorId, string? PurchaseOrderNumber, DateTime? ExpectedDeliveryDate);
