namespace Stationery.Api.Models;

public sealed record RequestLineInput(int ItemId, decimal Quantity, decimal? UnitPrice, string? Remarks);
public sealed record CreateRequestInput(int RequestorEmployeeId, int? DepartmentId, DateTime? RequestDate, string? Remarks, List<RequestLineInput> Lines);
public sealed record UpdateRequestInput(int? DepartmentId, string? Remarks, List<RequestLineInput> Lines);
public sealed record WorkflowActionInput(string Action, string? Comments);
public sealed record CreateInventoryTransactionInput(int ItemId, string TransactionType, decimal QuantityIn, decimal QuantityOut, string? Notes);
