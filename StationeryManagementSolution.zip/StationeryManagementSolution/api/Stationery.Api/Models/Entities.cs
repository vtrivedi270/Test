namespace Stationery.Api.Models;

public sealed class RequestHeader
{
    public int RequestId { get; set; }
    public string? RequestNumber { get; private set; }
    public int RequestorEmployeeId { get; set; }
    public DateTime RequestDate { get; set; } = DateTime.Today;
    public int? DepartmentId { get; set; }
    public string? Remarks { get; set; }
    public string Status { get; set; } = "Draft";
    public int CurrentStageOrder { get; set; }
    public decimal TotalAmount { get; set; }
    public DateTime? SubmittedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime UpdatedAt { get; set; }
    public byte[]? RowVersion { get; set; }
    public List<RequestLineItem> Lines { get; set; } = [];
}
public sealed class RequestLineItem
{
    public int RequestLineItemId { get; set; }
    public int RequestId { get; set; }
    public int ItemId { get; set; }
    public decimal Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal { get; private set; }
    public string? Remarks { get; set; }
}
public sealed class StationeryItem
{
    public int ItemId { get; set; }
    public string ItemCode { get; set; } = "";
    public string ItemName { get; set; } = "";
    public string Unit { get; set; } = "Each";
    public decimal DefaultUnitPrice { get; set; }
    public decimal ReorderLevel { get; set; }
    public bool IsActive { get; set; } = true;
}
public sealed class Vendor
{
    public int VendorId { get; set; }
    public string VendorName { get; set; } = "";
    public string? ContactName { get; set; }
    public string? Email { get; set; }
    public string? Phone { get; set; }
    public string? Address { get; set; }
    public bool IsActive { get; set; } = true;
}
public sealed class Department { public int DepartmentId { get; set; } public string DepartmentName { get; set; } = ""; public int? DivisionId { get; set; } public bool IsActive { get; set; } = true; }
public sealed class Division { public int DivisionId { get; set; } public string DivisionName { get; set; } = ""; public bool IsActive { get; set; } = true; }
public sealed class Employee { public int EmployeeId { get; set; } public string EmployeeCode { get; set; } = ""; public string DisplayName { get; set; } = ""; public string Email { get; set; } = ""; public int? DepartmentId { get; set; } public int? ManagerEmployeeId { get; set; } public bool IsActive { get; set; } = true; }
public sealed class WorkflowActionLog
{
    public long WorkflowActionLogId { get; set; }
    public int RequestId { get; set; }
    public int? ActorEmployeeId { get; set; }
    public string? ActorEmail { get; set; }
    public string Action { get; set; } = "";
    public string? FromStatus { get; set; }
    public string? ToStatus { get; set; }
    public string? Comments { get; set; }
    public DateTime ActionAt { get; set; }
}
public sealed class InventoryTransaction
{
    public long InventoryTransactionId { get; set; }
    public int ItemId { get; set; }
    public string TransactionType { get; set; } = "Opening";
    public decimal QuantityIn { get; set; }
    public decimal QuantityOut { get; set; }
    public string? ReferenceType { get; set; }
    public int? ReferenceId { get; set; }
    public string? Notes { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
}
