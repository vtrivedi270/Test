using Microsoft.EntityFrameworkCore;
using Stationery.Api.Models;

namespace Stationery.Api.Data;

public sealed class StationeryDbContext(DbContextOptions<StationeryDbContext> options) : DbContext(options)
{
    public DbSet<RequestHeader> Requests => Set<RequestHeader>();
    public DbSet<RequestLineItem> RequestLines => Set<RequestLineItem>();
    public DbSet<StationeryItem> Items => Set<StationeryItem>();
    public DbSet<Vendor> Vendors => Set<Vendor>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Division> Divisions => Set<Division>();
    public DbSet<Employee> Employees => Set<Employee>();
    public DbSet<WorkflowActionLog> WorkflowActions => Set<WorkflowActionLog>();
    public DbSet<InventoryTransaction> InventoryTransactions => Set<InventoryTransaction>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<RequestHeader>().ToTable("RequestHeader", "dbo").HasKey(x => x.RequestId);
        b.Entity<RequestHeader>().Property(x => x.RequestNumber).HasComputedColumnSql("('ST-' + RIGHT('000000' + CONVERT(VARCHAR(6), RequestId), 6))", stored: true);
        b.Entity<RequestHeader>().Property(x => x.RowVersion).IsRowVersion();
        b.Entity<RequestHeader>().Property(x => x.TotalAmount).HasPrecision(18, 2);
        b.Entity<RequestLineItem>().ToTable("RequestLineItem", "dbo").HasKey(x => x.RequestLineItemId);
        b.Entity<RequestLineItem>().Property(x => x.Quantity).HasPrecision(18, 2);
        b.Entity<RequestLineItem>().Property(x => x.UnitPrice).HasPrecision(18, 2);
        b.Entity<StationeryItem>().ToTable("StationeryItemMaster", "dbo").HasKey(x => x.ItemId);
        b.Entity<Vendor>().ToTable("VendorMaster", "dbo").HasKey(x => x.VendorId);
        b.Entity<Department>().ToTable("DeptMaster", "dbo").HasKey(x => x.DepartmentId);
        b.Entity<Division>().ToTable("DivMaster", "dbo").HasKey(x => x.DivisionId);
        b.Entity<Employee>().ToTable("EmployeeMaster", "dbo").HasKey(x => x.EmployeeId);
        b.Entity<WorkflowActionLog>().ToTable("WorkflowActionLog", "dbo").HasKey(x => x.WorkflowActionLogId);
        b.Entity<InventoryTransaction>().ToTable("InventoryTransaction", "dbo").HasKey(x => x.InventoryTransactionId);
        b.Entity<StationeryItem>().Property(x => x.DefaultUnitPrice).HasPrecision(18, 2);
        b.Entity<InventoryTransaction>().Property(x => x.QuantityIn).HasPrecision(18, 2);
        b.Entity<InventoryTransaction>().Property(x => x.QuantityOut).HasPrecision(18, 2);
    }
}
