USE StationeryManagement;
GO
INSERT INTO dbo.DivMaster(DivisionName) VALUES ('Corporate Services'),('Operations');
INSERT INTO dbo.DeptMaster(DepartmentName,DivisionId)
SELECT 'Administration', DivisionId FROM dbo.DivMaster WHERE DivisionName='Corporate Services';
INSERT INTO dbo.DeptMaster(DepartmentName,DivisionId)
SELECT 'Information Technology', DivisionId FROM dbo.DivMaster WHERE DivisionName='Corporate Services';
INSERT INTO dbo.DeptMaster(DepartmentName,DivisionId)
SELECT 'Plant Operations', DivisionId FROM dbo.DivMaster WHERE DivisionName='Operations';

INSERT INTO dbo.RoleMaster(RoleName) VALUES
('Requestor'),('Reporting Manager'),('Department Head'),('Division Head'),('HRAD'),('Administrator');

INSERT INTO dbo.EmployeeMaster(EmployeeCode,DisplayName,Email,DepartmentId)
SELECT 'EMP001','Demo Requestor','requestor@example.com',DepartmentId FROM dbo.DeptMaster WHERE DepartmentName='Administration';
INSERT INTO dbo.EmployeeMaster(EmployeeCode,DisplayName,Email,DepartmentId)
SELECT 'EMP002','Demo Manager','manager@example.com',DepartmentId FROM dbo.DeptMaster WHERE DepartmentName='Administration';
INSERT INTO dbo.EmployeeMaster(EmployeeCode,DisplayName,Email,DepartmentId)
SELECT 'EMP003','Demo HRAD','hrad@example.com',DepartmentId FROM dbo.DeptMaster WHERE DepartmentName='Administration';

UPDATE dbo.EmployeeMaster SET ManagerEmployeeId=(SELECT EmployeeId FROM dbo.EmployeeMaster WHERE EmployeeCode='EMP002')
WHERE EmployeeCode='EMP001';

INSERT INTO dbo.StationeryItemMaster(ItemCode,ItemName,Unit,DefaultUnitPrice,ReorderLevel) VALUES
('PEN-BLUE','Blue Ball Pen','Each',10,100),
('PPR-A4','A4 Paper Ream','Ream',280,20),
('NOTE-A5','A5 Notebook','Each',45,30),
('FILE-BOX','Box File','Each',65,25),
('MARK-BLK','Black Marker','Each',25,20);

INSERT INTO dbo.VendorMaster(VendorName,ContactName,Email,Phone,Address) VALUES
('Demo Office Supplies','Sales Desk','sales@example.com','0000000000','Sample address - replace before use'),
('Demo Stationers','Account Manager','vendor@example.com','0000000001','Sample address - replace before use');

INSERT INTO dbo.WorkflowDefinition(WorkflowName) VALUES ('Stationery Request Approval');
DECLARE @W INT = SCOPE_IDENTITY();
INSERT INTO dbo.WorkflowStage(WorkflowDefinitionId,StageOrder,StageName,RequiredRole) VALUES
(@W,1,'Reporting Manager Approval','Reporting Manager'),
(@W,2,'Department Head Approval','Department Head'),
(@W,3,'Division Head Approval','Division Head'),
(@W,4,'HRAD Validation','HRAD');
GO
