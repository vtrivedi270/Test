IF DB_ID(N'StationeryManagement') IS NULL
    CREATE DATABASE StationeryManagement;
GO
USE StationeryManagement;
GO

IF OBJECT_ID('dbo.InventoryTransaction','U') IS NOT NULL DROP TABLE dbo.InventoryTransaction;
IF OBJECT_ID('dbo.DeliveryLineItem','U') IS NOT NULL DROP TABLE dbo.DeliveryLineItem;
IF OBJECT_ID('dbo.DeliveryHeader','U') IS NOT NULL DROP TABLE dbo.DeliveryHeader;
IF OBJECT_ID('dbo.ProcurementLineItem','U') IS NOT NULL DROP TABLE dbo.ProcurementLineItem;
IF OBJECT_ID('dbo.ProcurementHeader','U') IS NOT NULL DROP TABLE dbo.ProcurementHeader;
IF OBJECT_ID('dbo.RequestQuery','U') IS NOT NULL DROP TABLE dbo.RequestQuery;
IF OBJECT_ID('dbo.RequestDocument','U') IS NOT NULL DROP TABLE dbo.RequestDocument;
IF OBJECT_ID('dbo.WorkflowActionLog','U') IS NOT NULL DROP TABLE dbo.WorkflowActionLog;
IF OBJECT_ID('dbo.RequestLineItem','U') IS NOT NULL DROP TABLE dbo.RequestLineItem;
IF OBJECT_ID('dbo.RequestHeader','U') IS NOT NULL DROP TABLE dbo.RequestHeader;
IF OBJECT_ID('dbo.WorkflowStage','U') IS NOT NULL DROP TABLE dbo.WorkflowStage;
IF OBJECT_ID('dbo.WorkflowDefinition','U') IS NOT NULL DROP TABLE dbo.WorkflowDefinition;
IF OBJECT_ID('dbo.VendorMaster','U') IS NOT NULL DROP TABLE dbo.VendorMaster;
IF OBJECT_ID('dbo.StationeryItemMaster','U') IS NOT NULL DROP TABLE dbo.StationeryItemMaster;
IF OBJECT_ID('dbo.EmployeeMaster','U') IS NOT NULL DROP TABLE dbo.EmployeeMaster;
IF OBJECT_ID('dbo.DeptMaster','U') IS NOT NULL DROP TABLE dbo.DeptMaster;
IF OBJECT_ID('dbo.DivMaster','U') IS NOT NULL DROP TABLE dbo.DivMaster;
IF OBJECT_ID('dbo.RoleMaster','U') IS NOT NULL DROP TABLE dbo.RoleMaster;
GO

CREATE TABLE dbo.DivMaster (
  DivisionId INT IDENTITY PRIMARY KEY,
  DivisionName NVARCHAR(120) NOT NULL UNIQUE,
  IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.DeptMaster (
  DepartmentId INT IDENTITY PRIMARY KEY,
  DepartmentName NVARCHAR(120) NOT NULL UNIQUE,
  DivisionId INT NULL REFERENCES dbo.DivMaster(DivisionId),
  IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.RoleMaster (
  RoleId INT IDENTITY PRIMARY KEY,
  RoleName NVARCHAR(60) NOT NULL UNIQUE,
  IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.EmployeeMaster (
  EmployeeId INT IDENTITY PRIMARY KEY,
  EmployeeCode NVARCHAR(40) NOT NULL UNIQUE,
  DisplayName NVARCHAR(150) NOT NULL,
  Email NVARCHAR(256) NOT NULL UNIQUE,
  DepartmentId INT NULL REFERENCES dbo.DeptMaster(DepartmentId),
  ManagerEmployeeId INT NULL REFERENCES dbo.EmployeeMaster(EmployeeId),
  IsActive BIT NOT NULL DEFAULT 1,
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.StationeryItemMaster (
  ItemId INT IDENTITY PRIMARY KEY,
  ItemCode NVARCHAR(40) NOT NULL UNIQUE,
  ItemName NVARCHAR(160) NOT NULL,
  Unit NVARCHAR(30) NOT NULL DEFAULT 'Each',
  DefaultUnitPrice DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (DefaultUnitPrice >= 0),
  ReorderLevel DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (ReorderLevel >= 0),
  IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.VendorMaster (
  VendorId INT IDENTITY PRIMARY KEY,
  VendorName NVARCHAR(160) NOT NULL,
  ContactName NVARCHAR(120) NULL,
  Email NVARCHAR(256) NULL,
  Phone NVARCHAR(40) NULL,
  Address NVARCHAR(500) NULL,
  IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.WorkflowDefinition (
  WorkflowDefinitionId INT IDENTITY PRIMARY KEY,
  WorkflowName NVARCHAR(120) NOT NULL,
  IsActive BIT NOT NULL DEFAULT 1,
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.WorkflowStage (
  WorkflowStageId INT IDENTITY PRIMARY KEY,
  WorkflowDefinitionId INT NOT NULL REFERENCES dbo.WorkflowDefinition(WorkflowDefinitionId),
  StageOrder INT NOT NULL,
  StageName NVARCHAR(100) NOT NULL,
  RequiredRole NVARCHAR(60) NOT NULL,
  IsActive BIT NOT NULL DEFAULT 1,
  CONSTRAINT UQ_WorkflowStage_Order UNIQUE(WorkflowDefinitionId, StageOrder)
);
CREATE TABLE dbo.RequestHeader (
  RequestId INT IDENTITY PRIMARY KEY,
  RequestNumber AS ('ST-' + RIGHT('000000' + CONVERT(VARCHAR(6), RequestId), 6)) PERSISTED,
  RequestorEmployeeId INT NOT NULL REFERENCES dbo.EmployeeMaster(EmployeeId),
  RequestDate DATE NOT NULL DEFAULT CONVERT(date, GETDATE()),
  DepartmentId INT NULL REFERENCES dbo.DeptMaster(DepartmentId),
  Remarks NVARCHAR(1000) NULL,
  Status NVARCHAR(40) NOT NULL DEFAULT 'Draft'
    CHECK (Status IN ('Draft','In Review','Amendment Required','Rejected','HR Approval','Ordered','Partially Received','Ready for Handover','Partial Close','Closed','Cancelled')),
  CurrentStageOrder INT NOT NULL DEFAULT 0,
  TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
  SubmittedAt DATETIME2 NULL,
  ClosedAt DATETIME2 NULL,
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  RowVersion ROWVERSION
);
CREATE TABLE dbo.RequestLineItem (
  RequestLineItemId INT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId) ON DELETE CASCADE,
  ItemId INT NOT NULL REFERENCES dbo.StationeryItemMaster(ItemId),
  Quantity DECIMAL(18,2) NOT NULL CHECK (Quantity > 0),
  UnitPrice DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (UnitPrice >= 0),
  LineTotal AS (Quantity * UnitPrice) PERSISTED,
  Remarks NVARCHAR(300) NULL
);
CREATE TABLE dbo.WorkflowActionLog (
  WorkflowActionLogId BIGINT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId),
  ActorEmployeeId INT NULL REFERENCES dbo.EmployeeMaster(EmployeeId),
  ActorEmail NVARCHAR(256) NULL,
  Action NVARCHAR(50) NOT NULL,
  FromStatus NVARCHAR(40) NULL,
  ToStatus NVARCHAR(40) NULL,
  Comments NVARCHAR(1000) NULL,
  ActionAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.RequestDocument (
  RequestDocumentId INT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId) ON DELETE CASCADE,
  FileName NVARCHAR(260) NOT NULL,
  DocumentUrl NVARCHAR(1000) NOT NULL,
  UploadedBy NVARCHAR(256) NULL,
  UploadedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.RequestQuery (
  RequestQueryId INT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId),
  RaisedByEmployeeId INT NOT NULL REFERENCES dbo.EmployeeMaster(EmployeeId),
  QueryText NVARCHAR(2000) NOT NULL,
  ResolutionText NVARCHAR(2000) NULL,
  Status NVARCHAR(30) NOT NULL DEFAULT 'Open',
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  ResolvedAt DATETIME2 NULL
);
CREATE TABLE dbo.ProcurementHeader (
  ProcurementId INT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId),
  VendorId INT NOT NULL REFERENCES dbo.VendorMaster(VendorId),
  PurchaseOrderNumber NVARCHAR(80) NULL,
  OrderDate DATE NOT NULL DEFAULT CONVERT(date, GETDATE()),
  ExpectedDeliveryDate DATE NULL,
  Status NVARCHAR(40) NOT NULL DEFAULT 'Ordered',
  OrderDocumentUrl NVARCHAR(1000) NULL,
  CreatedBy NVARCHAR(256) NULL,
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE TABLE dbo.ProcurementLineItem (
  ProcurementLineItemId INT IDENTITY PRIMARY KEY,
  ProcurementId INT NOT NULL REFERENCES dbo.ProcurementHeader(ProcurementId) ON DELETE CASCADE,
  RequestLineItemId INT NOT NULL REFERENCES dbo.RequestLineItem(RequestLineItemId),
  OrderedQuantity DECIMAL(18,2) NOT NULL CHECK (OrderedQuantity > 0),
  UnitPrice DECIMAL(18,2) NOT NULL CHECK (UnitPrice >= 0)
);
CREATE TABLE dbo.DeliveryHeader (
  DeliveryId INT IDENTITY PRIMARY KEY,
  RequestId INT NOT NULL REFERENCES dbo.RequestHeader(RequestId),
  ReceivedBy NVARCHAR(256) NULL,
  ReceivedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
  HandoverBy NVARCHAR(256) NULL,
  HandoverAt DATETIME2 NULL,
  RequestorConfirmedAt DATETIME2 NULL,
  Status NVARCHAR(40) NOT NULL DEFAULT 'Received',
  Notes NVARCHAR(1000) NULL
);
CREATE TABLE dbo.DeliveryLineItem (
  DeliveryLineItemId INT IDENTITY PRIMARY KEY,
  DeliveryId INT NOT NULL REFERENCES dbo.DeliveryHeader(DeliveryId) ON DELETE CASCADE,
  RequestLineItemId INT NOT NULL REFERENCES dbo.RequestLineItem(RequestLineItemId),
  ReceivedQuantity DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (ReceivedQuantity >= 0),
  HandedOverQuantity DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (HandedOverQuantity >= 0),
  Notes NVARCHAR(500) NULL
);
CREATE TABLE dbo.InventoryTransaction (
  InventoryTransactionId BIGINT IDENTITY PRIMARY KEY,
  ItemId INT NOT NULL REFERENCES dbo.StationeryItemMaster(ItemId),
  TransactionType NVARCHAR(30) NOT NULL CHECK (TransactionType IN ('Opening','Receipt','Issue','Adjustment')),
  QuantityIn DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (QuantityIn >= 0),
  QuantityOut DECIMAL(18,2) NOT NULL DEFAULT 0 CHECK (QuantityOut >= 0),
  ReferenceType NVARCHAR(40) NULL,
  ReferenceId INT NULL,
  Notes NVARCHAR(500) NULL,
  CreatedBy NVARCHAR(256) NULL,
  CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
CREATE INDEX IX_RequestHeader_Status_Date ON dbo.RequestHeader(Status, RequestDate DESC);
CREATE INDEX IX_RequestHeader_Requestor ON dbo.RequestHeader(RequestorEmployeeId, CreatedAt DESC);
CREATE INDEX IX_RequestLineItem_Request ON dbo.RequestLineItem(RequestId);
CREATE INDEX IX_WorkflowActionLog_Request ON dbo.WorkflowActionLog(RequestId, ActionAt DESC);
CREATE INDEX IX_InventoryTransaction_Item ON dbo.InventoryTransaction(ItemId, CreatedAt DESC);
GO
