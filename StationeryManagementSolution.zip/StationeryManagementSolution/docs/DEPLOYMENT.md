# Deployment guide

## SQL Server
1. Back up any target database.
2. Execute `database/01_schema.sql`.
3. Execute `database/02_seed.sql`.
4. Create a least-privilege SQL login for the API. Avoid using `sa`.

## API on IIS
1. Install the .NET 8 Hosting Bundle on the Windows Server.
2. Publish:
   ```bash
   dotnet publish -c Release -o publish
   ```
3. Create an IIS website/application pointing at `publish`.
4. Configure the application pool for **No Managed Code**.
5. Set connection strings and JWT/Entra ID values using environment variables or secure configuration.
6. Enable HTTPS and restrict CORS to your SharePoint site origin.
7. Check `/health` and `/swagger` (disable or restrict Swagger in production).

## SPFx
1. Use the SPFx version supported by your SharePoint tenant/toolchain.
2. Set the API base URL and authentication approach in the web part.
3. `npm install`
4. `gulp bundle --ship`
5. `gulp package-solution --ship`
6. Upload the generated `.sppkg` to the app catalog and deploy it.
7. Grant only the API permissions required by the app.

## Authentication
For local development, API JWT bearer settings can be configured in `appsettings.json`. For production, prefer Microsoft Entra ID token validation and delegated/scoped permissions. Never embed client secrets or signing keys in the SPFx bundle.

## Smoke tests
- GET `/health`
- GET `/api/requests`
- POST `/api/requests`
- POST `/api/requests/{id}/submit`
- GET `/api/approvals/my-queue`
- GET `/api/reports/summary`
