# API endpoint map

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/api/requests` | Filterable request list (`status`, `requestorEmployeeId`) |
| GET | `/api/requests/{id}` | Request detail + line items |
| POST | `/api/requests` | Create draft request |
| PUT | `/api/requests/{id}` | Edit draft/amendment-required request |
| POST | `/api/requests/{id}/submit` | Submit into approval workflow |
| POST | `/api/requests/{id}/workflow-action` | Approve/reject/request amendment |
| GET | `/api/requests/{id}/history` | Workflow audit trail |
| GET | `/api/approvals/my-queue` | Approval queue starter endpoint |
| GET/POST | `/api/masters/items` | List/create stationery items |
| GET | `/api/masters/vendors` | Active vendors |
| GET | `/api/masters/departments` | Active departments |
| GET | `/api/masters/divisions` | Active divisions |
| GET | `/api/masters/employees` | Active employees |
| GET | `/api/inventory` | Inventory balance derived from transactions |
| POST | `/api/inventory/transactions` | Record inventory movement |
| GET | `/api/reports/summary` | Summary KPIs and counts |
| POST | `/api/procurement` | Procurement starter endpoint |

## Before production
The API sample demonstrates core patterns but must be extended for full role-aware business rules, procurement line persistence, delivery receipt/handover transactions, PDF generation, email notifications, paging, and Microsoft Entra ID integration. All authorization must be enforced server-side.
