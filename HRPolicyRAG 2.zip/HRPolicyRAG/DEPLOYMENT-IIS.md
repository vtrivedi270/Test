# Deploying: API on IIS + SharePoint App Catalog + Teams

This covers the three pieces end to end, in the order you'd actually do them.

---

## Part 1 — Backend API on IIS

### 1.1 Prerequisites on the IIS server
- Windows Server with IIS role installed
- **.NET 8 Hosting Bundle** (not just the SDK) — download from
  https://dotnet.microsoft.com/download/dotnet/8.0 → "Hosting Bundle".
  This installs the ASP.NET Core Module that lets IIS run .NET apps.
- A valid HTTPS certificate for the server's hostname. **This is required**,
  not optional — SharePoint/Teams run in the browser and will refuse to call
  a plain `http://` API from an `https://` page (mixed content).

### 1.2 Publish the app
On your dev machine (or the server, if you build there):
```bash
cd Backend
dotnet publish -c Release -o ./publish
```
Copy the contents of `./publish` to the IIS server, e.g.
`C:\inetpub\hrpolicyrag\`.

### 1.3 Configure appsettings for production
Before publishing (or by editing the copied `appsettings.json` on the
server), set:
- `Cors:AllowedOrigins` → your real SharePoint tenant URL
  (`https://yourtenant.sharepoint.com`) and Teams origins
- `AzureAd:TenantId`, `ClientId`, `Audience`, `HRAdminGroupId` → from your
  Entra ID app registration (see the previous setup steps)
- `Jwt:Secret` → a real random secret (only needed if you're keeping the
  standalone React app's login active)
- `Storage:SqlitePath` → an absolute path with write permission for the
  IIS app pool identity, e.g. `D:\hrpolicyrag-data\hrpolicy.db`

### 1.4 Create the IIS site
1. IIS Manager → **Application Pools** → Add Application Pool
   - .NET CLR version: **No Managed Code** (ASP.NET Core doesn't use the
     classic CLR pipeline)
   - Start mode: AlwaysRunning
2. **Sites** → Add Website
   - Physical path: `C:\inetpub\hrpolicyrag`
   - Application pool: the one you just created
   - Binding: **https**, port 443, select your certificate
3. Give the app pool identity (e.g. `IIS AppPool\hrpolicyrag`) **write
   permission** on the SQLite data folder (`D:\hrpolicyrag-data`) — the app
   needs to create/write `hrpolicy.db` there.
4. Browse to `https://your-server-hostname/api/query/ask` (POST-only, so a
   GET will 405 — that's actually a good sign the app is running).

### 1.5 Firewall / reachability
Every employee's browser calls this API directly (it's client-side SPFx
code, not server-to-server) — so the IIS server's HTTPS endpoint must be
reachable from wherever employees are: internal network, VPN, or a public
address behind your firewall/reverse proxy, matching however your org
normally exposes internal web apps. If this is intranet-only, make sure the
DNS name resolves for remote/VPN users too, since Teams/SharePoint Online
are cloud services reaching out from the user's machine, not from inside
your network.

### 1.6 Optional: reverse proxy for a clean internal URL (IIS ARR)

Right now the SPFx properties point straight at the API site's own hostname
(e.g. `https://hrpolicyrag-server.company.local/api`). A reverse proxy lets
you front it with a friendlier, stable name (e.g.
`https://hrpolicy.company.com/api`) that doesn't change if you ever move
the API to a different physical server — useful since that URL is baked
into the SPFx webpart property and re-packaging/redeploying the `.sppkg`
just to change a hostname is annoying.

**Install the modules** (on the IIS server that will act as the proxy —
can be the same server or a separate front-door box):
1. Install **Application Request Routing (ARR)** —
   https://www.iis.net/downloads/microsoft/application-request-routing
2. Install **URL Rewrite** — https://www.iis.net/downloads/microsoft/url-rewrite
3. In IIS Manager → top-level server node → **Application Request
   Routing Cache** → **Server Proxy Settings** → check **Enable proxy**

**Set up the proxy site:**
1. Add a new website (or use Default Web Site) bound to your friendly
   hostname, e.g. `hrpolicy.company.com`, with its own HTTPS certificate
   for that name
2. Select the site → **URL Rewrite** → **Add Rule** → **Reverse Proxy**
3. Enter the actual backend address, e.g.
   `hrpolicyrag-server.company.local:443` (check "SSL Offload" off if the
   backend also uses HTTPS, so the proxy talks HTTPS end-to-end)
4. This creates a rewrite rule forwarding all requests to the real server

**Update configuration to match:**
- `Backend/appsettings.json` → `Cors:AllowedOrigins` stays the same (CORS
  cares about the *calling* origin — SharePoint/Teams — not this hop)
- SPFx webpart property **Backend API base URL** → now
  `https://hrpolicy.company.com/api` instead of the raw server name
- If the proxy and backend are different machines, make sure the backend's
  own site binding still accepts requests from the proxy (host header
  matching — ARR forwards the original Host header by default, which
  usually just works, but is the first thing to check if you get 404s only
  through the proxy)

**Test:** hit `https://hrpolicy.company.com/api/query/ask` (expect a 405
since it's POST-only, same as testing the direct address) — a 404 or
connection error here means the rewrite rule's backend address is wrong,
not a problem with the .NET app itself.

This step is optional — direct IIS binding (1.4) works fine for a smaller
rollout or if the server name is already stable and easy to remember.

---

## Part 2 — SharePoint App Catalog

### 2.1 Build the SPFx package
On a dev machine, after scaffolding per `SPFx/README.md` and dropping in
the provided files:
```bash
npm install
gulp bundle --ship
gulp package-solution --ship
```
This produces `sharepoint/solution/hr-policy-assistant.sppkg`.

### 2.2 Upload to the App Catalog
1. SharePoint Admin Center → **More features** → **Apps** → App Catalog
   (create one for the tenant if it doesn't exist yet)
2. Go to **Apps for SharePoint** → upload the `.sppkg` file
3. When prompted, trust the app (and check "Make available to Teams" if
   you see that option here — otherwise it's a separate toggle, see 2.3)

### 2.3 Set the webpart's connection properties
On any SharePoint page, add the "HR Policy Assistant" webpart, then in its
property pane set:
- **Backend API base URL** → `https://your-iis-server-hostname/api`
- **Azure AD API scope** → `api://<your-backend-client-id>/access_as_user`

---

## Part 3 — Microsoft Teams

1. SharePoint Admin Center → enable **"Make SharePoint Framework solutions
   available to Microsoft Teams"** (tenant-wide setting)
2. Back in the App Catalog, ensure the HR Policy Assistant app has Teams
   availability turned on (checkbox during upload/approval)
3. In Teams: any channel or personal app → **+ Add a tab** → search
   "HR Policy Assistant" → it appears automatically, no manifest upload
4. Configure the same **apiBaseUrl** / **apiScope** properties if prompted

---

## Verifying end to end

1. Open the tab in Teams (or the SharePoint page) — should sign in silently,
   no login form
2. As an "HR Admins" group member: upload a policy PDF, confirm "Ingested…"
   message
3. As a regular employee account: ask a question, confirm you get an answer
   with a source citation
4. Check the browser dev console (F12) for any CORS errors — if you see
   one, the calling origin needs to be added to `Cors:AllowedOrigins` in
   `appsettings.json` on the IIS server, then recycle the app pool

## Common first-time issues
- **CORS error in console** → add the exact origin shown in the error to
  `Cors:AllowedOrigins`, restart the app pool
- **401 Unauthorized from SPFx** → check `apiScope` matches the app
  registration's exposed scope exactly, and that admin consent was granted
- **Mixed content blocked** → the API must be HTTPS, not HTTP, once called
  from SharePoint/Teams (both HTTPS)
- **Upload works but ask says "no documents ingested"** → confirm both
  requests are hitting the same `hrpolicy.db` (a IIS app pool restart
  between them shouldn't matter — the file is persistent — but double check
  `Storage:SqlitePath` is an absolute, consistent path)
- **Works via direct server address but 404s through the reverse proxy** →
  check the ARR rewrite rule's backend address/port and that the backend
  site's bindings accept the forwarded Host header
