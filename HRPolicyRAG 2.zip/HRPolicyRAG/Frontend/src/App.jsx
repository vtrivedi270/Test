import { useState } from "react";
import { uploadPolicy, askQuestion, isLoggedIn, logout } from "./api";
import { STRINGS, LANGUAGES, getLang, setLang } from "./i18n";
import Login from "./Login";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(isLoggedIn());
  const [lang, setLangState] = useState(getLang());
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const [asking, setAsking] = useState(false);

  const t = STRINGS[lang];

  const changeLang = (newLang) => {
    setLang(newLang);
    setLangState(newLang);
  };

  if (!loggedIn) {
    return <Login onLoggedIn={() => setLoggedIn(true)} lang={lang} onChangeLang={changeLang} />;
  }

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await uploadPolicy(file);
      setMessages((m) => [
        ...m,
        { role: "system", text: t.ingested(result.fileName, result.chunksCreated, result.pagesProcessed) }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "system", text: t.uploadFailed + err.message }]);
    } finally {
      setUploading(false);
    }
  };

  const handleAsk = async () => {
    if (!input.trim()) return;
    const question = input;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setAsking(true);
    try {
      // The question's own language is what the backend uses to pick its
      // reply language — the UI language toggle only affects labels here.
      const result = await askQuestion(question);
      setMessages((m) => [
        ...m,
        { role: "assistant", text: result.answer, sources: result.sources }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: t.error + err.message }]);
    } finally {
      setAsking(false);
    }
  };

  return (
    <div style={{ maxWidth: 720, margin: "40px auto", fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>{t.title}</h2>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <select value={lang} onChange={(e) => changeLang(e.target.value)} aria-label={t.language}>
            {Object.entries(LANGUAGES).map(([code, label]) => (
              <option key={code} value={code}>{label}</option>
            ))}
          </select>
          <button onClick={() => { logout(); setLoggedIn(false); }}>{t.logout}</button>
        </div>
      </div>

      <div style={{ marginBottom: 20 }}>
        <label>
          {t.uploadLabel}{" "}
          <input type="file" accept=".pdf" onChange={handleUpload} disabled={uploading} />
        </label>
        {uploading && <span> {t.processing}</span>}
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 16, minHeight: 300, marginBottom: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 12 }}>
            <strong>{m.role === "user" ? t.you : m.role === "assistant" ? t.assistant : t.system}:</strong>
            <div style={{ whiteSpace: "pre-wrap" }}>{m.text}</div>
            {m.sources && m.sources.length > 0 && (
              <div style={{ fontSize: 12, color: "#666" }}>{t.sources}: {m.sources.join(", ")}</div>
            )}
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <input
          style={{ flex: 1, padding: 8 }}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAsk()}
          placeholder={t.placeholder}
        />
        <button onClick={handleAsk} disabled={asking}>
          {asking ? t.thinking : t.ask}
        </button>
      </div>
    </div>
  );
}
