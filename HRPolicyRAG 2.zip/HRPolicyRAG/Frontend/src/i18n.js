export const LANGUAGES = { en: "English", ja: "日本語" };

export const STRINGS = {
  en: {
    title: "HR Policy Assistant",
    logout: "Log out",
    uploadLabel: "Upload HR Policy PDF:",
    processing: "Processing...",
    you: "You",
    assistant: "Assistant",
    system: "System",
    sources: "Sources",
    placeholder: "Ask about leave policy, expenses, WFH rules...",
    ask: "Ask",
    thinking: "Thinking...",
    uploadFailed: "Upload failed: ",
    error: "Error: ",
    ingested: (name, chunks, pages) => `Ingested "${name}" — ${chunks} chunks from ${pages} pages.`,
    username: "Username",
    password: "Password",
    login: "Log in",
    loggingIn: "Logging in...",
    language: "Language"
  },
  ja: {
    title: "HR ポリシーアシスタント",
    logout: "ログアウト",
    uploadLabel: "HRポリシーPDFをアップロード:",
    processing: "処理中...",
    you: "あなた",
    assistant: "アシスタント",
    system: "システム",
    sources: "出典",
    placeholder: "休暇制度、経費、在宅勤務ルールについて質問してください...",
    ask: "質問する",
    thinking: "考え中...",
    uploadFailed: "アップロード失敗: ",
    error: "エラー: ",
    ingested: (name, chunks, pages) => `"${name}" を取り込みました — ${pages}ページから${chunks}チャンク。`,
    username: "ユーザー名",
    password: "パスワード",
    login: "ログイン",
    loggingIn: "ログイン中...",
    language: "言語"
  }
};

export function getLang() {
  return localStorage.getItem("hrrag_lang") || "en";
}

export function setLang(lang) {
  localStorage.setItem("hrrag_lang", lang);
}
