const API_BASE = "http://localhost:5000/api";

function authHeader() {
  const token = localStorage.getItem("hrrag_token");
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function login(username, password) {
  const res = await fetch(`${API_BASE}/auth/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, password })
  });
  if (!res.ok) throw new Error("Invalid username or password");
  const data = await res.json();
  localStorage.setItem("hrrag_token", data.token);
  return data;
}

export function logout() {
  localStorage.removeItem("hrrag_token");
}

export function isLoggedIn() {
  return !!localStorage.getItem("hrrag_token");
}

export async function uploadPolicy(file) {
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${API_BASE}/ingest/upload`, {
    method: "POST",
    headers: { ...authHeader() },
    body: formData
  });
  if (res.status === 401) throw new Error("Session expired — please log in again");
  if (!res.ok) throw new Error("Upload failed");
  return res.json();
}

export async function askQuestion(question) {
  const res = await fetch(`${API_BASE}/query/ask`, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeader() },
    body: JSON.stringify({ question, topK: 4 })
  });
  if (res.status === 401) throw new Error("Session expired — please log in again");
  if (!res.ok) throw new Error("Query failed");
  return res.json();
}
