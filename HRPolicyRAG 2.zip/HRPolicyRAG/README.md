# HR Policy Assistant (100% Free, Fully Local — No AI/LLM)

A tool that answers employee questions from your HR policy PDFs using pure
full-text search — no AI, no LLM, no external dependency of any kind beyond
.NET and SQLite. Every "answer" is the actual matching policy text, with
highlighted terms and a source citation, so there's nothing to hallucinate.

## Stack
- Backend: .NET 8 Web API + PdfPig (PDF parsing) + SQLite FTS5 (full-text search)
- Frontend: React + Vite (standalone), plus SPFx for SharePoint/Teams
- No LLM, no embeddings, no GPU, no model downloads required

## Setup

### 1. Run the backend
```bash
cd Backend
dotnet restore
dotnet run
```
API runs at `http://localhost:5000` (check your launch profile — adjust CORS
origin/API_BASE in the frontend if it uses a different port). This creates
`hrpolicy.db` automatically on first run — no database server to install.

### 2. Run the frontend
```bash
cd Frontend
npm install
npm run dev
```
Opens at `http://localhost:5173`.

### 3. Use it
1. Upload an HR policy PDF via the file picker.
2. Wait for "Ingested... chunks created" confirmation.
3. Ask questions like "How many casual leaves do I get per year?"

## Authentication
Two auth paths are supported side by side:
- **Standalone React app**: the original username/password login (`Auth` section in appsettings.json) — fine for a pilot.
- **SharePoint page / Teams tab (SPFx)**: real Entra ID (AAD) single sign-on — no login screen, uses the signed-in user's Microsoft 365 identity. Configure this in the `AzureAd` section of `Backend/appsettings.json`: register an app for the API in Entra ID, expose a scope, and set `HRAdminGroupId` to the security group whose members can upload policies. Everyone else who signs in can only ask questions. See `SPFx/README.md` for the matching webpart property.

## Multi-language support (including Japanese)
- **Search**: uses SQLite FTS5's `trigram` tokenizer instead of the default word-based one, since Japanese text has no spaces between words — this makes substring search work for Japanese, Chinese, etc. (with somewhat lower precision than for space-separated languages, since word boundaries aren't detected).
- **UI**: both the standalone React app and the SPFx/Teams tab have an English/日本語 toggle for labels and buttons.
- Since there's no LLM here, there's no "generated answer language" to worry about — the employee sees the actual policy text, in whatever language the source PDF was written in.

## How it works
1. **Ingest** — PdfPig extracts text per page from the uploaded PDF.
2. **Chunk** — text is split into ~350-word overlapping chunks.
3. **Store** — chunks go straight into a SQLite FTS5 virtual table as plain text (no embeddings).
4. **Query** — the question is run as an FTS5 `MATCH` query, ranked by SQLite's built-in relevance ranking.
5. **Response** — the top matching excerpts are returned as-is (with `<mark>` highlighted terms), with source file + page. No generation step, nothing to hallucinate, nothing to hallucinate about wrong information.

## Scaling notes
- Pure SQLite full-text search handles hundreds of concurrent readers comfortably — no LLM inference bottleneck to worry about at all, which was the main capacity risk in the earlier AI-mode design.
- Fine up to many thousands of chunks (well beyond a typical HR policy set); if you ever outgrow SQLite, the interface in `KeywordSearchService` is small enough to retarget at SQL Server full-text search with minimal changes.

## Notes
- This scaffold hasn't been build-tested in this environment (no network
  access here to restore NuGet/npm packages) — run `dotnet restore` and
  `npm install` on your machine to pull dependencies before running.
- An earlier version of this project supported an optional Ollama-based
  AI mode (semantic search + generated answers). It has been removed
  entirely per request — this is now keyword-search-only, by design.
