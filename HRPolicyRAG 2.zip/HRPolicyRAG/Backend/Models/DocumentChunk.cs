namespace HRPolicyRAG.Api.Models;

public class QueryRequest
{
    public string Question { get; set; } = string.Empty;
    public int TopK { get; set; } = 4;
}

public class QueryResponse
{
    public string Answer { get; set; } = string.Empty;
    public List<string> Sources { get; set; } = new();
}
