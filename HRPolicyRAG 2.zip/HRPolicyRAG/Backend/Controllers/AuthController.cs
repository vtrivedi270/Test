using HRPolicyRAG.Api.Models;
using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HRPolicyRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AuthService _auth;

    public AuthController(AuthService auth)
    {
        _auth = auth;
    }

    [HttpPost("login")]
    public ActionResult<LoginResponse> Login([FromBody] LoginRequest request)
    {
        if (!_auth.ValidateCredentials(request.Username, request.Password))
            return Unauthorized(new { message = "Invalid username or password" });

        var (token, expiresAt) = _auth.GenerateToken(request.Username);
        return Ok(new LoginResponse { Token = token, ExpiresAt = expiresAt });
    }
}
