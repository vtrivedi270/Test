using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HRPolicyRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Microsoft.AspNetCore.Authorization.Authorize(Policy = "HRAdminOnly")]
public class IngestController : ControllerBase
{
    private readonly PdfIngestionService _pdf;
    private readonly ChunkingService _chunker;
    private readonly KeywordSearchService _keywordStore;

    public IngestController(PdfIngestionService pdf, ChunkingService chunker,
        KeywordSearchService keywordStore)
    {
        _pdf = pdf;
        _chunker = chunker;
        _keywordStore = keywordStore;
    }

    [HttpPost("upload")]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        var tempPath = Path.GetTempFileName();
        await using (var stream = System.IO.File.Create(tempPath))
            await file.CopyToAsync(stream);

        var pages = _pdf.ExtractPages(tempPath);
        int chunkCount = 0;

        foreach (var (pageNumber, text) in pages)
        {
            var chunks = _chunker.Chunk(text);
            foreach (var chunkText in chunks)
            {
                _keywordStore.AddChunk(file.FileName, $"Page {pageNumber}", chunkText);
                chunkCount++;
            }
        }

        System.IO.File.Delete(tempPath);

        return Ok(new { file.FileName, PagesProcessed = pages.Count, ChunksCreated = chunkCount });
    }
}
