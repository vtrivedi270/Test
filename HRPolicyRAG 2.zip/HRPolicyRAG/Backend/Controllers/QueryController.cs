using HRPolicyRAG.Api.Models;
using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HRPolicyRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Microsoft.AspNetCore.Authorization.Authorize(Policy = "AnyUser")]
public class QueryController : ControllerBase
{
    private readonly KeywordSearchService _keywordStore;

    public QueryController(KeywordSearchService keywordStore)
    {
        _keywordStore = keywordStore;
    }

    /// <summary>
    /// Very light language detection just for picking which language to show
    /// the fallback "no results" message in.
    /// </summary>
    private static bool LooksJapanese(string text) =>
        text.Any(c => (c >= '\u3040' && c <= '\u30FF') || (c >= '\u4E00' && c <= '\u9FFF'));

    [HttpPost("ask")]
    public ActionResult<QueryResponse> Ask([FromBody] QueryRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
            return BadRequest("Question cannot be empty.");

        var japanese = LooksJapanese(request.Question);
        var hits = _keywordStore.Search(request.Question, request.TopK);

        if (hits.Count == 0)
            return Ok(new QueryResponse
            {
                Answer = japanese
                    ? "一致するポリシーが見つかりませんでした。別のキーワードで試すか、人事に直接お問い合わせください。"
                    : "No matching policy text found. Try different keywords, or contact HR directly.",
                Sources = new List<string>()
            });

        var combined = string.Join("\n\n", hits.Select(h => $"[{h.SourceFile}, {h.SectionHint}]\n{h.Snippet}"));

        return Ok(new QueryResponse
        {
            Answer = combined,
            Sources = hits.Select(h => $"{h.SourceFile} ({h.SectionHint})").Distinct().ToList()
        });
    }
}
