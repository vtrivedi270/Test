using System.Text;
using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSingleton<PdfIngestionService>();
builder.Services.AddSingleton<ChunkingService>();
builder.Services.AddSingleton<KeywordSearchService>();
builder.Services.AddSingleton<AuthService>();

var jwtSecret = builder.Configuration["Jwt:Secret"]
    ?? throw new InvalidOperationException("Jwt:Secret must be set in appsettings.json");

// Two auth schemes coexist:
//  - "Bearer"  : the app's own JWT, used by the standalone React web app (username/password)
//  - "AzureAd" : Entra ID SSO, used by the SharePoint page and Teams tab (SPFx)
// Both are accepted on the same endpoints; callers use whichever fits their surface.
builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = "HRPolicyRAG",
            ValidAudience = "HRPolicyRAG",
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret))
        };
    })
    .AddMicrosoftIdentityWebApi(builder.Configuration.GetSection("AzureAd"), jwtBearerScheme: "AzureAd");

var hrAdminGroupId = builder.Configuration["AzureAd:HRAdminGroupId"];

builder.Services.AddAuthorization(options =>
{
    // Any authenticated caller, via either scheme — used for asking questions.
    options.AddPolicy("AnyUser", policy =>
    {
        policy.AuthenticationSchemes.Add(JwtBearerDefaults.AuthenticationScheme);
        policy.AuthenticationSchemes.Add("AzureAd");
        policy.RequireAuthenticatedUser();
    });

    // HR admin: either the standalone-app shared login, OR an Entra ID
    // caller who is a member of the configured HR Admins group — used
    // for uploading/managing policy documents.
    options.AddPolicy("HRAdminOnly", policy =>
    {
        policy.AuthenticationSchemes.Add(JwtBearerDefaults.AuthenticationScheme);
        policy.AuthenticationSchemes.Add("AzureAd");
        policy.RequireAuthenticatedUser();
        policy.RequireAssertion(ctx =>
        {
            // Standalone app's own JWT: any successfully authenticated caller
            // on that scheme already went through the shared HR login.
            if (ctx.User.Identity?.AuthenticationType == JwtBearerDefaults.AuthenticationScheme)
                return true;

            // Entra ID token: must carry the configured HR Admins group id.
            if (string.IsNullOrEmpty(hrAdminGroupId)) return false;
            return ctx.User.Claims.Any(c => c.Type == "groups" && c.Value == hrAdminGroupId);
        });
    });
});

// CORS: browsers running the React app, SharePoint pages, and Teams tabs all
// call this API directly (client-side), so their origins must be explicitly
// allowed. Configure real origins in appsettings.json under Cors:AllowedOrigins
// once deployed — localhost entries are dev-only.
var allowedOrigins = builder.Configuration.GetSection("Cors:AllowedOrigins").Get<string[]>()
    ?? new[] { "http://localhost:5173", "http://localhost:3000" };

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
        policy.WithOrigins(allowedOrigins)
              .AllowAnyHeader()
              .AllowAnyMethod());
});

var app = builder.Build();

app.UseCors();
app.UseAuthentication();
app.UseAuthorization();
app.MapControllers();

app.Run();
