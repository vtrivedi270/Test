using UglyToad.PdfPig;

namespace HRPolicyRAG.Api.Services;

public class PdfIngestionService
{
    /// <summary>
    /// Extracts raw text page-by-page from a PDF. Returns list of (pageNumber, text).
    /// </summary>
    public List<(int PageNumber, string Text)> ExtractPages(string filePath)
    {
        var pages = new List<(int, string)>();
        using var document = PdfDocument.Open(filePath);

        foreach (var page in document.GetPages())
        {
            var text = page.Text;
            if (!string.IsNullOrWhiteSpace(text))
                pages.Add((page.Number, text));
        }

        return pages;
    }
}
