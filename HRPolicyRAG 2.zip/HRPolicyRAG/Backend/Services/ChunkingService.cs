namespace HRPolicyRAG.Api.Services;

public class ChunkingService
{
    /// <summary>
    /// Splits text into overlapping word-based chunks (approximation of token chunks).
    /// chunkSize/overlap are in words, which is close enough for HR policy prose.
    /// </summary>
    public List<string> Chunk(string text, int chunkSize = 350, int overlap = 60)
    {
        var words = text.Split(new[] { ' ', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries);
        var chunks = new List<string>();

        if (words.Length == 0) return chunks;

        int start = 0;
        while (start < words.Length)
        {
            int len = Math.Min(chunkSize, words.Length - start);
            var chunk = string.Join(' ', words.Skip(start).Take(len));
            chunks.Add(chunk);

            if (start + len >= words.Length) break;
            start += chunkSize - overlap;
        }

        return chunks;
    }
}
