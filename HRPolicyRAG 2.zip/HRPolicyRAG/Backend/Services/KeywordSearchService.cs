using Microsoft.Data.Sqlite;

namespace HRPolicyRAG.Api.Services;

/// <summary>
/// Pure keyword search over policy chunks using SQLite FTS5 — no embeddings,
/// no LLM, no external AI dependency. Returns matching excerpts directly
/// rather than a synthesized answer.
/// </summary>
public class KeywordSearchService
{
    private readonly string _dbPath;

    public KeywordSearchService(IConfiguration config)
    {
        _dbPath = config["Storage:SqlitePath"] ?? "hrpolicy.db";
        EnsureTable();
    }

    private void EnsureTable()
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        // 'trigram' tokenizer (SQLite 3.34+) works for languages without
        // spaces between words, like Japanese — the default 'unicode61'
        // tokenizer splits on whitespace and would badly fragment CJK text.
        cmd.CommandText = """
            CREATE VIRTUAL TABLE IF NOT EXISTS ChunksFts USING fts5(
                SourceFile,
                SectionHint,
                Text,
                tokenize='trigram'
            );
            """;
        cmd.ExecuteNonQuery();
    }

    public void AddChunk(string sourceFile, string sectionHint, string text)
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            INSERT INTO ChunksFts (SourceFile, SectionHint, Text)
            VALUES ($src, $section, $text);
            """;
        cmd.Parameters.AddWithValue("$src", sourceFile);
        cmd.Parameters.AddWithValue("$section", sectionHint);
        cmd.Parameters.AddWithValue("$text", text);
        cmd.ExecuteNonQuery();
    }

    public record SearchHit(string SourceFile, string SectionHint, string Snippet);

    /// <summary>
    /// FTS5 MATCH search with ranking and a highlighted snippet of the hit.
    /// The trigram tokenizer matches by substring rather than by word, which
    /// is what makes it usable for space-less languages like Japanese. For
    /// space-separated queries (English etc.) each word is required (AND).
    /// For queries with no spaces (typically Japanese/Chinese), the query is
    /// split into overlapping 3-character windows and any of them may match
    /// (OR) — word boundaries aren't reliably knowable without a proper CJK
    /// segmenter, so this trades some precision for recall. Terms under 3
    /// characters can't be matched by a trigram index and are dropped.
    /// </summary>
    public List<SearchHit> Search(string query, int topK = 5)
    {
        var trimmed = query.Trim();
        if (trimmed.Length == 0) return new List<SearchHit>();

        string sanitized;
        if (trimmed.Contains(' '))
        {
            var words = trimmed.Split(' ', StringSplitOptions.RemoveEmptyEntries)
                .Where(w => w.Length >= 3)
                .Select(w => "\"" + w.Replace("\"", "\"\"") + "\"");
            sanitized = string.Join(" ", words); // implicit AND
        }
        else
        {
            var windows = new List<string>();
            for (int i = 0; i + 3 <= trimmed.Length; i++)
                windows.Add(trimmed.Substring(i, 3));
            sanitized = string.Join(" OR ", windows.Distinct().Take(12)
                .Select(w => "\"" + w.Replace("\"", "\"\"") + "\""));
        }

        if (string.IsNullOrWhiteSpace(sanitized)) return new List<SearchHit>();

        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT SourceFile, SectionHint,
                   snippet(ChunksFts, 2, '<mark>', '</mark>', '...', 20) AS Snip
            FROM ChunksFts
            WHERE ChunksFts MATCH $q
            ORDER BY rank
            LIMIT $topK;
            """;
        cmd.Parameters.AddWithValue("$q", sanitized);
        cmd.Parameters.AddWithValue("$topK", topK);

        var results = new List<SearchHit>();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(new SearchHit(reader.GetString(0), reader.GetString(1), reader.GetString(2)));
        }

        return results;
    }
}
