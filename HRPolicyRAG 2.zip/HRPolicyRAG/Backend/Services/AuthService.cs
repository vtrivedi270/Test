using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace HRPolicyRAG.Api.Services;

/// <summary>
/// Lightweight single/multi-user auth for an internal tool. Credentials are
/// configured in appsettings (username -> salted SHA-256 password hash).
/// For a real multi-user rollout, swap this for AAD/Entra ID (you already
/// use Graph API elsewhere, so SSO via Entra is the natural upgrade path).
/// </summary>
public class AuthService
{
    private readonly IConfiguration _config;

    public AuthService(IConfiguration config)
    {
        _config = config;
    }

    public bool ValidateCredentials(string username, string password)
    {
        var configuredUser = _config["Auth:Username"];
        var configuredHash = _config["Auth:PasswordHash"]; // hex SHA-256
        var salt = _config["Auth:Salt"] ?? "";

        if (string.IsNullOrEmpty(configuredUser) || string.IsNullOrEmpty(configuredHash))
            return false;

        if (!string.Equals(username, configuredUser, StringComparison.OrdinalIgnoreCase))
            return false;

        var computedHash = HashPassword(password, salt);
        return computedHash == configuredHash;
    }

    public static string HashPassword(string password, string salt)
    {
        using var sha = SHA256.Create();
        var bytes = Encoding.UTF8.GetBytes(password + salt);
        var hash = sha.ComputeHash(bytes);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    public (string Token, DateTime ExpiresAt) GenerateToken(string username)
    {
        var secret = _config["Jwt:Secret"] ?? throw new InvalidOperationException("Jwt:Secret not configured");
        var expiresAt = DateTime.UtcNow.AddHours(8);

        var claims = new[]
        {
            new Claim(ClaimTypes.Name, username)
        };

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(secret));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            issuer: "HRPolicyRAG",
            audience: "HRPolicyRAG",
            claims: claims,
            expires: expiresAt,
            signingCredentials: creds
        );

        return (new JwtSecurityTokenHandler().WriteToken(token), expiresAt);
    }
}
