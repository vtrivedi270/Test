# Using HR Policy Assistant as a Teams tab

Your SPFx webpart already declares `"supportedHosts": ["SharePointWebPart", "TeamsPersonalApp", "TeamsTab"]`
in its manifest — SharePoint Framework webparts with this flag can be added
straight into Teams as a tab, with no separate Teams app package or bot
needed. This is the officially supported path (Microsoft calls it
"SharePoint Framework in Microsoft Teams").

## One-time setup (tenant admin)

1. Go to the **SharePoint Admin Center** → **Advanced** → **API access**
   (or **More features** → **Apps**, depending on your tenant's layout).
2. Find the setting **"Make SharePoint Framework solutions available to
   Microsoft Teams"** (sometimes shown as "Store apps in Teams" / Teams
   sync) and turn it **on**.
3. Upload `hr-policy-assistant.sppkg` (built via `gulp package-solution
   --ship`, see `SPFx/README.md`) to the **App Catalog** as usual.
4. When approving/deploying the app in the App Catalog, there's a toggle
   or checkbox for **"Make this solution available to Microsoft Teams"** —
   enable it. SharePoint auto-generates the matching Teams app package
   behind the scenes.

## Adding the tab (any user with access)

1. In Teams, go to a channel (or a 1:1/personal scope for a personal tab)
   → **+ Add a tab** → search for **"HR Policy Assistant"**.
2. It appears because of the sync in step 4 above — no manual manifest
   upload required.
3. Configure the tab's **apiBaseUrl** property if prompted (same setting
   as the SharePoint page version) so it points at your hosted .NET API.

## What changes vs. the SharePoint page version

Nothing in the code — it's the exact same `HrPolicyAssistantWebPart` and
`HrPolicyAssistant.tsx` component. Teams just renders the SPFx webpart in
an iframe styled to Teams' UI. `this.context.pageContext.user.displayName`
still resolves correctly since Teams passes through the SharePoint/AAD
identity.

## Icon

Teams shows the tab icon from the `iconImageUrl` field in
`HrPolicyAssistantWebPart.manifest.json` — currently a placeholder.
Replace it with a real 32x32 PNG hosted somewhere reachable (a SharePoint
document library asset works fine) before shipping to real users.

## If sync isn't available on your tenant

Some tenants have this feature restricted by policy. In that case the
fallback is a manual Teams app package (a `manifest.json` with a
`staticTabs` entry pointing at a `contentUrl`) — this requires hosting a
plain web page that embeds the same React component outside of SPFx.
That's a bigger lift (effectively a second frontend target) — let me know
if your tenant blocks the sync feature and I'll build that path instead.
