export type Lang = "en" | "ja";

export const STRINGS: Record<Lang, {
  title: string;
  greeting: (name: string) => string;
  signingIn: string;
  authError: string;
  you: string;
  assistant: string;
  system: string;
  sources: string;
  placeholder: string;
  ask: string;
  thinking: string;
  uploadFailed: string;
  error: string;
  language: string;
  ingested: (name: string, chunks: number, pages: number) => string;
}> = {
  en: {
    title: "HR Policy Assistant",
    greeting: (name) => `Hi ${name}, signed in via your Microsoft 365 account.`,
    signingIn: "Signing you in...",
    authError: "Sign-in failed",
    you: "You",
    assistant: "Assistant",
    system: "System",
    sources: "Sources",
    placeholder: "Ask about leave, WFH, expenses...",
    ask: "Ask",
    thinking: "...",
    uploadFailed: "Upload failed: ",
    error: "Error: ",
    language: "Language",
    ingested: (name, chunks, pages) => `Ingested "${name}" — ${chunks} chunks from ${pages} pages.`
  },
  ja: {
    title: "HR ポリシーアシスタント",
    greeting: (name) => `${name} さん、Microsoft 365 アカウントでサインインしました。`,
    signingIn: "サインイン中...",
    authError: "サインインに失敗しました",
    you: "あなた",
    assistant: "アシスタント",
    system: "システム",
    sources: "出典",
    placeholder: "休暇、在宅勤務、経費について質問してください...",
    ask: "質問する",
    thinking: "...",
    uploadFailed: "アップロード失敗: ",
    error: "エラー: ",
    language: "言語",
    ingested: (name, chunks, pages) => `"${name}" を取り込みました — ${pages}ページから${chunks}チャンク。`
  }
};
