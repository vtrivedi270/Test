import * as React from "react";
import { AadHttpClient, AadHttpClientFactory, HttpClientResponse } from "@microsoft/sp-http";
import styles from "./HrPolicyAssistant.module.scss";
import { STRINGS, Lang } from "./strings";

export interface IHrPolicyAssistantProps {
  apiBaseUrl: string;
  apiScope: string;
  userDisplayName: string;
  aadHttpClientFactory: AadHttpClientFactory;
}

interface IMessage {
  role: "user" | "assistant" | "system";
  text: string;
  sources?: string[];
}

const HrPolicyAssistant: React.FC<IHrPolicyAssistantProps> = ({
  apiBaseUrl,
  apiScope,
  userDisplayName,
  aadHttpClientFactory
}) => {
  const [client, setClient] = React.useState<AadHttpClient | null>(null);
  const [clientError, setClientError] = React.useState("");
  const [lang, setLangState] = React.useState<Lang>(
    (sessionStorage.getItem("hrrag_spfx_lang") as Lang) || "en"
  );
  const [messages, setMessages] = React.useState<IMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  const t = STRINGS[lang];

  const changeLang = (newLang: Lang): void => {
    sessionStorage.setItem("hrrag_spfx_lang", newLang);
    setLangState(newLang);
  };

  // Acquire the Entra ID-backed HTTP client once on mount. This is what
  // replaces a login screen: the user is already signed into SharePoint
  // /Teams, and this silently gets a token for our backend API's scope.
  React.useEffect(() => {
    aadHttpClientFactory
      .getClient(apiScope)
      .then(setClient)
      .catch((err: Error) => setClientError(err.message));
  }, [apiScope]);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files?.[0];
    if (!file || !client) return;
    const formData = new FormData();
    formData.append("file", file);
    setBusy(true);
    try {
      const res: HttpClientResponse = await client.post(
        `${apiBaseUrl}/ingest/upload`,
        AadHttpClient.configurations.v1,
        { body: formData }
      );
      const data = await res.json();
      setMessages((m) => [
        ...m,
        { role: "system", text: t.ingested(data.fileName, data.chunksCreated, data.pagesProcessed) }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "system", text: t.uploadFailed + (err as Error).message }]);
    } finally {
      setBusy(false);
    }
  };

  const handleAsk = async (): Promise<void> => {
    if (!input.trim() || !client) return;
    const question = input;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setBusy(true);
    try {
      const res: HttpClientResponse = await client.post(
        `${apiBaseUrl}/query/ask`,
        AadHttpClient.configurations.v1,
        {
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ question, topK: 4 })
        }
      );
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", text: data.answer, sources: data.sources }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: t.error + (err as Error).message }]);
    } finally {
      setBusy(false);
    }
  };

  if (clientError) {
    return (
      <div className={styles.hrPolicyAssistant}>
        <h2>{t.title}</h2>
        <div className={styles.error}>{t.authError}: {clientError}</div>
      </div>
    );
  }

  if (!client) {
    return (
      <div className={styles.hrPolicyAssistant}>
        <h2>{t.title}</h2>
        <p>{t.signingIn}</p>
      </div>
    );
  }

  return (
    <div className={styles.hrPolicyAssistant}>
      <div className={styles.headerRow}>
        <h2>{t.title}</h2>
        <select value={lang} onChange={(e) => changeLang(e.target.value as Lang)} aria-label={t.language}>
          <option value="en">English</option>
          <option value="ja">日本語</option>
        </select>
      </div>
      <p className={styles.greeting}>{t.greeting(userDisplayName)}</p>
      <input type="file" accept=".pdf" onChange={handleUpload} disabled={busy} />
      <div className={styles.messages}>
        {messages.map((m, i) => (
          <div key={i} className={styles.message}>
            <strong>{m.role === "user" ? t.you : m.role === "assistant" ? t.assistant : t.system}:</strong>{" "}
            <span style={{ whiteSpace: "pre-wrap" }}>{m.text}</span>
            {m.sources && m.sources.length > 0 && (
              <div className={styles.sources}>{t.sources}: {m.sources.join(", ")}</div>
            )}
          </div>
        ))}
      </div>
      <div className={styles.inputRow}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAsk()}
          placeholder={t.placeholder}
        />
        <button onClick={handleAsk} disabled={busy}>{busy ? t.thinking : t.ask}</button>
      </div>
    </div>
  );
};

export default HrPolicyAssistant;
