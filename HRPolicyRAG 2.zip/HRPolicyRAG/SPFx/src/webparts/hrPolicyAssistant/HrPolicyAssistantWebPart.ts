import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import HrPolicyAssistant, { IHrPolicyAssistantProps } from "./components/HrPolicyAssistant";

export interface IHrPolicyAssistantWebPartProps {
  apiBaseUrl: string;
  apiScope: string;
}

export default class HrPolicyAssistantWebPart extends BaseClientSideWebPart<IHrPolicyAssistantWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IHrPolicyAssistantProps> = React.createElement(
      HrPolicyAssistant,
      {
        apiBaseUrl: this.properties.apiBaseUrl || "http://localhost:5000/api",
        apiScope: this.properties.apiScope,
        userDisplayName: this.context.pageContext.user.displayName,
        // SharePoint/Teams identity flows through automatically via this
        // factory — no separate login screen needed.
        aadHttpClientFactory: this.context.aadHttpClientFactory
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: { description: "HR Policy Assistant settings" },
          groups: [
            {
              groupName: "API Connection",
              groupFields: [
                PropertyPaneTextField("apiBaseUrl", {
                  label: "Backend API base URL",
                  description: "e.g. https://your-internal-host/api"
                }),
                PropertyPaneTextField("apiScope", {
                  label: "Azure AD API scope",
                  description: "e.g. api://<backend-client-id>/access_as_user"
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
