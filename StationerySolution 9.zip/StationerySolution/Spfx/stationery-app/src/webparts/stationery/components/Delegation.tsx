import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Me } from '../models';
import { Alert, Btn, Chip, Field, toast } from './kit';
import { fmtDate } from './ui';

interface Deleg { delegationId: number; fromEmployeeId: number; fromName: string; toEmployeeId: number; toName: string; startDate: string; endDate: string; reason?: string; isActive: boolean; activeNow: boolean; mine: boolean; }
interface Emp { employeeId: number; fullName: string; }
const today = (): string => new Date().toISOString().slice(0, 10);

/** Approver delegation: while you are away, a delegate can approve / amend / reject on your behalf (recorded in history). */
const Delegation: React.FC<{ api: ApiService; me: Me }> = ({ api, me }) => {
  const isAdmin = me.roles.indexOf('Admin') > -1;
  const [rows, setRows] = useState<Deleg[]>([]);
  const [emps, setEmps] = useState<Emp[]>([]);
  const [all, setAll] = useState(false);
  const [from, setFrom] = useState(me.employeeId);
  const [to, setTo] = useState(0);
  const [start, setStart] = useState(today());
  const [end, setEnd] = useState(today());
  const [reason, setReason] = useState('');
  const [err, setErr] = useState<string>();

  const load = (): void => { api.get<Deleg[]>('delegations' + (all ? '?all=true' : '')).then(setRows).catch((e: Error) => setErr(e.message)); };
  useEffect(() => { api.get<Emp[]>('masters/employees?active=true').then(setEmps).catch(() => undefined); }, []);
  useEffect(load, [all]);

  const create = async (): Promise<void> => {
    setErr(undefined);
    if (!to) { setErr('Choose a delegate'); return; }
    if (to === from) { setErr('Choose a different delegate'); return; }
    if (end < start) { setErr('End date cannot be before start date'); return; }
    try {
      await api.post('delegations', { fromEmployeeId: from === me.employeeId ? null : from, toEmployeeId: to, startDate: start, endDate: end, reason: reason });
      toast('Delegation created, delegate notified'); setReason(''); load();
    } catch (e) { setErr((e as Error).message); }
  };
  const revoke = async (d: Deleg): Promise<void> => {
    if (!window.confirm('Revoke delegation to ' + d.toName + '?')) return;
    try { await api.del('delegations/' + d.delegationId); toast('Delegation revoked'); load(); } catch (e) { setErr((e as Error).message); }
  };
  const state = (d: Deleg): [string, string] =>
    !d.isActive ? ['Revoked', '#6b7280'] : d.activeNow ? ['Active now', '#15803d'] : d.startDate.slice(0, 10) > today() ? ['Scheduled', '#2563eb'] : ['Expired', '#b45309'];

  return (<>
    <h1>Delegation</h1>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <h2>Delegate approvals</h2>
      <div className="mut">While active, the delegate sees the approver{'\u2019'}s pending requests and can approve, amend or reject. Their decision is recorded as {'\u201C'}on behalf of{'\u201D'}.</div>
      <div className="row" style={{ marginTop: 12, alignItems: 'flex-end' }}>
        {isAdmin && <Field label="Approver"><select value={from} onChange={e => setFrom(Number(e.target.value))}>{emps.map(e => <option key={e.employeeId} value={e.employeeId}>{e.fullName}</option>)}</select></Field>}
        {!isAdmin && <Field label="Approver"><input readOnly value={me.fullName} /></Field>}
        <Field label="Delegate to"><select value={to} onChange={e => setTo(Number(e.target.value))}><option value={0}>Select person</option>
          {emps.filter(e => e.employeeId !== from).map(e => <option key={e.employeeId} value={e.employeeId}>{e.fullName}</option>)}</select></Field>
        <Field label="From"><input type="date" value={start} onChange={e => setStart(e.target.value)} /></Field>
        <Field label="To"><input type="date" value={end} onChange={e => setEnd(e.target.value)} /></Field>
        <Field label="Reason"><input value={reason} onChange={e => setReason(e.target.value)} /></Field>
        <Btn onClick={create}>Create delegation</Btn>
      </div>
    </div>
    <div className="card">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0 }}>{all ? 'All delegations' : 'My delegations'}</h2>
        {isAdmin && <label className="mut"><input type="checkbox" checked={all} onChange={e => setAll(e.target.checked)} /> Show all</label>}
      </div>
      <div className="tw"><table>
        <thead><tr><th>Approver</th><th>Delegate</th><th>From</th><th>To</th><th>Reason</th><th>Status</th><th /></tr></thead>
        <tbody>
          {rows.length === 0 && <tr><td colSpan={7} className="mut">No delegations.</td></tr>}
          {rows.map(d => { const s = state(d); return (
            <tr key={d.delegationId}><td>{d.fromName}{d.mine ? ' (you)' : ''}</td><td>{d.toName}{d.toEmployeeId === me.employeeId ? ' (you)' : ''}</td>
              <td>{fmtDate(d.startDate)}</td><td>{fmtDate(d.endDate)}</td><td>{d.reason || '\u2013'}</td><td><Chip bg={s[1]}>{s[0]}</Chip></td>
              <td>{d.isActive && (d.mine || isAdmin) && <Btn v="g" s onClick={() => revoke(d)}>Revoke</Btn>}</td></tr>); })}
        </tbody></table></div>
    </div>
  </>);
};
export default Delegation;
