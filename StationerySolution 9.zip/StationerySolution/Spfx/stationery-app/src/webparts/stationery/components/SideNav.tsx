import * as React from 'react';
import { Me, RouteName } from '../models';
import { Icon } from './kit';

interface Props { me: Me; active: RouteName; pending: number; collapsed: boolean; onToggle: () => void; go: (n: RouteName) => void; }
interface NavItem { key: RouteName; label: string; icon: string; badge?: number; }

/** Left navigation: same markup and classes as the preview (.side, .hd, .sec, .nav, .bd, .us). */
const SideNav: React.FC<Props> = ({ me, active, pending, collapsed, onToggle, go }) => {
  const has = (r: string): boolean => me.roles.indexOf(r) > -1;
  const main: NavItem[] = [{ key: 'dash', label: 'Dashboard', icon: 'dash' }, { key: 'list', label: 'Requests', icon: 'list', badge: pending }];
  const work: NavItem[] = [{ key: 'new', label: 'New request', icon: 'add' }];
  if (has('HRAD') || has('Admin')) work.push({ key: 'stock', label: 'Store stock', icon: 'box' });
  if (has('Approver') || has('Admin')) work.push({ key: 'delegation', label: 'Delegation', icon: 'users' });
  const admin: NavItem[] = has('Admin') ? [{ key: 'admin', label: 'Admin masters', icon: 'adm' }, { key: 'emails', label: 'E-mail log', icon: 'mail' }] : [];

  const section = (title: string, items: NavItem[]): React.ReactNode => items.length === 0 ? null : (
    <React.Fragment key={title}>
      <div className="sec">{title}</div>
      {items.map(n => (
        <button type="button" key={n.key} className={'nav' + (active === n.key ? ' on' : '')} title={n.label} aria-current={active === n.key ? 'page' : undefined} onClick={() => go(n.key)}>
          <Icon k={n.icon} /><span className="lb">{n.label}</span>{n.badge ? <span className="bd">{n.badge}</span> : null}
        </button>))}
    </React.Fragment>);

  return (
    <nav className={'side' + (collapsed ? ' col' : '')} aria-label="Main navigation">
      <div className="hd">
        <div className="brand"><div className="logo"><Icon k="pen" style={{ stroke: '#fff' }} /></div><span>Stationery Hub</span></div>
        <button type="button" className="tg" aria-label="Toggle menu" aria-expanded={!collapsed} onClick={onToggle}><Icon k="menu" /></button>
      </div>
      {section('Overview', main)}{section('Work', work)}{section('Administration', admin)}
      <div className="us">
        <div className="av2">{me.fullName.charAt(0).toUpperCase()}</div>
        <div className="un"><div style={{ color: '#fff', fontWeight: 600, fontSize: 13 }}>{me.fullName}</div>
          <div style={{ color: '#8fc0ea', fontSize: 11 }}>{me.persona} {'\u00B7'} {me.departmentName}</div></div>
      </div>
    </nav>);
};
export default SideNav;
