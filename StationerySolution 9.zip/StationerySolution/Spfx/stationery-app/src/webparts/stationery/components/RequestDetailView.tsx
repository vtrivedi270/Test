import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Me, RequestDetail, RouteName, Vendor } from '../models';
import { Alert, Btn, Field, toast } from './kit';
import { fmt, fmtDate, STAGE } from './ui';
import StatusChip from './StatusChip';
import HradTools from './HradTools';
import CancelCard from './CancelCard';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; requestId: number; }
const CHAIN = ['ReportingManager', 'DeptHead', 'DivHead'];

const RequestDetailView: React.FC<Props> = ({ api, me, go, requestId }) => {
  const [r, setR] = useState<RequestDetail>();
  const [err, setErr] = useState<string>();
  const [comment, setComment] = useState('');
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [vendorId, setVendorId] = useState<number>(0);
  const [hl, setHl] = useState<{ [id: number]: { approved: number; store: number } }>({});
  const [recv, setRecv] = useState<{ [id: number]: number }>({});
  const [busy, setBusy] = useState(false);

  const load = (): void => {
    api.get<RequestDetail>('requests/' + requestId).then(d => {
      setR(d);
      const h: any = {}, rc: any = {};
      d.items.forEach(i => {
        const appr = i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty;
        h[i.requestItemId] = { approved: appr, store: Math.min(appr, i.stockQty) };
        rc[i.requestItemId] = appr;
      });
      setHl(h); setRecv(rc);
    }).catch((e: Error) => setErr(e.message));
  };
  useEffect(() => { load(); }, [requestId]);
  useEffect(() => { if (me.roles.indexOf('HRAD') > -1) api.get<Vendor[]>('masters/vendors?active=true').then(v => { setVendors(v); if (v.length) setVendorId(v[0].vendorId); }).catch(() => undefined); }, []);

  const run = async (fn: () => Promise<any>, msg: string): Promise<void> => {
    setErr(undefined); setBusy(true);
    try { await fn(); toast(msg); setComment(''); load(); } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  if (!r) return err ? <Alert kind="error">{err}</Alert> : <span className="mut">Loading request...</span>;

  const mine = r.requestorEmail.toLowerCase() === me.email.toLowerCase();
  const isHrad = me.roles.indexOf('HRAD') > -1;
  const isAdmin = me.roles.indexOf('Admin') > -1;
  const hrLines = r.items.map(i => ({ requestItemId: i.requestItemId, approvedQty: hl[i.requestItemId].approved, issuedFromStockQty: hl[i.requestItemId].store }));
  const toOrder = hrLines.reduce((s, l) => s + Math.max(0, l.approvedQty - l.issuedFromStockQty), 0);
  const future: string[] = [];
  if (r.status === 'InReview' && r.currentStage) { CHAIN.slice(Math.max(0, CHAIN.indexOf(r.currentStage))).forEach(c => future.push(STAGE[c] + ' approval')); future.push('HRAD processing'); }
  else if (r.status === 'HRApproval') future.push('HRAD vendor order');
  const expected = (i: { approvedQty?: number; quantity: number }): number => i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty;
  const decide = (a: string, ok: string): void => {
    if (a !== 'Approve' && !comment.trim()) { toast('A comment is required'); return; }
    run(() => api.post('requests/' + r.requestId + '/action', { action: a, comments: comment }), ok);
  };
  const editable = mine && (r.status === 'Draft' || r.status === 'AmendRequired');

  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <div className="row"><Btn v="g" s onClick={() => go('list')}>{'\u2190'} Back</Btn><h1>{r.requestNo}</h1><StatusChip status={r.status} /></div>
      <div className="row" style={{ gap: 8 }}>
        <Btn v="g" onClick={() => api.download('requests/' + r.requestId + '/export', r.requestNo + '-items.xlsx').catch((e: Error) => setErr(e.message))}>Export items</Btn>
        {(isHrad || mine) && r.poNumber && <Btn v="g" onClick={() => api.download('hrad/' + r.requestId + '/pdf', r.poNumber + '.pdf').catch((e: Error) => setErr(e.message))}>PDF</Btn>}
      </div>
    </div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}

    <div className="row" style={{ alignItems: 'stretch' }}>
      <div className="card grow" style={{ flex: '2 1 460px' }}>
        <div className="row mut" style={{ gap: 24, marginBottom: 12 }}>
          <span>Requestor: <b style={{ color: 'var(--ink)' }}>{r.requestorName}</b></span><span>Dept: <b style={{ color: 'var(--ink)' }}>{r.departmentName}</b></span>
          <span>Date: <b style={{ color: 'var(--ink)' }}>{fmtDate(r.requestDate)}</b></span>
          {r.vendorName && <span>Vendor: <b style={{ color: 'var(--ink)' }}>{r.vendorName}</b></span>}
        </div>
        {r.remarks && <div className="mut" style={{ marginBottom: 10 }}>Remarks: {r.remarks}</div>}
        <div className="tw"><table>
          <thead><tr><th>Item</th><th>Unit</th><th>Rate</th><th>Qty</th><th>Approved</th><th>From store</th><th>To vendor</th><th>Received</th><th>Total</th><th>Remarks</th></tr></thead>
          <tbody>{r.items.map(i => (
            <tr key={i.requestItemId}><td>{i.itemName}</td><td>{i.unit}</td><td>{fmt(i.rate)}</td><td>{i.quantity}</td>
              <td>{i.approvedQty === null || i.approvedQty === undefined ? '\u2013' : i.approvedQty}</td><td>{i.issuedFromStockQty}</td><td>{i.orderedQty}</td><td>{i.receivedQty}</td>
              <td>{fmt(i.lineTotal)}</td><td>{i.remarks || ''}</td></tr>))}</tbody></table></div>
        <div style={{ textAlign: 'right', marginTop: 12, fontSize: 18 }}>Total <b>{fmt(r.totalAmount)}</b></div>
      </div>
      <div className="card grow">
        <h2>History</h2>
        {r.history.length === 0 && future.length === 0 && <span className="mut">No activity yet</span>}
        {r.history.map((h, i) => (
          <div key={i} className="st"><div className="dot" style={{ background: h.action === 'Reject' || h.action === 'Cancel' ? '#dc2626' : h.action === 'Amend' || h.action === 'Reorder' ? '#c2410c' : '#15803d' }} />
            <div><b>{h.action}</b> <span className="mut">({STAGE[h.stage] || h.stage})</span>
              <div className="mut">{h.actorName} {'\u00B7'} {fmtDate(h.actionDate)}{h.comments && <><br />{'\u201C'}{h.comments}{'\u201D'}</>}</div></div></div>))}
        {future.map((f, i) => (
          <div key={'f' + i} className="st"><div className="dot" style={{ background: i ? 'var(--line)' : '#2563eb' }} /><div><b className="mut">{f}</b><div className="mut">{i ? 'Upcoming' : 'Pending now'}</div></div></div>))}
      </div>
    </div>

    {r.canAct && (<div className="card">
      {r.delegatedFrom && <div className="note" style={{ marginBottom: 10 }}>You are acting as delegate for {r.delegatedFrom}. Your decision is recorded as {'\u201C'}on behalf of{'\u201D'}.</div>}
      <h2>Your decision {'\u00B7'} {STAGE[r.currentStage || '']}</h2>
      <textarea rows={3} style={{ width: '100%' }} placeholder="Comments (required for Reject or Ask to amend)" value={comment} onChange={e => setComment(e.target.value)} />
      <div className="row" style={{ marginTop: 10 }}>
        <Btn disabled={busy} onClick={() => decide('Approve', 'Approved')}>Approve</Btn>
        <Btn v="g" disabled={busy} onClick={() => decide('Amend', 'Sent back for amendment')}>Ask to amend</Btn>
        <Btn v="d" disabled={busy} onClick={() => decide('Reject', 'Rejected')}>Reject</Btn>
      </div></div>)}

    {isHrad && r.status === 'HRApproval' && (<div className="card">
      <h2>HRAD processing</h2>
      <div className="tw"><table>
        <thead><tr><th>Item</th><th>Requested</th><th>In store</th><th>Approved qty</th><th>Issue from store</th><th>To order</th></tr></thead>
        <tbody>{r.items.map(i => { const v = hl[i.requestItemId] || { approved: 0, store: 0 }; return (
          <tr key={i.requestItemId}><td>{i.itemName}</td><td>{i.quantity}</td><td>{i.stockQty}</td>
            <td><input type="number" min={0} max={i.quantity} value={v.approved} style={{ width: 90 }}
              onChange={e => setHl({ ...hl, [i.requestItemId]: { approved: Number(e.target.value) || 0, store: Math.min(v.store, Number(e.target.value) || 0) } })} /></td>
            <td><input type="number" min={0} value={v.store} style={{ width: 90 }}
              onChange={e => setHl({ ...hl, [i.requestItemId]: { approved: v.approved, store: Number(e.target.value) || 0 } })} /></td>
            <td><b>{Math.max(0, v.approved - v.store)}</b></td></tr>); })}</tbody></table></div>
      <div className="row" style={{ marginTop: 12 }}>
        {toOrder > 0 && <Field label="Vendor (needed when something must be ordered)"><select value={vendorId} onChange={e => setVendorId(Number(e.target.value))}>
          {vendors.map(v => <option key={v.vendorId} value={v.vendorId}>{v.vendorName}</option>)}</select></Field>}
        <Field label="Comments"><input value={comment} onChange={e => setComment(e.target.value)} /></Field>
      </div>
      <div className="row" style={{ marginTop: 10 }}>
        <Btn disabled={busy || (toOrder > 0 && !vendorId)} onClick={() => run(() => api.post('hrad/' + r.requestId + '/process', { vendorId: toOrder > 0 ? vendorId : null, comments: comment, lines: hrLines }), toOrder > 0 ? 'PO emailed to the vendor' : 'Issued from store, requestor notified')}>
          {toOrder > 0 ? 'Process request (send to vendor)' : 'Issue from store and hand over'}</Btn>
        <Btn v="g" disabled={busy} onClick={() => run(() => api.downloadPost('hrad/' + r.requestId + '/pdf-preview', { vendorId: vendorId || null, lines: hrLines }, 'PO-preview-' + r.requestNo + '.pdf'), 'PDF preview downloaded (not sent)')}>Preview PDF</Btn>
      </div></div>)}

    {isHrad && r.status === 'Ordered' && (<div className="card">
      <h2>Vendor order sent to {r.vendorName} ({r.poNumber})</h2>
      <div className="row">
        <Btn disabled={busy} onClick={() => run(() => api.post('hrad/' + r.requestId + '/deliver'), 'Requestor notified')}>Mark delivered and hand over</Btn>
        <Btn v="g" disabled={busy} onClick={() => run(() => api.post('hrad/' + r.requestId + '/resend-po'), 'Revised PO sent to the vendor')}>Resend PO to vendor</Btn>
      </div></div>)}

    {mine && r.status === 'Delivered' && (<div className="card">
      <h2>Verify received items</h2>
      <div className="tw"><table><thead><tr><th>Item</th><th>Expected</th><th>Received</th></tr></thead>
        <tbody>{r.items.map(i => (<tr key={i.requestItemId}><td>{i.itemName}</td><td>{expected(i)}</td>
          <td><input type="number" min={0} value={recv[i.requestItemId]} style={{ width: 90 }} onChange={e => setRecv({ ...recv, [i.requestItemId]: Math.max(0, Number(e.target.value) || 0) })} /></td></tr>))}</tbody></table></div>
      <Field label="Comment / query to HRAD" style={{ marginTop: 10 }}><input value={comment} onChange={e => setComment(e.target.value)} /></Field>
      <div className="row" style={{ marginTop: 10 }}>
        <Btn disabled={busy} onClick={() => run(() => api.post('requests/' + r.requestId + '/receive', { comments: comment, lines: r.items.map(i => ({ requestItemId: i.requestItemId, receivedQty: recv[i.requestItemId] })) }), 'Delivery verified')}>Confirm received</Btn>
        <Btn v="g" disabled={busy || !comment.trim()} onClick={() => run(() => api.post('requests/' + r.requestId + '/query', { text: comment }), 'Query emailed to HRAD')}>Raise query</Btn>
      </div>
      <div className="mut" style={{ marginTop: 6 }}>All received closes the request; less than expected partially closes it.</div></div>)}

    {editable && (<div className="card">
      <h2>{r.status === 'Draft' ? 'Draft' : 'Amend requested'}</h2>
      <div className="row"><Btn v="g" onClick={() => go('edit', r.requestId)}>Edit</Btn>
        <Btn disabled={busy} onClick={() => run(() => api.post('requests/' + r.requestId + '/submit'), 'Submitted for approval')}>{r.status === 'Draft' ? 'Submit' : 'Resubmit'}</Btn></div></div>)}

    {isHrad && <HradTools api={api} r={r} onChanged={m => { toast(m); setErr(undefined); load(); }} onError={m => setErr(m)} />}
    {(mine || isAdmin) && <CancelCard api={api} r={r} onChanged={m => { toast(m); setErr(undefined); load(); }} onError={m => setErr(m)} />}
  </>);
};
export default RequestDetailView;
