import * as React from 'react';
import { STATUS } from './ui';

const StatusChip: React.FC<{ status: string }> = ({ status }) => {
  const s = STATUS[status] || [status, '#6b7280'];
  return <span className="chip" style={{ background: s[1] }}>{s[0]}</span>;
};
export default StatusChip;
