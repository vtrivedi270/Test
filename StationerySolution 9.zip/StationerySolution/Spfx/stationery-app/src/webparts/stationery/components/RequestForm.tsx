import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { FormLine, Item, LineOut, Me, RequestDetail, RouteName } from '../models';
import { Alert, Btn, Field, toast } from './kit';
import { fmt } from './ui';
import LineImportPanel from './LineImportPanel';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; requestId?: number; }

const RequestForm: React.FC<Props> = ({ api, me, go, requestId }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [lines, setLines] = useState<FormLine[]>([{ itemId: 0, quantity: 1 }]);
  const [remarks, setRemarks] = useState('');
  const [err, setErr] = useState<string>();
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [status, setStatus] = useState('');
  const [no, setNo] = useState('');

  useEffect(() => {
    const p: Promise<any>[] = [api.get<Item[]>('masters/items?active=true').then(setItems)];
    if (requestId) p.push(api.get<RequestDetail>('requests/' + requestId).then(r => {
      setRemarks(r.remarks || ''); setStatus(r.status); setNo(r.requestNo);
      setLines(r.items.map(i => ({ itemId: i.itemId, quantity: i.quantity, remarks: i.remarks })));
    }));
    Promise.all(p).then(() => setReady(true)).catch((e: Error) => { setErr(e.message); setReady(true); });
  }, []);

  const find = (id: number): Item | undefined => items.filter(i => i.itemId === id)[0];
  const total = lines.reduce((s, l) => s + (find(l.itemId) ? find(l.itemId)!.rate * l.quantity : 0), 0);
  const upd = (idx: number, patch: Partial<FormLine>): void => setLines(lines.map((l, i) => i === idx ? { ...l, ...patch } : l));
  const pick = (idx: number, itemId: number): void => {
    if (lines.some((l, i) => i !== idx && l.itemId === itemId)) { toast('Item already added'); return; }
    upd(idx, { itemId: itemId });
  };

  /** Same rules as the server: item chosen, quantity 0.01 - 100000 with at most 2 decimals, no duplicates, remarks max 200, max 200 lines. */
  const validate = (): string | undefined => {
    if (lines.length === 0 || lines.length > 200) return 'A request needs between 1 and 200 lines';
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      if (!l.itemId) return 'Row ' + (i + 1) + ': select an item';
      if (!(l.quantity >= 0.01 && l.quantity <= 100000)) return 'Row ' + (i + 1) + ': quantity must be between 0.01 and 100000';
      if (Math.round(l.quantity * 100) / 100 !== l.quantity) return 'Row ' + (i + 1) + ': quantity can have at most 2 decimals';
      if ((l.remarks || '').length > 200) return 'Row ' + (i + 1) + ': remarks can be at most 200 characters';
    }
    const ids = lines.map(l => l.itemId);
    if (ids.some((x, i) => ids.indexOf(x) !== i)) return 'The same item appears more than once';
    return undefined;
  };

  const save = async (submit: boolean): Promise<void> => {
    setErr(undefined);
    const v = validate(); if (v) { setErr(v); return; }
    setBusy(true);
    try {
      const saved = await api.post<{ requestId: number }>('requests', { requestId: requestId, remarks: remarks, items: lines.map(l => ({ itemId: l.itemId, quantity: l.quantity, remarks: l.remarks })) });
      if (submit) await api.post('requests/' + saved.requestId + '/submit');
      toast(submit ? 'Submitted for approval' : 'Draft saved');
      go('detail', saved.requestId);
    } catch (e) { setErr((e as Error).message); setBusy(false); }
  };

  const exportExcel = async (): Promise<void> => {
    const valid = lines.filter(l => l.itemId && l.quantity > 0);
    if (valid.length === 0) { setErr('Add at least one item with a quantity before exporting'); return; }
    try { await api.downloadPost('requests/export-lines', { items: valid.map(l => ({ itemId: l.itemId, quantity: l.quantity, remarks: l.remarks })) }, 'request-lines.xlsx'); toast('Exported ' + valid.length + ' line(s)'); }
    catch (e) { setErr((e as Error).message); }
  };

  const applyImport = (imported: LineOut[], mode: 'replace' | 'add'): void => {
    const next: FormLine[] = mode === 'replace' ? [] : lines.filter(l => l.itemId).map(l => ({ ...l }));
    imported.forEach(o => {
      const ex = next.filter(l => l.itemId === o.itemId)[0];
      if (ex) { ex.quantity = Math.round((ex.quantity + o.quantity) * 100) / 100; if (o.remarks) ex.remarks = o.remarks; }
      else next.push({ itemId: o.itemId, quantity: o.quantity, remarks: o.remarks });
    });
    if (next.some(l => l.quantity > 100000)) { setErr('After adding, one quantity would exceed 100000. Nothing was changed.'); return; }
    if (next.length > 200) { setErr('A request can have at most 200 lines. Nothing was changed.'); return; }
    setLines(next.length ? next : [{ itemId: 0, quantity: 1 }]);
    setErr(undefined); toast(imported.length + ' line(s) applied to the request');
  };

  if (!ready) return <span className="mut">Loading...</span>;
  return (<>
    <h1>{requestId ? 'Edit ' + no + (status === 'Draft' ? ' (draft)' : '') : 'New stationery request'}</h1>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <h2>Requestor details</h2>
      <div className="row">
        {[['Requestor', me.fullName], ['Department', me.departmentName], ['Division', me.divisionName], ['Reporting manager', me.reportingManagerName || '\u2013'], ['Date', new Date().toLocaleDateString('en-GB')]].map(f => (
          <Field key={f[0]} label={f[0]}><input readOnly value={f[1]} /></Field>))}
      </div>
      <Field label="Remarks" style={{ marginTop: 12 }}><textarea rows={2} value={remarks} placeholder="Why do you need these items?" onChange={e => setRemarks(e.target.value)} /></Field>
    </div>
    <div className="card">
      <h2>Items</h2>
      <div className="tw"><table>
        <thead><tr><th>#</th><th>Item</th><th>Unit</th><th>Rate</th><th>Qty</th><th>Total</th><th>Remarks</th><th /></tr></thead>
        <tbody>{lines.map((l, x) => { const it = find(l.itemId); return (
          <tr key={x}>
            <td>{x + 1}</td>
            <td><select aria-label="Item" value={l.itemId} onChange={e => pick(x, Number(e.target.value))}>
              <option value={0}>Select item</option>{items.map(o => <option key={o.itemId} value={o.itemId}>{o.itemCode} {'\u2013'} {o.itemName}</option>)}</select></td>
            <td>{it ? it.unit : ''}</td><td>{it ? fmt(it.rate) : ''}</td>
            <td><input type="number" min={0.01} step={0.01} aria-label="Quantity" value={l.quantity} style={{ width: 84 }}
              onChange={e => upd(x, { quantity: Math.max(0, Number(e.target.value) || 0) })} /></td>
            <td><b>{it ? fmt(it.rate * l.quantity) : ''}</b></td>
            <td><input aria-label="Remarks" maxLength={200} value={l.remarks || ''} style={{ width: 140 }} onChange={e => upd(x, { remarks: e.target.value })} /></td>
            <td><Btn v="g" s aria-label="Remove row" onClick={() => setLines(lines.length > 1 ? lines.filter((_, i) => i !== x) : [{ itemId: 0, quantity: 1 }])}>{'\u2715'}</Btn></td>
          </tr>); })}</tbody></table></div>
      <div className="row" style={{ justifyContent: 'space-between', marginTop: 14 }}>
        <div className="row" style={{ gap: 8 }}>
          <Btn v="g" onClick={() => setLines([...lines, { itemId: 0, quantity: 1 }])}>+ Add item</Btn>
          <Btn v="g" onClick={() => setImportOpen(true)}>Import from Excel</Btn>
          <Btn v="g" onClick={exportExcel}>Export to Excel</Btn>
        </div>
        <div style={{ fontSize: 18 }}>Grand total <b>{fmt(total)}</b></div>
      </div>
    </div>
    <div className="row">
      <Btn v="g" disabled={busy} onClick={() => save(false)}>Save as draft</Btn>
      <Btn disabled={busy} onClick={() => save(true)}>{status === 'AmendRequired' ? 'Resubmit' : 'Submit for approval'}</Btn>
      <Btn v="g" onClick={() => go(requestId ? 'detail' : 'list', requestId)}>Cancel</Btn>
    </div>
    {importOpen && <LineImportPanel api={api} onClose={() => setImportOpen(false)} onApply={applyImport} />}
  </>);
};
export default RequestForm;
