import * as React from 'react';
import { useState } from 'react';
import { ApiService } from '../services/ApiService';
import { RequestDetail } from '../models';
import { Btn } from './kit';

interface Props { api: ApiService; r: RequestDetail; onChanged: (msg: string) => void; onError: (msg: string) => void; }

/** Requestor (or Admin) can withdraw a request until it has been ordered. */
const CancelCard: React.FC<Props> = ({ api, r, onChanged, onError }) => {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  if (['Draft', 'InReview', 'AmendRequired', 'HRApproval'].indexOf(r.status) < 0) return null;
  const cancel = async (): Promise<void> => {
    if (!reason.trim()) { onError('Enter a reason to cancel this request'); return; }
    if (!window.confirm('Cancel ' + r.requestNo + '? This cannot be undone.')) return;
    setBusy(true);
    try { await api.post('requests/' + r.requestId + '/cancel', { action: 'Cancel', comments: reason }); onChanged('Request cancelled'); }
    catch (e) { onError((e as Error).message); }
    setBusy(false);
  };
  return (
    <div className="card">
      <h2>Cancel request</h2>
      <div className="mut" style={{ marginBottom: 8 }}>Withdraw this request. It stays in history as Cancelled.</div>
      <input placeholder="Reason (required)" value={reason} onChange={e => setReason(e.target.value)} style={{ width: '100%', marginBottom: 10 }} />
      <Btn v="g" disabled={busy} style={{ color: 'var(--bad)' }} onClick={cancel}>Cancel this request</Btn>
    </div>);
};
export default CancelCard;
