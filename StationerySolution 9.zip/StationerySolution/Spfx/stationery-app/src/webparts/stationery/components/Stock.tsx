import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Alert, Btn, Chip, Field, Modal, Pager, toast } from './kit';
import { fmtDate } from './ui';

interface StockRow { itemId: number; itemCode: string; itemName: string; categoryName?: string; unit: string; stockQty: number; reorderLevel: number; isLow: boolean; isActive: boolean; }
interface Txn { txnDate: string; txnType: string; quantity: number; note?: string; createdBy?: string; requestNo?: string; }
type Mode = 'receipt' | 'adjust' | 'history';

/** Store stock: search, category and low-stock filters, paging, add stock, adjust, history. */
const Stock: React.FC<{ api: ApiService }> = ({ api }) => {
  const [rows, setRows] = useState<StockRow[]>([]);
  const [q, setQ] = useState('');
  const [cat, setCat] = useState('');
  const [low, setLow] = useState(false);
  const [page, setPage] = useState(1);
  const [size, setSize] = useState(5);
  const [err, setErr] = useState<string>();
  const [sel, setSel] = useState<StockRow>();
  const [mode, setMode] = useState<Mode>();
  const [qty, setQty] = useState('');
  const [note, setNote] = useState('');
  const [mErr, setMErr] = useState<string>();
  const [hist, setHist] = useState<Txn[]>([]);

  const load = (): void => { api.get<StockRow[]>('stock').then(setRows).catch((e: Error) => setErr(e.message)); };
  useEffect(load, []);

  const open = (r: StockRow, m: Mode): void => {
    setSel(r); setMode(m); setQty(m === 'adjust' ? String(r.stockQty) : ''); setNote(''); setMErr(undefined);
    if (m === 'history') api.get<Txn[]>('stock/' + r.itemId + '/history').then(setHist).catch((e: Error) => setMErr(e.message));
  };
  const save = async (): Promise<void> => {
    if (!sel) return;
    const n = Number(qty);
    if (mode === 'receipt' && !(n > 0)) { setMErr('Quantity must be above zero'); return; }
    if (mode === 'adjust' && (qty === '' || n < 0)) { setMErr('Enter the new stock quantity (0 or more)'); return; }
    if (mode === 'adjust' && !note.trim()) { setMErr('Reason is required'); return; }
    try {
      if (mode === 'receipt') await api.post('stock/receipt', { itemId: sel.itemId, quantity: n, note: note });
      else await api.post('stock/adjust', { itemId: sel.itemId, newQty: n, reason: note });
      setMode(undefined); toast('Stock updated'); load();
    } catch (e) { setMErr((e as Error).message); }
  };

  const cats = rows.map(r => r.categoryName || '').filter((c, i, a) => c && a.indexOf(c) === i);
  const filtered = rows.filter(r => (!low || r.isLow) && (!cat || r.categoryName === cat) && (!q || (r.itemName + r.itemCode).toLowerCase().indexOf(q.toLowerCase()) > -1));
  const shown = filtered.slice((page - 1) * size, page * size);

  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <h1>Store stock</h1>
      <div className="row">
        <input placeholder="Search item" aria-label="Search item" value={q} onChange={e => { setQ(e.target.value); setPage(1); }} />
        <select aria-label="Category" value={cat} onChange={e => { setCat(e.target.value); setPage(1); }}><option value="">All categories</option>{cats.map(c => <option key={c}>{c}</option>)}</select>
        <Btn v="g" onClick={() => { setLow(!low); setPage(1); }}>{low ? 'Showing low stock' : 'Low stock only'}</Btn>
      </div>
    </div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    <div className="card">
      <div className="tw"><table>
        <thead><tr><th>Code</th><th>Item</th><th>Category</th><th>In stock</th><th>Reorder</th><th>Status</th><th /></tr></thead>
        <tbody>
          {shown.length === 0 && <tr><td colSpan={7} className="mut">No items.</td></tr>}
          {shown.map(r => (
            <tr key={r.itemId} style={{ opacity: r.isActive ? 1 : 0.5 }}>
              <td>{r.itemCode}</td><td><b>{r.itemName}</b></td><td>{r.categoryName || '\u2013'}</td><td>{r.stockQty} {r.unit}</td><td>{r.reorderLevel}</td>
              <td><Chip bg={r.isLow ? '#dc2626' : '#15803d'}>{r.isLow ? 'Low' : 'OK'}</Chip></td>
              <td><div className="row" style={{ gap: 6 }}><Btn s onClick={() => open(r, 'receipt')}>Add stock</Btn><Btn v="g" s onClick={() => open(r, 'adjust')}>Adjust</Btn><Btn v="g" s onClick={() => open(r, 'history')}>History</Btn></div></td>
            </tr>))}
        </tbody></table></div>
      <Pager page={page} total={filtered.length} pageSize={size} onPage={setPage} onSize={n => { setSize(n); setPage(1); }} />
    </div>

    {sel && mode && mode !== 'history' && (
      <Modal onClose={() => setMode(undefined)}>
        <h2>{sel.itemName}</h2>
        <div className="mut">Current stock: <b>{sel.stockQty} {sel.unit}</b></div>
        {mErr && <Alert kind="error" style={{ marginTop: 10 }}>{mErr}</Alert>}
        <Field label={mode === 'receipt' ? 'Quantity received' : 'New stock quantity'} style={{ marginTop: 10 }}><input type="number" min={0} value={qty} onChange={e => setQty(e.target.value)} /></Field>
        <Field label={mode === 'receipt' ? 'Note (supplier / bill no)' : 'Reason (required)'} style={{ marginTop: 10 }}><input value={note} onChange={e => setNote(e.target.value)} /></Field>
        <div className="row" style={{ marginTop: 12 }}><Btn onClick={save}>Save</Btn><Btn v="g" onClick={() => setMode(undefined)}>Cancel</Btn></div>
      </Modal>)}
    {sel && mode === 'history' && (
      <Modal onClose={() => setMode(undefined)}>
        <h2>{sel.itemName} {'\u00B7'} movements (last 50)</h2>
        {mErr && <Alert kind="error">{mErr}</Alert>}
        <table><thead><tr><th>Date</th><th>Type</th><th>Qty</th><th>Note / request</th></tr></thead>
          <tbody>{hist.length === 0 && <tr><td colSpan={4} className="mut">No movements yet.</td></tr>}
            {hist.map((t, i) => (<tr key={i}><td>{fmtDate(t.txnDate)}</td><td>{t.txnType}</td>
              <td style={{ color: t.quantity < 0 || t.txnType === 'Issue' ? '#dc2626' : '#15803d' }}>{t.txnType === 'Issue' ? '-' : t.quantity > 0 ? '+' : ''}{t.quantity}</td>
              <td>{t.requestNo || t.note || '\u2013'}</td></tr>))}</tbody></table>
        <Btn style={{ marginTop: 12 }} onClick={() => setMode(undefined)}>Close</Btn>
      </Modal>)}
  </>);
};
export default Stock;
