import * as React from 'react';
import { useEffect, useState } from 'react';
import { ApiService } from '../services/ApiService';
import { Me, RouteName } from '../models';
import { Alert, Btn, Chip, toast } from './kit';
import { fmt } from './ui';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; }

const Bars: React.FC<{ data: any[]; label: string; value: string; money?: boolean }> = ({ data, label, value }) => {
  const max = Math.max(1, ...data.map(d => d[value]));
  return (<div>
    {data.length === 0 && <span className="mut">No data</span>}
    {data.map((d, i) => (
      <div key={i} className="row" style={{ flexWrap: 'nowrap', marginBottom: 10 }}>
        <span className="mut" style={{ width: 110, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{d[label]}</span>
        <div className="bar" style={{ width: Math.max(4, Math.round(d[value] / max * 240)), maxWidth: '55%' }} />
        <b>{fmt(d[value])}</b>
      </div>))}
  </div>);
};

const Dashboard: React.FC<Props> = ({ api, me, go }) => {
  const priv = me.roles.indexOf('HRAD') > -1 || me.roles.indexOf('Admin') > -1;
  const [from, setFrom] = useState(new Date().getFullYear() + '-01-01');
  const [to, setTo] = useState(new Date().toISOString().slice(0, 10));
  const [dept, setDept] = useState(0);
  const [depts, setDepts] = useState<any[]>([]);
  const [d, setD] = useState<any>();
  const [err, setErr] = useState<string>();

  const qs = (): string => 'from=' + from + '&to=' + to + (dept ? '&deptId=' + dept : '');
  const load = async (): Promise<void> => {
    try {
      const q = qs();
      const r = await Promise.all([api.get<any>('dashboard/summary?' + q), api.get<any[]>('dashboard/monthly?' + q), api.get<any[]>('dashboard/by-department?' + q),
        api.get<any[]>('dashboard/by-item?' + q), api.get<any[]>('dashboard/store')]);
      setD({ sum: r[0], monthly: r[1], dept: r[2], item: r[3], store: r[4] }); setErr(undefined);
    } catch (e) { setErr((e as Error).message); }
  };
  useEffect(() => { if (priv) api.get<any[]>('masters/departments?active=true').then(setDepts).catch(() => undefined); load(); }, []);

  const K = d ? [['Total requests', d.sum.totalRequests, '#2b8ee0'], ['Waiting for me', d.sum.pending, '#f59e0b'], ['Total cost', fmt(d.sum.totalCost), '#10b981'], ['Low-stock items', d.sum.lowStock, '#ef4444']] : [];
  const maxM = d ? Math.max(1, ...d.monthly.map((m: any) => m.totalCost)) : 1;
  return (<>
    <div className="row" style={{ justifyContent: 'space-between' }}>
      <h1>Dashboard</h1>
      <div className="row">
        <input type="date" aria-label="From" value={from} onChange={e => setFrom(e.target.value)} />
        <input type="date" aria-label="To" value={to} onChange={e => setTo(e.target.value)} />
        {priv && <select aria-label="Department" value={dept} onChange={e => setDept(Number(e.target.value))}>
          <option value={0}>All departments</option>{depts.map(x => <option key={x.departmentId} value={x.departmentId}>{x.departmentName}</option>)}</select>}
        <Btn v="g" onClick={load}>Apply</Btn>
        <Btn v="g" onClick={() => api.download('reports/export?' + qs(), 'stationery-report.xlsx').then(() => toast('Excel report downloaded')).catch((e: Error) => setErr(e.message))}>Export Excel</Btn>
      </div>
    </div>
    {err && <Alert kind="error" onClose={() => setErr(undefined)}>{err}</Alert>}
    {!d && !err && <span className="mut">Loading...</span>}
    {d && (<>
      <div className="row">{K.map((k, i) => (
        <div key={i} className="card kpi"><i style={{ background: k[2] as string }} /><span className="mut">{k[0]}</span><b>{k[1]}</b></div>))}</div>
      <div className="row" style={{ alignItems: 'stretch' }}>
        <div className="card grow"><h2>Cost by department</h2><Bars data={d.dept} label="departmentName" value="totalCost" /></div>
        <div className="card grow"><h2>Monthly cost</h2>
          <div className="cols">{d.monthly.length === 0 ? <span className="mut">No data</span> : d.monthly.map((m: any) => (
            <div key={m.month}><b style={{ fontSize: 11 }}>{fmt(m.totalCost)}</b><span style={{ height: Math.max(4, m.totalCost / maxM * 130) }} /><small className="mut">{m.month}</small></div>))}</div></div>
      </div>
      <div className="row" style={{ alignItems: 'stretch' }}>
        <div className="card grow"><h2>Top items by cost</h2><Bars data={d.item} label="itemName" value="totalCost" /></div>
        <div className="card grow">
          <div className="row" style={{ justifyContent: 'space-between' }}><h2 style={{ margin: 0 }}>Store availability</h2>{priv && <Btn v="g" s onClick={() => go('stock')}>Open stock</Btn>}</div>
          <div className="tw"><table><thead><tr><th>Item</th><th>In stock</th><th>Reorder at</th><th /></tr></thead>
            <tbody>{d.store.map((s: any) => (<tr key={s.itemId}><td>{s.itemName}</td><td>{s.stockQty} {s.unit}</td><td>{s.reorderLevel}</td>
              <td><Chip bg={s.isLow ? '#dc2626' : '#15803d'}>{s.isLow ? 'Low' : 'OK'}</Chip></td></tr>))}</tbody></table></div>
        </div>
      </div>
    </>)}
  </>);
};
export default Dashboard;
