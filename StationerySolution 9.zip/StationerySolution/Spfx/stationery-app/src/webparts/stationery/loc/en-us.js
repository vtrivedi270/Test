define([], function () {
  return {
    "PropertyPaneDescription": "Stationery Hub settings",
    "BasicGroupName": "API connection",
    "ApiBaseUrlFieldLabel": "API base URL (e.g. https://host/api)",
    "ApiResourceFieldLabel": "API App ID URI (leave empty for local dev mode)",
    "ScreenPercentFieldLabel": "Width: % of the screen (90 = covers 90% of the page width, 100 = full width)"
  };
});
