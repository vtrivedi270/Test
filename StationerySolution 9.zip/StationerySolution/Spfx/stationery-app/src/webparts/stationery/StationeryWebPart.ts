import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration, PropertyPaneSlider, PropertyPaneTextField } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import * as strings from 'StationeryWebPartStrings';
import App from './components/App';
import { ApiService } from './services/ApiService';
import { injectStyles } from './styles/shStyles';

export interface IStationeryWebPartProps {
  apiBaseUrl: string;
  apiResource: string;
  screenPercent: number;
}

export default class StationeryWebPart extends BaseClientSideWebPart<IStationeryWebPartProps> {
  public render(): void {
    injectStyles();
    const api = new ApiService(this.context, this.properties.apiBaseUrl, this.properties.apiResource);
    ReactDom.render(React.createElement(App, { api, screenPercent: this.properties.screenPercent === undefined ? 90 : this.properties.screenPercent }), this.domElement);
  }

  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('1.0'); }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [{
        header: { description: strings.PropertyPaneDescription },
        groups: [{
          groupName: strings.BasicGroupName,
          groupFields: [
            PropertyPaneTextField('apiBaseUrl', { label: strings.ApiBaseUrlFieldLabel }),
            PropertyPaneTextField('apiResource', { label: strings.ApiResourceFieldLabel }),
            PropertyPaneSlider('screenPercent', { label: strings.ScreenPercentFieldLabel, min: 50, max: 100, step: 5, showValue: true })
          ]
        }]
      }]
    };
  }
}
