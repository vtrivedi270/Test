using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

/// <summary>E-mail log for administrators: see failures and retry manually.</summary>
[Authorize(Roles = "Admin"), ApiController, Route("api/emails")]
public class EmailsController(AppDbContext db, EmailService mail, PdfService pdf) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List(string? status, int page = 1, int pageSize = 25)
    {
        var q = db.EmailLogs.AsNoTracking().AsQueryable();
        if (!string.IsNullOrEmpty(status)) q = q.Where(x => x.Status == status);
        var total = await q.CountAsync();
        var rows = await q.OrderByDescending(x => x.EmailLogId).Skip((Math.Max(page, 1) - 1) * pageSize).Take(pageSize)
            .Select(x => new { x.EmailLogId, x.RequestId, x.ToEmail, x.Subject, x.Status, x.ErrorMessage, x.RetryCount, x.CreatedAt, x.SentAt }).ToListAsync();
        return Ok(new { total, rows, smtpConfigured = mail.SmtpConfigured });
    }

    [HttpPost("{id:long}/retry")]
    public async Task<IActionResult> Retry(long id)
    {
        if (!mail.SmtpConfigured) throw new InvalidOperationException("SMTP is not configured (Smtp:Host is empty)");
        var m = await db.EmailLogs.FindAsync(id) ?? throw new InvalidOperationException("Mail not found");
        m.RetryCount = 0;
        await mail.RetryOneAsync(m, pdf);
        return Ok(new { m.Status, m.ErrorMessage });
    }
}
