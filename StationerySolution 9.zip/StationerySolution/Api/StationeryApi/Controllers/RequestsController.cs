using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[Authorize, ApiController, Route("api/requests")]
public class RequestsController(AppDbContext db, CurrentUser user, WorkflowService wf, RequestService rs, EmailService mail) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List([FromQuery] ListFilter f)
    {
        var me = await user.GetAsync();
        var priv = me.Role is "HRAD" or "Admin";
        var today = DateTime.Today;
        var q = db.RequestHeaders.AsNoTracking().AsQueryable();
        switch (f.View ?? "mine")
        {
            case "mine": q = q.Where(x => x.RequestorId == me.EmployeeId); break;
            case "pending":
                if (me.Role == "HRAD") q = q.Where(x => x.Status == "HRApproval" || x.Status == "Ordered" || x.Status == "PartialClosed");
                else q = q.Where(x => (x.Status == "InReview" && (x.CurrentApproverId == me.EmployeeId
                        || db.Delegations.Any(d => d.ToEmployeeId == me.EmployeeId && d.IsActive && d.FromEmployeeId == x.CurrentApproverId && d.StartDate <= today && d.EndDate >= today)))
                    || (x.RequestorId == me.EmployeeId && (x.Status == "Delivered" || x.Status == "AmendRequired" || x.Status == "Draft")));
                break;
            default:
                if (!priv) q = q.Where(x => x.RequestorId == me.EmployeeId || x.CurrentApproverId == me.EmployeeId || x.History.Any(h => h.ActorId == me.EmployeeId));
                break;
        }
        if (!string.IsNullOrEmpty(f.Status)) q = q.Where(x => x.Status == f.Status);
        if (f.From != null) q = q.Where(x => x.RequestDate >= f.From);
        if (f.To != null) q = q.Where(x => x.RequestDate <= f.To);
        if (f.DeptId != null) q = q.Where(x => x.DepartmentId == f.DeptId);
        if (!string.IsNullOrWhiteSpace(f.Search)) q = q.Where(x => x.RequestNo.Contains(f.Search) || x.Requestor.FullName.Contains(f.Search));
        var total = await q.CountAsync();
        var rows = await q.OrderByDescending(x => x.RequestId).Skip((Math.Max(f.Page, 1) - 1) * f.PageSize).Take(f.PageSize)
            .Select(x => new
            {
                IsMine = x.RequestorId == me.EmployeeId, x.RequestId, x.RequestNo, x.RequestDate, x.RequestorId, RequestorName = x.Requestor.FullName,
                DepartmentName = x.Department!.DepartmentName, x.TotalAmount, x.Status, x.CurrentStage,
                CurrentApproverName = x.CurrentApprover != null ? x.CurrentApprover.FullName : null
            }).ToListAsync();
        return Ok(new { total, rows });
    }

    // ---------- Excel: requestor line items ----------
    /// <summary>Blank template (ItemCode, Quantity, Remarks) plus a sheet that lists all active items.</summary>
    [HttpGet("lines-template")]
    public async Task<IActionResult> LinesTemplate([FromServices] ImportService imp) =>
        File(await imp.LinesTemplateAsync(), ImportService.Xlsx, "request-lines-template.xlsx");

    /// <summary>Validate an uploaded .xlsx of line items. Nothing is saved; the screen applies the valid lines to the form.</summary>
    [HttpPost("import-lines"), RequestSizeLimit(6 * 1024 * 1024)]
    public async Task<IActionResult> ImportLines(IFormFile file, [FromServices] ImportService imp) => Ok(await imp.ValidateLinesAsync(file));

    /// <summary>Export the lines currently on the entry form (works for unsaved requests).</summary>
    [HttpPost("export-lines")]
    public async Task<IActionResult> ExportLines(ExportLinesDto dto)
    {
        if (dto.Items == null || dto.Items.Count == 0) throw new InvalidOperationException("There are no lines to export");
        var ids = dto.Items.Select(i => i.ItemId).ToList();
        var items = await db.Items.AsNoTracking().Where(i => ids.Contains(i.ItemId)).ToDictionaryAsync(i => i.ItemId);
        var lines = dto.Items.Where(i => items.ContainsKey(i.ItemId)).Select(i =>
            (items[i.ItemId].ItemCode, items[i.ItemId].ItemName, items[i.ItemId].Unit, items[i.ItemId].Rate, i.Quantity, i.Remarks, (decimal?)null, (decimal?)null, (decimal?)null));
        return File(ImportService.LinesExport(lines, false), ImportService.Xlsx, "request-lines.xlsx");
    }

    /// <summary>Export the line items of a saved request (same access rules as viewing it).</summary>
    [HttpGet("{id:int}/export")]
    public async Task<IActionResult> ExportRequest(int id)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.AsNoTracking().Include(x => x.Items).ThenInclude(i => i.Item).Include(x => x.History)
            .FirstOrDefaultAsync(x => x.RequestId == id) ?? throw new InvalidOperationException("Request not found");
        var principals = await Delegations.PrincipalsAsync(db, me.EmployeeId);
        var allowed = me.Role is "HRAD" or "Admin" || h.RequestorId == me.EmployeeId
            || (h.CurrentApproverId != null && principals.Contains(h.CurrentApproverId.Value)) || h.History.Any(a => a.ActorId == me.EmployeeId);
        if (!allowed) throw new UnauthorizedAccessException("You cannot view this request");
        var lines = h.Items.Select(i => (i.Item.ItemCode, i.Item.ItemName, i.Unit, i.Rate, i.Quantity, i.Remarks, i.ApprovedQty, (decimal?)i.IssuedFromStockQty, (decimal?)i.ReceivedQty));
        return File(ImportService.LinesExport(lines, true), ImportService.Xlsx, h.RequestNo + "-items.xlsx");
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.AsNoTracking().AsSplitQuery()
            .Include(x => x.Requestor).Include(x => x.CurrentApprover).Include(x => x.Vendor).Include(x => x.Department)
            .Include(x => x.Items).ThenInclude(i => i.Item).Include(x => x.History).ThenInclude(a => a.Actor)
            .FirstOrDefaultAsync(x => x.RequestId == id);
        if (h == null) return NotFound();
        var priv = me.Role is "HRAD" or "Admin";
        var delegator = h.Status == "InReview" ? await wf.DelegatorAsync(h, me) : null;
        var canAct = h.Status == "InReview" && h.RequestorId != me.EmployeeId && (h.CurrentApproverId == me.EmployeeId || delegator != null);
        if (!priv && h.RequestorId != me.EmployeeId && h.CurrentApproverId != me.EmployeeId && delegator == null && !h.History.Any(a => a.ActorId == me.EmployeeId))
            return StatusCode(403, new { error = "You cannot view this request" });
        return Ok(new
        {
            CanAct = canAct, DelegatedFrom = delegator?.FullName,
            h.RequestId, h.RequestNo, h.RequestDate, RequestorName = h.Requestor.FullName, RequestorEmail = h.Requestor.Email,
            DepartmentName = h.Department?.DepartmentName, h.Remarks, h.TotalAmount, h.Status, h.CurrentStage,
            CurrentApproverEmail = h.CurrentApprover?.Email, CurrentApproverName = h.CurrentApprover?.FullName,
            VendorName = h.Vendor?.VendorName, h.PONumber,
            Items = h.Items.Select(i => new { i.RequestItemId, i.ItemId, ItemName = i.Item.ItemName, i.Unit, i.Rate, i.Quantity, i.ApprovedQty, i.IssuedFromStockQty, i.OrderedQty, i.ReceivedQty, StockQty = i.Item.StockQty, i.LineTotal, i.Remarks }),
            History = h.History.OrderBy(a => a.ActionDate).Select(a => new { a.Stage, a.Action, ActorName = a.Actor.FullName, a.Comments, a.ActionDate })
        });
    }

    [HttpPost]
    public async Task<IActionResult> Save(RequestSaveDto dto)
    {
        var me = await user.GetAsync();
        var h = await rs.SaveAsync(dto, me);
        return Ok(new { h.RequestId, h.RequestNo });
    }

    [HttpPost("{id:int}/submit")]
    public async Task<IActionResult> Submit(int id)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        await wf.SubmitAsync(h, me);
        return Ok(new { h.Status });
    }

    [HttpPost("{id:int}/action")]
    public async Task<IActionResult> Act(int id, ActionDto dto)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        await wf.ActAsync(h, me, dto);
        return Ok(new { h.Status, h.CurrentStage });
    }

    /// <summary>Requestor permanently deletes their own Draft.</summary>
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> DeleteDraft(int id)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.Include(x => x.Items).Include(x => x.History).FirstOrDefaultAsync(x => x.RequestId == id) ?? throw new InvalidOperationException("Request not found");
        if (h.RequestorId != me.EmployeeId) throw new UnauthorizedAccessException("Only the requestor can delete this draft");
        if (h.Status != "Draft") throw new InvalidOperationException("Only drafts can be deleted. Use Cancel for submitted requests.");
        db.Audit("RequestHeader", h.RequestId.ToString(), "DeleteDraft", h.RequestNo, null, me.Email);
        db.RequestHeaders.Remove(h);
        await db.SaveChangesAsync();
        return NoContent();
    }

    /// <summary>Requestor (or Admin) withdraws a request that has not been ordered yet.</summary>
    [HttpPost("{id:int}/cancel")]
    public async Task<IActionResult> Cancel(int id, ActionDto dto)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        if (h.RequestorId != me.EmployeeId && me.Role != "Admin") throw new UnauthorizedAccessException("Only the requestor can cancel this request");
        if (h.Status is not ("Draft" or "InReview" or "AmendRequired" or "HRApproval"))
            throw new InvalidOperationException("Only requests that are not yet ordered can be cancelled");
        if (string.IsNullOrWhiteSpace(dto.Comments)) throw new InvalidOperationException("Reason is required");
        var notify = new List<string>();
        if (h.Status == "InReview" && h.CurrentApproverId != null) { var a = await db.Employees.FindAsync(h.CurrentApproverId); if (a != null) notify.Add(a.Email); }
        if (h.Status == "HRApproval") notify.AddRange(await db.Employees.Where(e => e.Role == "HRAD" && e.IsActive).Select(e => e.Email).ToListAsync());
        h.Status = "Cancelled"; h.CurrentStage = null; h.CurrentApproverId = null; h.ClosedAt = DateTime.UtcNow;
        wf.AddHistory(h, "Requestor", "Cancel", me, dto.Comments);
        await db.SaveChangesAsync();
        foreach (var e in notify.Distinct()) await mail.QueueAsync(h.RequestId, e, $"[Stationery] {h.RequestNo}: Cancelled", $"Request cancelled by {me.FullName}. Reason: {dto.Comments}");
        return Ok(new { h.Status });
    }

    [HttpPost("{id:int}/receive")]
    public async Task<IActionResult> Receive(int id, ReceiveDto dto)
    {
        var me = await user.GetAsync();
        var h = await db.RequestHeaders.Include(x => x.Items).FirstOrDefaultAsync(x => x.RequestId == id) ?? throw new InvalidOperationException("Request not found");
        if (h.RequestorId != me.EmployeeId) throw new UnauthorizedAccessException("Only the requestor can verify delivery");
        if (h.Status != "Delivered") throw new InvalidOperationException("Request is not awaiting your verification");
        foreach (var l in dto.Lines)
        {
            var ri = h.Items.FirstOrDefault(x => x.RequestItemId == l.RequestItemId) ?? throw new InvalidOperationException("Invalid line");
            if (l.ReceivedQty < 0) throw new InvalidOperationException("Received quantity cannot be negative");
            ri.ReceivedQty = l.ReceivedQty;
        }
        var all = h.Items.All(i => i.ReceivedQty >= (i.ApprovedQty ?? i.Quantity));
        h.Status = all ? "Closed" : "PartialClosed"; h.ClosedAt = DateTime.UtcNow; h.CurrentStage = null; h.CurrentApproverId = null;
        wf.AddHistory(h, "Requestor", all ? "Close" : "PartialClose", me, dto.Comments);
        await db.SaveChangesAsync();
        var hrad = await db.Employees.Where(e => e.Role == "HRAD" && e.IsActive).Select(e => e.Email).ToListAsync();
        foreach (var e in hrad) await mail.QueueAsync(h.RequestId, e, $"[Stationery] {h.RequestNo}: {h.Status}", $"Requestor verified delivery. Status: {h.Status}.");
        return Ok(new { h.Status });
    }

    [HttpPost("{id:int}/query")]
    public async Task<IActionResult> Query(int id, QueryDto dto)
    {
        var me = await user.GetAsync();
        if (string.IsNullOrWhiteSpace(dto.Text)) throw new InvalidOperationException("Enter your query");
        var h = await db.RequestHeaders.FindAsync(id) ?? throw new InvalidOperationException("Request not found");
        if (h.RequestorId != me.EmployeeId) throw new UnauthorizedAccessException();
        wf.AddHistory(h, "Requestor", "Query", me, dto.Text);
        await db.SaveChangesAsync();
        var hrad = await db.Employees.Where(e => e.Role == "HRAD" && e.IsActive).Select(e => e.Email).ToListAsync();
        foreach (var e in hrad) await mail.QueueAsync(h.RequestId, e, $"[Stationery] {h.RequestNo}: Query from requestor", dto.Text);
        return Ok();
    }
}
