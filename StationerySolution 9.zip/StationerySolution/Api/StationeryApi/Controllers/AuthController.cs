using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[ApiController, Route("api/auth")]
public class AuthController(AppDbContext db, TokenService tokens, IConfiguration cfg) : ControllerBase
{
    /// <summary>Production: exchange a valid Entra ID (Azure AD) access token for the app JWT that carries role claims.</summary>
    [HttpPost("login"), Authorize(AuthenticationSchemes = "Entra")]
    public async Task<IActionResult> Login()
    {
        var u = User;
        var email = (u.FindFirst("preferred_username")?.Value ?? u.FindFirst("upn")?.Value ?? u.FindFirst(ClaimTypes.Upn)?.Value
                     ?? u.FindFirst("email")?.Value ?? "").ToLowerInvariant();
        return await Issue(email, "entra");
    }

    /// <summary>Development only (Auth:AllowDevLogin=true): get a JWT for an employee e-mail without Entra ID.</summary>
    [HttpPost("dev-login"), AllowAnonymous]
    public async Task<IActionResult> DevLogin(DevLoginDto dto)
    {
        if (!cfg.GetValue<bool>("Auth:AllowDevLogin")) return NotFound();
        return await Issue((dto.Email ?? "").Trim().ToLowerInvariant(), "dev");
    }

    /// <summary>Development only: people the "View as" dropdown can switch to. Returns 404 unless Auth:AllowDevLogin=true.</summary>
    [HttpGet("dev-users"), AllowAnonymous]
    public async Task<IActionResult> DevUsers()
    {
        if (!cfg.GetValue<bool>("Auth:AllowDevLogin")) return NotFound();
        var list = new List<object>();
        foreach (var e in await db.Employees.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.FullName).ToListAsync())
            list.Add(new { e.EmployeeId, e.FullName, e.Email, Persona = await tokens.PersonaAsync(e) });
        return Ok(list);
    }

    private async Task<IActionResult> Issue(string email, string via)
    {
        var e = await db.Employees.FirstOrDefaultAsync(x => x.Email.ToLower() == email && x.IsActive);
        if (e == null) return StatusCode(403, new { error = "You are not registered in the Employee master: " + email });
        var (token, expires, roles) = await tokens.IssueAsync(e);
        db.AuditLogs.Add(new AuditLog { EntityName = "Auth", EntityId = e.EmployeeId.ToString(), Action = "Login-" + via, UserEmail = e.Email });
        await db.SaveChangesAsync();
        return Ok(new { token, expiresAt = expires, user = new { e.EmployeeId, e.FullName, e.Email, roles } });
    }
}
