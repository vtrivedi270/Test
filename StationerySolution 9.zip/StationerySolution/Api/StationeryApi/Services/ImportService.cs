using System.Globalization;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public record ImportError(int Row, string Column, string Value, string Message);
public record LineOut(int Row, int ItemId, string ItemCode, string ItemName, string Unit, decimal Rate, decimal Quantity, string? Remarks);

public class PlanRow
{
    public int Row { get; set; }
    public bool Update { get; set; }
    public string[] Show { get; set; } = [];
    [JsonIgnore] public object? Cur { get; set; }
    [JsonIgnore] public object Rec { get; set; } = null!;
}

public class ImportReport
{
    public string Entity { get; set; } = "";
    public string FileName { get; set; } = "";
    public int Total { get; set; }
    public List<ImportError> Errors { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
    public List<PlanRow> Plan { get; set; } = new();
    public List<LineOut>? Lines { get; set; }
    public bool Applied { get; set; }
    public int Created { get; set; }
    public int Updated { get; set; }
    public string Message { get; set; } = "";
}

/// <summary>Excel (.xlsx) import / export. Rules: header in row 1 of the first sheet (a sheet called "Data" wins), column names are
/// matched ignoring case / spaces, every problem is reported with row, column, value and message, and a commit is
/// all-or-nothing (a single error blocks the whole import).</summary>
public class ImportService(AppDbContext db, CurrentUser user)
{
    public const long MaxBytes = 5 * 1024 * 1024;
    public const string Xlsx = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static readonly string[] Entities = ["items", "categories", "vendors", "divisions", "departments", "employees"];

    private static readonly Regex EmailRx = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$", RegexOptions.Compiled);
    private static readonly Regex GstRx = new(@"^[0-9A-Za-z]{15}$", RegexOptions.Compiled);
    private static readonly string[] Roles = ["Requestor", "HRAD", "Admin", "ReportingManager", "DeptHead", "DivHead"];

    private sealed record SheetDef(string[] Req, string[] Opt, int MaxRows, string Rules, string[]? Silent = null)
    { public string[] Known => Req.Concat(Opt).ToArray(); }

    private static readonly Dictionary<string, SheetDef> Defs = new()
    {
        ["items"] = new(["ItemCode", "ItemName", "Unit", "Rate"], ["Category", "StockQty", "ReorderLevel", "Active"], 1000,
            "ItemCode unique (max 30). Rate 0 or more, max 2 decimals. Category must already exist. StockQty is used for NEW items only (existing stock changes via Store stock). Active = Y or N (blank = Y)."),
        ["categories"] = new(["CategoryName"], ["Active"], 1000, "CategoryName unique (max 100). Active = Y or N."),
        ["vendors"] = new(["VendorName", "Email"], ["ContactPerson", "Phone", "Address", "GSTNo", "Active"], 1000,
            "VendorName unique. Valid e-mail. GSTNo = 15 letters / digits."),
        ["divisions"] = new(["DivisionName"], ["DivisionHead", "Active"], 1000,
            "DivisionName unique. DivisionHead = code, e-mail or full name of an existing employee."),
        ["departments"] = new(["DepartmentName", "Division"], ["DepartmentHead", "Active"], 1000,
            "Division must already exist. Name + division unique. DepartmentHead = code, e-mail or full name of an existing employee."),
        ["employees"] = new(["EmployeeCode", "FullName", "Email", "Department", "Role"], ["ReportingManager", "Active"], 1000,
            "Code and e-mail unique. Department must exist. Role = Requestor, HRAD, Admin, ReportingManager, DeptHead or DivHead. ReportingManager = code or e-mail (existing or in this file), no loops; blank keeps the current manager.")
    };
    private static readonly SheetDef LineDef = new(["ItemCode", "Quantity"], ["Remarks", "ItemName", "Unit", "Rate", "LineTotal", "Approved", "FromStore", "Received"], 200,
        "ItemCode must be an active item. Quantity 0.01 to 100000, max 2 decimals. No duplicate items. Max 200 lines.",
        ["ItemName", "Unit", "Rate", "LineTotal", "Approved", "FromStore", "Received"]);

    // =====================================================================  READING
    private sealed record Row(int N, Dictionary<string, string> V);

    public static MemoryStream Open(IFormFile? f)
    {
        if (f == null || f.Length == 0) throw new InvalidOperationException("Choose an .xlsx file to upload");
        if (!string.Equals(Path.GetExtension(f.FileName), ".xlsx", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Only .xlsx files are supported");
        if (f.Length > MaxBytes) throw new InvalidOperationException("The file is larger than 5 MB");
        var ms = new MemoryStream(); f.CopyTo(ms); ms.Position = 0; return ms;
    }

    private static string Nrm(string s) => Regex.Replace(s.ToLowerInvariant(), "[^a-z0-9]", "");

    private static string Text(IXLCell c)
    {
        if (c.IsEmpty()) return "";
        if (c.DataType == XLDataType.Number) return c.GetDouble().ToString("0.############", CultureInfo.InvariantCulture);
        if (c.DataType == XLDataType.Boolean) return c.GetBoolean() ? "TRUE" : "FALSE";
        return c.GetString().Trim();
    }

    private static List<Row>? ReadSheet(Stream s, SheetDef def, ImportReport rep)
    {
        XLWorkbook wb;
        try { wb = new XLWorkbook(s); }
        catch { rep.Errors.Add(new(1, "File", "", "The file is not a valid Excel (.xlsx) file")); return null; }
        using (wb)
        {
            var ws = wb.Worksheets.FirstOrDefault(w => w.Name.Equals("Data", StringComparison.OrdinalIgnoreCase)) ?? wb.Worksheets.FirstOrDefault();
            var lastRow = ws?.LastRowUsed()?.RowNumber() ?? 0; var lastCol = ws?.LastColumnUsed()?.ColumnNumber() ?? 0;
            if (ws == null || lastRow == 0 || lastCol == 0) { rep.Errors.Add(new(1, "File", "", "The sheet is empty")); return null; }

            var canon = def.Known.ToDictionary(Nrm, k => k);
            var map = new Dictionary<string, int>();
            for (int c = 1; c <= lastCol; c++)
            {
                var h = Text(ws.Cell(1, c)); if (h == "") continue;
                if (canon.TryGetValue(Nrm(h), out var k))
                { if (map.ContainsKey(k)) rep.Errors.Add(new(1, h, h, $"Column ‘{h}’ appears twice")); else map[k] = c; }
                else if (def.Silent == null || !def.Silent.Any(x => Nrm(x) == Nrm(h))) rep.Warnings.Add($"Column ‘{h}’ is not used and was ignored");
            }
            foreach (var q in def.Req) if (!map.ContainsKey(q)) rep.Errors.Add(new(1, q, "", $"Required column ‘{q}’ is missing"));
            if (rep.Errors.Count > 0) return null;

            var rows = new List<Row>();
            for (int r = 2; r <= lastRow; r++)
            {
                var v = new Dictionary<string, string>(); var any = false;
                foreach (var (k, c) in map) { var x = Text(ws.Cell(r, c)); if (x != "") any = true; v[k] = x; }
                if (any) rows.Add(new Row(r, v));
            }
            if (rows.Count == 0) { rep.Errors.Add(new(2, "File", "", "No data rows found below the header")); return null; }
            if (rows.Count > def.MaxRows) { rep.Errors.Add(new(1, "File", "", $"Too many rows ({rows.Count}). Maximum is {def.MaxRows} per file")); return null; }
            return rows;
        }
    }

    /// <summary>Per-row validation helper: every failure is recorded with row, column, value and message.</summary>
    private sealed class Ctx(ImportReport rep, Row r)
    {
        private readonly int _before = rep.Errors.Count;
        public bool Ok => rep.Errors.Count == _before;
        private string Get(string col) => r.V.TryGetValue(col, out var v) ? v : "";
        public void Fail(string col, string val, string msg) => rep.Errors.Add(new ImportError(r.N, col, val.Length > 40 ? val[..40] + "…" : val, msg));
        public string? T(string col, int max, bool req)
        {
            var v = Get(col);
            if (v == "") { if (req) Fail(col, "", $"{col} is required"); return null; }
            if (v.Length > max) { Fail(col, v, $"{col} is too long (max {max} characters)"); return null; }
            return v;
        }
        public decimal? N(string col, decimal min, decimal max, bool req, int dec = 2)
        {
            var v = Get(col);
            if (v == "") { if (req) Fail(col, "", $"{col} is required"); return null; }
            if (!decimal.TryParse(v, NumberStyles.Number, CultureInfo.InvariantCulture, out var n)) { Fail(col, v, $"{col} must be a number"); return null; }
            if (n < min || n > max) { Fail(col, v, $"{col} must be between {min:0.##} and {max:0.##}"); return null; }
            if (decimal.Round(n, dec) != n) { Fail(col, v, $"{col} can have at most {dec} decimals"); return null; }
            return n;
        }
        public bool Active()
        {
            var v = Get("Active");
            if (v == "") return true;
            switch (v.ToLowerInvariant()) { case "y": case "yes": case "true": case "1": return true; case "n": case "no": case "false": case "0": return false; }
            Fail("Active", v, "Active must be Y or N"); return true;
        }
    }

    private static bool Dup(Dictionary<string, int> seen, string? val, int row, Ctx c, string col, string what)
    {
        if (val == null) return false;
        var k = val.ToLowerInvariant();
        if (seen.TryGetValue(k, out var first)) { c.Fail(col, val, $"Duplicate {what} in the file (first used in row {first})"); return true; }
        seen[k] = row; return false;
    }

    // =====================================================================  RUN
    public async Task<ImportReport> RunAsync(string entity, IFormFile file, bool commit)
    {
        entity = entity.ToLowerInvariant();
        if (!Defs.TryGetValue(entity, out var def)) throw new InvalidOperationException("Unknown master data type: " + entity);
        var rep = new ImportReport { Entity = entity, FileName = file.FileName };
        var rows = ReadSheet(Open(file), def, rep);
        if (rows != null)
        {
            rep.Total = rows.Count;
            switch (entity)
            {
                case "items": await ItemsAsync(rows, rep); break;
                case "categories": await CategoriesAsync(rows, rep); break;
                case "vendors": await VendorsAsync(rows, rep); break;
                case "divisions": await DivisionsAsync(rows, rep); break;
                case "departments": await DepartmentsAsync(rows, rep); break;
                case "employees": await EmployeesAsync(rows, rep); break;
            }
        }
        if (!commit)
        {
            rep.Message = rep.Errors.Count == 0 ? $"File is valid: {rep.Plan.Count} row(s) ready to import." : $"{rep.Errors.Count} problem(s) found. Nothing has been imported.";
            return rep;
        }
        if (rep.Errors.Count > 0 || rep.Plan.Count == 0)
        {
            rep.Message = rep.Errors.Count > 0 ? $"Nothing was imported: {rep.Errors.Count} problem(s) found. Fix them in the file and upload it again." : "Nothing to import.";
            return rep;
        }
        await using var tx = await db.Database.BeginTransactionAsync();
        try
        {
            await ApplyAsync(entity, rep);
            db.Audit("Import", entity, "Import", null, $"{rep.FileName}: {rep.Created} created, {rep.Updated} updated", user.Email);
            await db.SaveChangesAsync();
            await tx.CommitAsync();
        }
        catch { await tx.RollbackAsync(); throw; }
        rep.Applied = true;
        rep.Message = $"Import complete: {rep.Created} created, {rep.Updated} updated.";
        return rep;
    }

    // =====================================================================  VALIDATION PER ENTITY
    private sealed record ItemRec(string Code, string Name, int? CatId, string Unit, decimal Rate, decimal Stock, decimal Reorder, bool Active);
    private sealed record CatRec(string Name, bool Active);
    private sealed record VendRec(string Name, string Email, string? Contact, string? Phone, string? Address, string? Gst, bool Active);
    private sealed record DivRec(string Name, int? HeadId, bool Active);
    private sealed record DeptRec(string Name, int DivisionId, int? HeadId, bool Active);
    private sealed record EmpRec(string Code, string Name, string Email, int DeptId, int DivId, string Role, string? MgrKey, bool Active);

    private async Task ItemsAsync(List<Row> rows, ImportReport rep)
    {
        var cats = await db.Categories.AsNoTracking().ToDictionaryAsync(c => c.CategoryName.ToLower());
        var cur = await db.Items.ToDictionaryAsync(i => i.ItemCode.ToLower());
        var seen = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r);
            var code = c.T("ItemCode", 30, true); var name = c.T("ItemName", 200, true); var unit = c.T("Unit", 30, true); var catName = c.T("Category", 100, false);
            var rate = c.N("Rate", 0, 10000000, true); var stock = c.N("StockQty", 0, 10000000, false); var reo = c.N("ReorderLevel", 0, 10000000, false); var act = c.Active();
            int? catId = null;
            if (catName != null) { if (cats.TryGetValue(catName.ToLower(), out var cat)) catId = cat.CategoryId; else c.Fail("Category", catName, $"Category ‘{catName}’ does not exist. Import categories first or fix the name"); }
            Dup(seen, code, r.N, c, "ItemCode", "ItemCode");
            if (!c.Ok) continue;
            cur.TryGetValue(code!.ToLower(), out var ex);
            if (ex != null && stock != null && stock != ex.StockQty) rep.Warnings.Add($"Row {r.N}: StockQty ignored for existing item {code} (use Store stock)");
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [code!, name!, rate!.Value.ToString("N2")],
                Rec = new ItemRec(code!, name!, catId, unit!, rate.Value, stock ?? 0, reo ?? 0, act) });
        }
    }

    private async Task CategoriesAsync(List<Row> rows, ImportReport rep)
    {
        var cur = await db.Categories.ToDictionaryAsync(c => c.CategoryName.ToLower());
        var seen = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r); var name = c.T("CategoryName", 100, true); var act = c.Active();
            Dup(seen, name, r.N, c, "CategoryName", "category");
            if (!c.Ok) continue;
            cur.TryGetValue(name!.ToLower(), out var ex);
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [name!, act ? "Active" : "Inactive", ""], Rec = new CatRec(name!, act) });
        }
    }

    private async Task VendorsAsync(List<Row> rows, ImportReport rep)
    {
        var cur = await db.Vendors.ToDictionaryAsync(v => v.VendorName.ToLower());
        var seen = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r);
            var name = c.T("VendorName", 200, true); var email = c.T("Email", 256, true); var contact = c.T("ContactPerson", 150, false);
            var phone = c.T("Phone", 30, false); var addr = c.T("Address", 500, false); var gst = c.T("GSTNo", 30, false); var act = c.Active();
            if (email != null && !EmailRx.IsMatch(email)) c.Fail("Email", email, "Email is not a valid address");
            if (gst != null && !GstRx.IsMatch(gst)) c.Fail("GSTNo", gst, "GSTNo must be exactly 15 letters / digits");
            Dup(seen, name, r.N, c, "VendorName", "vendor");
            if (!c.Ok) continue;
            cur.TryGetValue(name!.ToLower(), out var ex);
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [name!, email!, contact ?? ""], Rec = new VendRec(name!, email!, contact, phone, addr, gst, act) });
        }
    }

    private static Employee? FindEmp(List<Employee> emps, string key, out bool ambiguous)
    {
        ambiguous = false; var k = key.ToLowerInvariant();
        var byKey = emps.Where(e => e.EmployeeCode.ToLower() == k || e.Email.ToLower() == k).ToList();
        if (byKey.Count == 1) return byKey[0];
        var byName = emps.Where(e => e.FullName.ToLower() == k).ToList();
        if (byName.Count == 1) return byName[0];
        ambiguous = byName.Count > 1; return null;
    }

    private async Task DivisionsAsync(List<Row> rows, ImportReport rep)
    {
        var emps = await db.Employees.AsNoTracking().ToListAsync();
        var cur = await db.Divisions.ToDictionaryAsync(d => d.DivisionName.ToLower());
        var seen = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r); var name = c.T("DivisionName", 150, true); var head = c.T("DivisionHead", 200, false); var act = c.Active();
            int? headId = null;
            if (head != null) { var e = FindEmp(emps, head, out var amb); if (e != null) headId = e.EmployeeId; else c.Fail("DivisionHead", head, amb ? $"‘{head}’ matches several employees. Use the employee code or e-mail" : $"Employee ‘{head}’ was not found. Import employees first"); }
            Dup(seen, name, r.N, c, "DivisionName", "division");
            if (!c.Ok) continue;
            cur.TryGetValue(name!.ToLower(), out var ex);
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [name!, head ?? "", act ? "Active" : "Inactive"], Rec = new DivRec(name!, headId, act) });
        }
    }

    private async Task DepartmentsAsync(List<Row> rows, ImportReport rep)
    {
        var emps = await db.Employees.AsNoTracking().ToListAsync();
        var divs = await db.Divisions.AsNoTracking().ToListAsync();
        var cur = await db.Departments.ToListAsync();
        var seen = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r); var name = c.T("DepartmentName", 150, true); var divName = c.T("Division", 150, true); var head = c.T("DepartmentHead", 200, false); var act = c.Active();
            var div = divName == null ? null : divs.FirstOrDefault(d => d.DivisionName.Equals(divName, StringComparison.OrdinalIgnoreCase));
            if (divName != null && div == null) c.Fail("Division", divName, $"Division ‘{divName}’ does not exist. Known: {string.Join(", ", divs.Select(d => d.DivisionName))}");
            int? headId = null;
            if (head != null) { var e = FindEmp(emps, head, out var amb); if (e != null) headId = e.EmployeeId; else c.Fail("DepartmentHead", head, amb ? $"‘{head}’ matches several employees. Use the employee code or e-mail" : $"Employee ‘{head}’ was not found. Import employees first"); }
            if (name != null && divName != null) Dup(seen, name + "|" + divName, r.N, c, "DepartmentName", "department + division");
            if (!c.Ok) continue;
            var ex = cur.FirstOrDefault(d => d.DepartmentName.Equals(name, StringComparison.OrdinalIgnoreCase) && d.DivisionId == div!.DivisionId);
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [name!, div!.DivisionName, head ?? ""], Rec = new DeptRec(name!, div.DivisionId, headId, act) });
        }
    }

    private async Task EmployeesAsync(List<Row> rows, ImportReport rep)
    {
        var depts = await db.Departments.AsNoTracking().ToListAsync();
        var all = await db.Employees.ToListAsync();                          // tracked
        var byCode = all.ToDictionary(e => e.EmployeeCode.ToLower());
        var byId = all.ToDictionary(e => e.EmployeeId);
        var me = user.Email;

        // keys (code / e-mail, lower case) of every row in the file -> its e-mail
        var fileKey = new Dictionary<string, string>();
        foreach (var r in rows)
        {
            var code = r.V.GetValueOrDefault("EmployeeCode", "").ToLower(); var em = r.V.GetValueOrDefault("Email", "").ToLower();
            if (em != "") { fileKey[em] = em; if (code != "") fileKey[code] = em; }
        }
        string? ResolveEmail(string key)
        {
            var k = key.ToLower();
            if (fileKey.TryGetValue(k, out var e)) return e;
            var emp = all.FirstOrDefault(x => x.EmployeeCode.ToLower() == k || x.Email.ToLower() == k);
            return emp?.Email.ToLower();
        }

        var sc = new Dictionary<string, int>(); var se = new Dictionary<string, int>();
        foreach (var r in rows)
        {
            var c = new Ctx(rep, r);
            var code = c.T("EmployeeCode", 30, true); var name = c.T("FullName", 200, true); var email = c.T("Email", 256, true);
            var deptName = c.T("Department", 150, true); var roleIn = c.T("Role", 30, true); var mgr = c.T("ReportingManager", 256, false); var act = c.Active();
            var dept = deptName == null ? null : depts.FirstOrDefault(d => d.DepartmentName.Equals(deptName, StringComparison.OrdinalIgnoreCase));
            var role = roleIn == null ? null : Roles.FirstOrDefault(x => x.Equals(roleIn, StringComparison.OrdinalIgnoreCase));
            if (email != null && !EmailRx.IsMatch(email)) c.Fail("Email", email, "Email is not a valid address");
            if (deptName != null && dept == null) c.Fail("Department", deptName, $"Department ‘{deptName}’ does not exist. Import departments first or fix the name");
            if (roleIn != null && role == null) c.Fail("Role", roleIn, "Role must be one of: " + string.Join(", ", Roles));
            if (mgr != null)
            {
                var me2 = ResolveEmail(mgr);
                if (me2 == null) c.Fail("ReportingManager", mgr, $"Manager ‘{mgr}’ was not found. Use the code or e-mail of an existing employee or of a row in this file");
                else if (me2 == (email ?? "").ToLower() || mgr.Equals(code, StringComparison.OrdinalIgnoreCase)) c.Fail("ReportingManager", mgr, "An employee cannot report to themselves");
            }
            Dup(sc, code, r.N, c, "EmployeeCode", "EmployeeCode");
            Dup(se, email, r.N, c, "Email", "e-mail");
            byCode.TryGetValue((code ?? "").ToLower(), out var ex);
            if (email != null)
            {
                var other = all.FirstOrDefault(x => x.Email.Equals(email, StringComparison.OrdinalIgnoreCase) && x != ex);
                if (other != null) c.Fail("Email", email, $"E-mail is already used by employee {other.EmployeeCode} ({other.FullName})");
                if (!act && email.Equals(me, StringComparison.OrdinalIgnoreCase)) c.Fail("Active", "N", "You cannot deactivate your own account through an import");
                if (role != null && role != "Admin" && email.Equals(me, StringComparison.OrdinalIgnoreCase)) c.Fail("Role", roleIn!, "You cannot remove your own Admin role through an import");
            }
            if (!c.Ok) continue;
            rep.Plan.Add(new PlanRow { Row = r.N, Update = ex != null, Cur = ex, Show = [code!, name!, role!],
                Rec = new EmpRec(code!, name!, email!.ToLower(), dept!.DepartmentId, dept.DivisionId, role!, mgr, act) });
        }

        // reporting-chain loops (file rows override the database)
        var chain = all.Where(e => e.ReportingManagerId != null && byId.ContainsKey(e.ReportingManagerId.Value))
            .ToDictionary(e => e.Email.ToLower(), e => byId[e.ReportingManagerId!.Value].Email.ToLower());
        foreach (var p in rep.Plan) { var rec = (EmpRec)p.Rec; if (!string.IsNullOrEmpty(rec.MgrKey)) { var t = ResolveEmail(rec.MgrKey); if (t != null) chain[rec.Email] = t; } }
        foreach (var p in rep.Plan.ToList())
        {
            var rec = (EmpRec)p.Rec; var x = rec.Email; var n = 0; var loop = false;
            while (chain.TryGetValue(x, out var nx) && n++ < 100) { if (nx == rec.Email) { loop = true; break; } x = nx; }
            if (loop) { rep.Errors.Add(new ImportError(p.Row, "ReportingManager", rec.MgrKey ?? "", $"Reporting chain loops back to {rec.Name} ({rec.Code})")); rep.Plan.Remove(p); }
        }
    }

    // =====================================================================  APPLY (inside a transaction)
    private async Task ApplyAsync(string entity, ImportReport rep)
    {
        switch (entity)
        {
            case "items":
                var opening = new List<(Item it, decimal q)>();
                foreach (var p in rep.Plan)
                {
                    var r = (ItemRec)p.Rec; var it = (Item?)p.Cur;
                    if (it == null) { it = new Item { ItemCode = r.Code, StockQty = r.Stock }; db.Items.Add(it); opening.Add((it, r.Stock)); rep.Created++; } else rep.Updated++;
                    it.ItemName = r.Name; it.CategoryId = r.CatId; it.Unit = r.Unit; it.Rate = r.Rate; it.ReorderLevel = r.Reorder; it.IsActive = r.Active;
                }
                await db.SaveChangesAsync();
                foreach (var (it, q) in opening.Where(o => o.q > 0))
                    db.StockTransactions.Add(new StockTransaction { ItemId = it.ItemId, TxnType = "Receipt", Quantity = q, Note = "Opening stock (import)", CreatedBy = user.Email });
                break;
            case "categories":
                foreach (var p in rep.Plan)
                {
                    var r = (CatRec)p.Rec; var c = (ItemCategory?)p.Cur;
                    if (c == null) { c = new ItemCategory(); db.Categories.Add(c); rep.Created++; } else rep.Updated++;
                    c.CategoryName = r.Name; c.IsActive = r.Active;
                }
                break;
            case "vendors":
                foreach (var p in rep.Plan)
                {
                    var r = (VendRec)p.Rec; var v = (Vendor?)p.Cur;
                    if (v == null) { v = new Vendor(); db.Vendors.Add(v); rep.Created++; } else rep.Updated++;
                    v.VendorName = r.Name; v.Email = r.Email; v.IsActive = r.Active;
                    if (r.Contact != null) v.ContactPerson = r.Contact; if (r.Phone != null) v.Phone = r.Phone; if (r.Address != null) v.Address = r.Address; if (r.Gst != null) v.GSTNo = r.Gst;
                }
                break;
            case "divisions":
                foreach (var p in rep.Plan)
                {
                    var r = (DivRec)p.Rec; var d = (Division?)p.Cur;
                    if (d == null) { d = new Division(); db.Divisions.Add(d); rep.Created++; } else rep.Updated++;
                    d.DivisionName = r.Name; d.IsActive = r.Active; if (r.HeadId != null) d.DivisionHeadId = r.HeadId;
                }
                break;
            case "departments":
                foreach (var p in rep.Plan)
                {
                    var r = (DeptRec)p.Rec; var d = (Department?)p.Cur;
                    if (d == null) { d = new Department(); db.Departments.Add(d); rep.Created++; } else rep.Updated++;
                    d.DepartmentName = r.Name; d.DivisionId = r.DivisionId; d.IsActive = r.Active; if (r.HeadId != null) d.DepartmentHeadId = r.HeadId;
                }
                break;
            case "employees":
                foreach (var p in rep.Plan)
                {
                    var r = (EmpRec)p.Rec; var e = (Employee?)p.Cur;
                    if (e == null) { e = new Employee(); db.Employees.Add(e); rep.Created++; } else rep.Updated++;
                    e.EmployeeCode = r.Code; e.FullName = r.Name; e.Email = r.Email; e.DepartmentId = r.DeptId; e.DivisionId = r.DivId; e.Role = r.Role; e.IsActive = r.Active;
                }
                await db.SaveChangesAsync();                                  // new rows get ids, then link managers
                var all = await db.Employees.ToListAsync();
                foreach (var p in rep.Plan)
                {
                    var r = (EmpRec)p.Rec; if (string.IsNullOrEmpty(r.MgrKey)) continue;
                    var k = r.MgrKey.ToLower();
                    var mgr = all.FirstOrDefault(x => x.EmployeeCode.ToLower() == k || x.Email.ToLower() == k);
                    var emp = all.First(x => x.Email.Equals(r.Email, StringComparison.OrdinalIgnoreCase));
                    if (mgr != null) emp.ReportingManagerId = mgr.EmployeeId;
                }
                break;
        }
        await db.SaveChangesAsync();
    }

    // =====================================================================  REQUESTOR LINE-ITEM IMPORT (validation only, nothing is saved)
    public async Task<ImportReport> ValidateLinesAsync(IFormFile file)
    {
        var rep = new ImportReport { Entity = "lines", FileName = file.FileName, Lines = new() };
        var rows = ReadSheet(Open(file), LineDef, rep);
        if (rows != null)
        {
            rep.Total = rows.Count;
            var items = await db.Items.AsNoTracking().Where(i => i.IsActive).ToDictionaryAsync(i => i.ItemCode.ToLower());
            var seen = new Dictionary<string, int>();
            foreach (var r in rows)
            {
                var c = new Ctx(rep, r);
                var code = c.T("ItemCode", 30, true); var qty = c.N("Quantity", 0.01m, 100000, true); var rem = c.T("Remarks", 200, false);
                Item? it = null;
                if (code != null)
                {
                    if (!items.TryGetValue(code.ToLower(), out it)) c.Fail("ItemCode", code, $"Item code ‘{code}’ was not found in the item master (or the item is inactive)");
                    else Dup(seen, code, r.N, c, "ItemCode", "item");
                }
                if (c.Ok) rep.Lines!.Add(new LineOut(r.N, it!.ItemId, it.ItemCode, it.ItemName, it.Unit, it.Rate, qty!.Value, rem));
            }
        }
        rep.Message = rep.Errors.Count == 0 ? $"{rep.Lines!.Count} line(s) are valid." : $"{rep.Errors.Count} problem(s) found. Fix the file and upload it again.";
        return rep;
    }

    // =====================================================================  TEMPLATES / EXPORTS
    private static byte[] Save(XLWorkbook wb) { using var ms = new MemoryStream(); wb.SaveAs(ms); return ms.ToArray(); }

    private static void Head(IXLWorksheet ws, IEnumerable<string> cols, string[] req)
    {
        int i = 1;
        foreach (var c in cols)
        {
            var cell = ws.Cell(1, i++); cell.Value = c; cell.Style.Font.Bold = true;
            cell.Style.Fill.BackgroundColor = req.Contains(c) ? XLColor.FromHtml("#FDE68A") : XLColor.FromHtml("#E5E7EB");
        }
        ws.SheetView.FreezeRows(1);
    }

    private static void Instructions(XLWorkbook wb, SheetDef d)
    {
        var ws = wb.AddWorksheet("Instructions");
        ws.Cell(1, 1).Value = "Column"; ws.Cell(1, 2).Value = "Required"; ws.Row(1).Style.Font.Bold = true;
        int r = 2; foreach (var c in d.Req) { ws.Cell(r, 1).Value = c; ws.Cell(r++, 2).Value = "Yes"; }
        foreach (var c in d.Opt.Where(o => d.Silent == null || !d.Silent.Contains(o))) { ws.Cell(r, 1).Value = c; ws.Cell(r++, 2).Value = "No"; }
        ws.Cell(r + 1, 1).Value = "Rules"; ws.Cell(r + 1, 1).Style.Font.Bold = true; ws.Cell(r + 2, 1).Value = d.Rules;
        ws.Cell(r + 4, 1).Value = "Header in row 1 of the sheet called Data. Yellow = required. Max " + d.MaxRows + " rows. One error blocks the whole import.";
        ws.Column(1).Width = 28; ws.Column(2).Width = 12;
    }

    public byte[] MasterTemplate(string entity)
    {
        if (!Defs.TryGetValue(entity.ToLowerInvariant(), out var d)) throw new InvalidOperationException("Unknown master data type");
        using var wb = new XLWorkbook();
        Head(wb.AddWorksheet("Data"), d.Known, d.Req);
        Instructions(wb, d);
        return Save(wb);
    }

    public async Task<byte[]> MasterExportAsync(string entity)
    {
        entity = entity.ToLowerInvariant();
        if (!Defs.TryGetValue(entity, out var d)) throw new InvalidOperationException("Unknown master data type");
        using var wb = new XLWorkbook(); var ws = wb.AddWorksheet("Data"); Head(ws, d.Known, d.Req);
        int r = 2; string Y(bool b) => b ? "Y" : "N";
        void Put(params object?[] v)
        {
            for (int i = 0; i < v.Length; i++)
            {
                var cell = ws.Cell(r, i + 1);
                switch (v[i])
                {
                    case null: cell.SetValue(""); break;
                    case bool b: cell.SetValue(Y(b)); break;
                    case decimal m: cell.SetValue(m); break;
                    case int n: cell.SetValue(n); break;
                    default: cell.SetValue(v[i]!.ToString() ?? ""); break;
                }
            }
            r++;
        }
        switch (entity)
        {
            case "items":
                var cats = await db.Categories.AsNoTracking().ToDictionaryAsync(c => c.CategoryId, c => c.CategoryName);
                foreach (var i in await db.Items.AsNoTracking().OrderBy(x => x.ItemCode).ToListAsync())
                    Put(i.ItemCode, i.ItemName, i.Unit, i.Rate, i.CategoryId != null && cats.TryGetValue(i.CategoryId.Value, out var cn) ? cn : "", i.StockQty, i.ReorderLevel, i.IsActive);
                break;
            case "categories": foreach (var c in await db.Categories.AsNoTracking().OrderBy(x => x.CategoryName).ToListAsync()) Put(c.CategoryName, c.IsActive); break;
            case "vendors": foreach (var v in await db.Vendors.AsNoTracking().OrderBy(x => x.VendorName).ToListAsync()) Put(v.VendorName, v.Email, v.ContactPerson, v.Phone, v.Address, v.GSTNo, v.IsActive); break;
            case "divisions":
                var emps = await db.Employees.AsNoTracking().ToDictionaryAsync(e => e.EmployeeId, e => e.EmployeeCode);
                foreach (var v in await db.Divisions.AsNoTracking().OrderBy(x => x.DivisionName).ToListAsync())
                    Put(v.DivisionName, v.DivisionHeadId != null && emps.TryGetValue(v.DivisionHeadId.Value, out var hc) ? hc : "", v.IsActive);
                break;
            case "departments":
                var emp2 = await db.Employees.AsNoTracking().ToDictionaryAsync(e => e.EmployeeId, e => e.EmployeeCode);
                var divs = await db.Divisions.AsNoTracking().ToDictionaryAsync(x => x.DivisionId, x => x.DivisionName);
                foreach (var v in await db.Departments.AsNoTracking().OrderBy(x => x.DepartmentName).ToListAsync())
                    Put(v.DepartmentName, divs.GetValueOrDefault(v.DivisionId, ""), v.DepartmentHeadId != null && emp2.TryGetValue(v.DepartmentHeadId.Value, out var dc) ? dc : "", v.IsActive);
                break;
            case "employees":
                var list = await db.Employees.AsNoTracking().Include(e => e.Department).OrderBy(x => x.EmployeeCode).ToListAsync();
                var codes = list.ToDictionary(e => e.EmployeeId, e => e.EmployeeCode);
                foreach (var e in list)
                    Put(e.EmployeeCode, e.FullName, e.Email, e.Department?.DepartmentName, e.Role, e.ReportingManagerId != null && codes.TryGetValue(e.ReportingManagerId.Value, out var mc) ? mc : "", e.IsActive);
                break;
        }
        ws.Columns().AdjustToContents();
        return Save(wb);
    }

    public async Task<byte[]> LinesTemplateAsync()
    {
        using var wb = new XLWorkbook();
        Head(wb.AddWorksheet("Data"), ["ItemCode", "Quantity", "Remarks"], LineDef.Req);
        var ws = wb.AddWorksheet("Items"); Head(ws, ["ItemCode", "ItemName", "Unit", "Rate"], []);
        int r = 2;
        foreach (var i in await db.Items.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.ItemCode).ToListAsync())
        { ws.Cell(r, 1).SetValue(i.ItemCode); ws.Cell(r, 2).SetValue(i.ItemName); ws.Cell(r, 3).SetValue(i.Unit); ws.Cell(r++, 4).SetValue(i.Rate); }
        ws.Columns().AdjustToContents();
        Instructions(wb, LineDef);
        return Save(wb);
    }

    /// <summary>Line items as Excel (re-importable: ItemCode, Quantity and Remarks are the import columns).</summary>
    public static byte[] LinesExport(IEnumerable<(string Code, string Name, string Unit, decimal Rate, decimal Qty, string? Remarks, decimal? Approved, decimal? FromStore, decimal? Received)> lines, bool detail)
    {
        using var wb = new XLWorkbook(); var ws = wb.AddWorksheet("Data");
        var cols = detail ? new[] { "ItemCode", "ItemName", "Unit", "Rate", "Quantity", "Remarks", "Approved", "FromStore", "Received", "LineTotal" }
                          : new[] { "ItemCode", "ItemName", "Unit", "Rate", "Quantity", "Remarks", "LineTotal" };
        Head(ws, cols, LineDef.Req);
        int r = 2;
        foreach (var l in lines)
        {
            int c = 1;
            ws.Cell(r, c++).SetValue(l.Code); ws.Cell(r, c++).SetValue(l.Name); ws.Cell(r, c++).SetValue(l.Unit); ws.Cell(r, c++).SetValue(l.Rate); ws.Cell(r, c++).SetValue(l.Qty); ws.Cell(r, c++).SetValue(l.Remarks ?? "");
            if (detail) { ws.Cell(r, c++).SetValue(l.Approved ?? 0m); ws.Cell(r, c++).SetValue(l.FromStore ?? 0m); ws.Cell(r, c++).SetValue(l.Received ?? 0m); }
            ws.Cell(r, c).SetValue(l.Rate * l.Qty); r++;
        }
        ws.Columns().AdjustToContents();
        return Save(wb);
    }
}
