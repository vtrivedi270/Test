using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<AppDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// LOCAL-ONLY authentication: no Entra/JWT/Graph/SharePoint dependencies.
// The current user is selected with the X-Dev-User header for local development.
builder.Services.AddAuthentication("LocalDev")
    .AddScheme<LocalDevAuthenticationOptions, LocalDevAuthenticationHandler>("LocalDev", _ => { });

builder.Services.AddAuthorization();
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHttpContextAccessor();
builder.Services.AddScoped<ICurrentUserService, CurrentUserService>();
builder.Services.AddScoped<INotificationService, LocalNotificationService>();
builder.Services.AddScoped<ICalendarService, LocalCalendarService>();
builder.Services.AddScoped<IFileStorageService, LocalFileService>();
builder.Services.AddScoped<IPermissionService, PermissionService>();
builder.Services.AddCors(o => o.AddPolicy("local", p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

var app = builder.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();
    if (!db.Users.Any())
    {
        db.Users.AddRange(
            new EmployeeReferral.Api.Models.User { FullName="Vishal Trivedi", Email="vishal@local.test", Role="Manager", Department="IT" },
            new EmployeeReferral.Api.Models.User { FullName="Priya Shah", Email="depthead@local.test", Role="DeptHead", Department="IT" },
            new EmployeeReferral.Api.Models.User { FullName="Rahul Mehta", Email="divhead@local.test", Role="DivHead", Department="IT" },
            new EmployeeReferral.Api.Models.User { FullName="Neha Patel", Email="hrhead@local.test", Role="HRHead", Department="HR" },
            new EmployeeReferral.Api.Models.User { FullName="HR Recruiter", Email="hr@local.test", Role="HR", Department="HR" },
            new EmployeeReferral.Api.Models.User { FullName="Technical Interviewer", Email="interviewer@local.test", Role="Interviewer", Department="IT" },
            new EmployeeReferral.Api.Models.User { FullName="Demo Employee", Email="employee@local.test", Role="Employee", Department="IT" });
        await db.SaveChangesAsync();
        var manager = db.Users.First(x => x.Email == "vishal@local.test");
        db.Jobs.AddRange(
            new EmployeeReferral.Api.Models.Job { JobTitle="Senior .NET Developer", Department="IT", Location="Ahmedabad", Positions=2, DueDate=new DateTime(2026,9,30), Description="Build enterprise APIs and integrations.", Requirements=".NET 8, C#, SQL Server, REST, React", CreatedByUserId=manager.Id, Status="Open", OpenedAt=DateTime.UtcNow },
            new EmployeeReferral.Api.Models.Job { JobTitle="React Developer", Department="IT", Location="Ahmedabad", Positions=3, DueDate=new DateTime(2026,9,25), Description="Develop modern SPFx and React applications.", Requirements="React, TypeScript, SPFx, Fluent UI", CreatedByUserId=manager.Id, Status="Open", OpenedAt=DateTime.UtcNow });
        await db.SaveChangesAsync();
        var matrix = new Dictionary<string,string[]> {
            ["Manager"] = new[]{Permissions.JobCreate,Permissions.JobEdit,Permissions.JobDelete},
            ["DeptHead"] = new[]{Permissions.JobApprove},
            ["DivHead"] = new[]{Permissions.JobApprove,Permissions.ReferralViewAll,Permissions.ReferralFinalApprove},
            ["HR"] = new[]{Permissions.ReferralViewAll,Permissions.ReferralEdit,Permissions.InterviewSchedule,Permissions.InterviewFeedback,Permissions.ResumeUpload,Permissions.ResumeView,Permissions.ReferralStatus},
            ["HRHead"] = new[]{Permissions.ReferralViewAll,Permissions.InterviewSchedule,Permissions.InterviewFeedback,Permissions.ResumeUpload,Permissions.ResumeView,Permissions.ReferralFinalApprove,Permissions.ReferralStatus},
            ["Interviewer"] = new[]{Permissions.InterviewFeedback,Permissions.ResumeView},
            ["Employee"] = new[]{Permissions.ReferralCreate,Permissions.ReferralEdit,Permissions.ReferralDelete,Permissions.ResumeUpload,Permissions.ResumeView}
        };
        foreach(var pair in matrix) foreach(var permission in pair.Value) db.RolePermissions.Add(new EmployeeReferral.Api.Models.RolePermission{Role=pair.Key,Permission=permission,IsAllowed=true});
        await db.SaveChangesAsync();
    }
}
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseCors("local");
app.UseAuthentication();
app.UseAuthorization();
app.UseStaticFiles();
app.MapControllers();
app.MapGet("/", () => Results.Ok(new { name = "Employee Referral Portal API", mode = "LOCAL", status = "Running" }));
app.Run();
