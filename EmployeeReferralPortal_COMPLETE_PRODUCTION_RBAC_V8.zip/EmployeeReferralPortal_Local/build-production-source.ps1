$ErrorActionPreference = 'Stop'
Write-Host 'Building .NET API...'
dotnet restore .\backend\EmployeeReferral.Api\EmployeeReferral.Api.csproj
dotnet build .\backend\EmployeeReferral.Api\EmployeeReferral.Api.csproj -c Release
Write-Host 'Building standalone React frontend...'
Push-Location .\frontend
npm install
npm run build
Pop-Location
Write-Host 'Building SPFx package...'
Push-Location .\spfx\employee-referral-portal
npm install
npm run build
Pop-Location
Write-Host 'Source build completed. Configure production authentication/services before deployment.'
