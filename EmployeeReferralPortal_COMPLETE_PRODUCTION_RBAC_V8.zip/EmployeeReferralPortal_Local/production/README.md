# Production source handover

This is the handover point for moving the local application to production. The application source is complete in the parent folders (`backend`, `frontend`, `spfx`, `database`).

The production folder contains configuration templates and the migration checklist. Replace local service implementations with the production adapters described in `PRODUCTION_MIGRATION.md`, then configure Entra/Graph/SharePoint using environment variables or Key Vault.
