# Production Move Guide

This handover contains the complete local/UAT application source plus centralized RBAC/permission enforcement.

## Production architecture
SPFx React -> ASP.NET Core .NET 8 API -> SQL Server.
Production adapters replace the LOCAL development authentication, notification, calendar and file-storage services with Entra ID/JWT, Microsoft Graph mail/calendar/Teams, and SharePoint document storage.

## Security requirements before go-live
1. Replace LocalDevAuthenticationHandler with Entra ID/JWT validation.
2. Disable `X-Dev-*` headers outside Development.
3. Restrict CORS to the real SPFx/SharePoint origins.
4. Move SQL secrets to Key Vault/managed identity.
5. Replace LocalNotificationService with Graph SendMail.
6. Replace LocalCalendarService with Graph calendar/online meeting creation.
7. Replace LocalFileService with SharePoint/Graph document library storage.
8. Configure HTTPS and production logging/monitoring.
9. Run database migrations/scripts in a controlled deployment.
10. Perform UAT for every role and permission in `database/05_rbac.sql`.

The production package is intentionally not shipped with tenant/client IDs or secrets.
