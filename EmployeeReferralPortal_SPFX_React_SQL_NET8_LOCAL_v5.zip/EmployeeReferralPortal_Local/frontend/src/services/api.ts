import axios from 'axios';

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: {
    'X-Dev-User': localStorage.getItem('erp.dev.email') || 'vishal@local.test',
    'X-Dev-Name': localStorage.getItem('erp.dev.name') || 'Vishal Trivedi',
    'X-Dev-Role': localStorage.getItem('erp.dev.role') || 'Employee'
  }
});
