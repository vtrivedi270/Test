USE EmployeeReferralPortal;
GO
IF OBJECT_ID('dbo.NotificationLogs','U') IS NULL
CREATE TABLE dbo.NotificationLogs(
 Id BIGINT IDENTITY PRIMARY KEY,
 EventType NVARCHAR(100) NOT NULL,
 EntityType NVARCHAR(50) NULL,
 EntityId INT NULL,
 Recipients NVARCHAR(MAX) NOT NULL,
 Subject NVARCHAR(500) NOT NULL,
 Status NVARCHAR(30) NOT NULL,
 ErrorMessage NVARCHAR(MAX) NULL,
 CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
GO


-- Optional configurable template table for the next admin UI phase
IF OBJECT_ID('dbo.NotificationTemplates','U') IS NULL
CREATE TABLE dbo.NotificationTemplates(
 Id INT IDENTITY PRIMARY KEY, EventType NVARCHAR(100) NOT NULL UNIQUE, SubjectTemplate NVARCHAR(500) NOT NULL, HtmlTemplate NVARCHAR(MAX) NOT NULL, IsEnabled BIT NOT NULL DEFAULT 1, UpdatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
