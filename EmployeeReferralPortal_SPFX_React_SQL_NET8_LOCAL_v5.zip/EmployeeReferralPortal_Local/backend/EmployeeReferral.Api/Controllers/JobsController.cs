using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.DTOs;
using EmployeeReferral.Api.Models;
using EmployeeReferral.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Controllers;

[ApiController, Route("api/jobs"), Authorize]
public class JobsController(AppDbContext db, ICurrentUserService currentUser, INotificationService notifications) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string? search = null, [FromQuery] string? status = null)
    {
        var q = db.Jobs.AsNoTracking();
        if (!string.IsNullOrWhiteSpace(search)) q = q.Where(x => x.JobTitle.Contains(search) || x.Department.Contains(search));
        if (!string.IsNullOrWhiteSpace(status)) q = q.Where(x => x.Status == status);
        return Ok(await q.OrderByDescending(x => x.CreatedAt).ToListAsync());
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var j = await db.Jobs.AsNoTracking().Include(x => x.Approvals).FirstOrDefaultAsync(x => x.Id == id);
        return j is null ? NotFound() : Ok(j);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateJobRequest r)
    {
        if (r.Positions < 1) return BadRequest("Positions must be at least 1.");
        if (!await currentUser.IsInRoleAsync("Manager") && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        var user = await currentUser.GetOrCreateAsync();
        var j = new Job { JobTitle=r.JobTitle, Department=r.Department, Location=r.Location, Positions=r.Positions, DueDate=r.DueDate, Description=r.Description, Requirements=r.Requirements, CreatedByUserId=user.Id, Status="Pending Department Head" };
        db.Jobs.Add(j); await db.SaveChangesAsync();
        foreach (var level in new[] { "Department Head", "Division Head", "HR Head" }) db.JobApprovals.Add(new JobApproval { JobId=j.Id, ApprovalLevel=level });
        db.AuditLogs.Add(new AuditLog { EntityType="Job", EntityId=j.Id, Action="Created", UserId=user.Id, Details=j.JobTitle });
        await db.SaveChangesAsync();
        var deptHead = await db.Users.AsNoTracking().Where(u => u.IsActive && u.Role == "DeptHead").Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
        await notifications.SendAsync("JobSubmitted", deptHead, $"Job approval required: {j.JobTitle}", $"<p>A new job requirement <b>{System.Net.WebUtility.HtmlEncode(j.JobTitle)}</b> has been submitted for Department Head approval.</p><p>Positions: {j.Positions}<br/>Due date: {j.DueDate:dd-MMM-yyyy}</p>", "Job", j.Id);
        return CreatedAtAction(nameof(Get), new { id=j.Id }, j);
    }

    [HttpPost("{id:int}/approval")]
    public async Task<IActionResult> Approval(int id, ApprovalRequest r)
    {
        if (r.Status is not ("Approved" or "Rejected")) return BadRequest("Status must be Approved or Rejected.");
        var j = await db.Jobs.Include(x => x.Approvals).FirstOrDefaultAsync(x => x.Id == id); if (j is null) return NotFound();
        var user = await currentUser.GetOrCreateAsync();
        var level = j.Status.Replace("Pending ", "", StringComparison.OrdinalIgnoreCase);
        var requiredRole = level == "Department Head" ? "DeptHead" : level == "Division Head" ? "DivHead" : "HRHead";
        if (!await currentUser.IsInRoleAsync(requiredRole) && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        var a = j.Approvals.FirstOrDefault(x => x.ApprovalLevel.Equals(level, StringComparison.OrdinalIgnoreCase));
        if (a is null) return BadRequest("Current approval level not found.");
        if (a.Status != "Pending") return BadRequest("This approval is already processed.");
        a.Status=r.Status; a.Comments=r.Comments; a.ApproverUserId=user.Id; a.ApprovedAt=DateTime.UtcNow;
        j.Status = r.Status == "Rejected" ? "Rejected" : j.Approvals.All(x => x.Status == "Approved") ? "Open" : $"Pending {j.Approvals.First(x => x.Status == "Pending").ApprovalLevel}";
        if (j.Status == "Open") j.OpenedAt=DateTime.UtcNow;
        db.AuditLogs.Add(new AuditLog { EntityType="Job", EntityId=id, Action=$"{r.Status} - {a.ApprovalLevel}", UserId=user.Id, Details=r.Comments });
        await db.SaveChangesAsync();
        var nextRole = j.Status == "Pending Division Head" ? "DivHead" : j.Status == "Pending HR Head" ? "HRHead" : null;
        if (nextRole != null) {
            var recipients = await db.Users.AsNoTracking().Where(u => u.IsActive && u.Role == nextRole).Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
            await notifications.SendAsync("JobApprovalRequired", recipients, $"Job approval required: {j.JobTitle}", $"<p>Job <b>{System.Net.WebUtility.HtmlEncode(j.JobTitle)}</b> is waiting for your approval.</p>", "Job", j.Id);
        } else if (j.Status == "Open") {
            var recipients = await db.Users.AsNoTracking().Where(u => u.IsActive && u.Role == "Employee").Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
            await notifications.SendAsync("JobOpened", recipients, $"New employee referral opportunity: {j.JobTitle}", $"<p><b>{System.Net.WebUtility.HtmlEncode(j.JobTitle)}</b> is now open for employee referrals.</p><p>Apply before {j.DueDate:dd-MMM-yyyy}.</p>", "Job", j.Id);
        }
        return Ok(j);
    }
}
