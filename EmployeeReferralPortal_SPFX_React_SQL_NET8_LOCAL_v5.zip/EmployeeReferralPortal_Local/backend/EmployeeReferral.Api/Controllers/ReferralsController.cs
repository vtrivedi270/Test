using EmployeeReferral.Api.Data;
using EmployeeReferral.Api.DTOs;
using EmployeeReferral.Api.Models;
using EmployeeReferral.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Controllers;

[ApiController, Route("api/referrals"), Authorize]
public class ReferralsController(AppDbContext db, ICurrentUserService currentUser, INotificationService notifications, ICalendarService calendar, IFileStorageService sharePoint) : ControllerBase
{
    [HttpGet("my")]
    public async Task<IActionResult> My()
    {
        var user=await currentUser.GetOrCreateAsync();
        return Ok(await db.Referrals.AsNoTracking().Where(x=>x.ReferrerUserId==user.Id).Include(x=>x.Interviews).OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> All()
    {
        if (!await currentUser.IsInRoleAsync("HR") && !await currentUser.IsInRoleAsync("HRHead") && !await currentUser.IsInRoleAsync("DivHead") && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        return Ok(await db.Referrals.AsNoTracking().Include(x=>x.Interviews).Include(x=>x.FinalApprovals).OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }

    [HttpGet("assigned")]
    public async Task<IActionResult> Assigned()
    {
        var user=await currentUser.GetOrCreateAsync();
        if(!await currentUser.IsInRoleAsync("Interviewer") && !await currentUser.IsInRoleAsync("HR") && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        return Ok(await db.Referrals.AsNoTracking().Include(x=>x.Interviews).ThenInclude(x=>x.Feedback).Where(x=>x.Interviews.Any(i=>i.InterviewerUserId==user.Id)).OrderByDescending(x=>x.CreatedAt).ToListAsync());
    }

    [HttpGet("{id:int}")]
    public async Task<IActionResult> Get(int id)
    {
        var r=await db.Referrals.AsNoTracking().Include(x=>x.Interviews).ThenInclude(x=>x.Feedback).Include(x=>x.FinalApprovals).FirstOrDefaultAsync(x=>x.Id==id);
        return r is null ? NotFound() : Ok(r);
    }

    [HttpPost]
    public async Task<IActionResult> Create(CreateReferralRequest r)
    {
        if (!await db.Jobs.AnyAsync(x=>x.Id==r.JobId && x.Status=="Open" && x.DueDate.Date>=DateTime.UtcNow.Date)) return BadRequest("Job is not open for referrals.");
        var user=await currentUser.GetOrCreateAsync();
        var x=new Referral { JobId=r.JobId, ReferrerUserId=user.Id, CandidateName=r.CandidateName, CandidateEmail=r.CandidateEmail, CandidatePhone=r.CandidatePhone, ExperienceYears=r.ExperienceYears, ResumeFileName=r.ResumeFileName, ResumePath=r.ResumePath, WhyGoodFit=r.WhyGoodFit, Status="Submitted" };
        db.Referrals.Add(x); await db.SaveChangesAsync();
        foreach(var level in new[]{"Division Head","HR Head"}) db.FinalApprovals.Add(new FinalApproval { ReferralId=x.Id, ApprovalLevel=level });
        db.AuditLogs.Add(new AuditLog { EntityType="Referral", EntityId=x.Id, Action="Submitted", UserId=user.Id, Details=x.CandidateName });
        await db.SaveChangesAsync();
        var hr = await db.Users.AsNoTracking().Where(u => u.IsActive && (u.Role == "HR" || u.Role == "HRHead")).Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
        await notifications.SendAsync("ReferralSubmitted", hr, $"New employee referral: {x.CandidateName}", $"<p>A new referral for <b>{System.Net.WebUtility.HtmlEncode(x.CandidateName)}</b> has been submitted.</p><p>Candidate email: {System.Net.WebUtility.HtmlEncode(x.CandidateEmail)}</p>", "Referral", x.Id);
        return CreatedAtAction(nameof(Get),new{id=x.Id},x);
    }

    [HttpPost("{id:int}/interviews")]
    public async Task<IActionResult> Schedule(int id, ScheduleInterviewRequest r)
    {
        if (r.RoundNo is < 1 or > 3) return BadRequest("Round must be 1, 2 or 3.");
        var x=await db.Referrals.Include(z=>z.Interviews).FirstOrDefaultAsync(z=>z.Id==id); if(x is null) return NotFound();
        if (r.RoundNo > 1) { var previous = x.Interviews.FirstOrDefault(z=>z.RoundNo==r.RoundNo-1); if (previous?.Status != "Completed") return BadRequest($"Interview {r.RoundNo-1} must be completed first."); }
        var i=await db.Interviews.FirstOrDefaultAsync(z=>z.ReferralId==id && z.RoundNo==r.RoundNo) ?? new Interview{ReferralId=id,RoundNo=r.RoundNo};
        i.InterviewType=r.InterviewType;i.ScheduledAt=r.ScheduledAt;i.InterviewerUserId=r.InterviewerUserId;i.Status="Scheduled";
        if(i.Id==0) db.Interviews.Add(i); x.Status=$"Interview {r.RoundNo}";x.UpdatedAt=DateTime.UtcNow;
        await db.SaveChangesAsync();
        var attendees = new List<(string Email,string Name)> { (x.CandidateEmail, x.CandidateName) };
        if (i.InterviewerUserId.HasValue)
        {
            var interviewerForMeeting = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == i.InterviewerUserId.Value);
            if (interviewerForMeeting != null) attendees.Add((interviewerForMeeting.Email, interviewerForMeeting.FullName));
        }
        try
        {
            var start = i.ScheduledAt!.Value.ToUniversalTime();
            var meeting = await calendar.CreateInterviewEventAsync($"Employee Referral - Interview {i.RoundNo} - {x.CandidateName}", $"<p>Interview {i.RoundNo} for <b>{System.Net.WebUtility.HtmlEncode(x.CandidateName)}</b>.</p><p>Type: {System.Net.WebUtility.HtmlEncode(i.InterviewType)}</p>", start, start.AddMinutes(60), attendees);
            if (meeting != null) { i.CalendarEventId = meeting.EventId; i.OnlineMeetingUrl = meeting.JoinUrl; await db.SaveChangesAsync(); }
        }
        catch { /* interview remains scheduled; notification/audit can capture the local service failure in production */ }
        var recipients = new List<NotificationRecipient> { new(x.CandidateEmail, x.CandidateName) };
        if (i.InterviewerUserId.HasValue) { var interviewer = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == i.InterviewerUserId.Value); if (interviewer != null) recipients.Add(new(interviewer.Email, interviewer.FullName)); }
        var hrRecipients = await db.Users.AsNoTracking().Where(u => u.IsActive && (u.Role == "HR" || u.Role == "HRHead")).Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
        recipients.AddRange(hrRecipients);
        await notifications.SendAsync("InterviewScheduled", recipients, $"Interview {i.RoundNo} scheduled: {x.CandidateName}", $"<p>Interview <b>{i.RoundNo}</b> for <b>{System.Net.WebUtility.HtmlEncode(x.CandidateName)}</b> has been scheduled.</p><p>Type: {System.Net.WebUtility.HtmlEncode(i.InterviewType)}<br/>Time: {i.ScheduledAt:dd-MMM-yyyy HH:mm} UTC</p>{(string.IsNullOrWhiteSpace(i.OnlineMeetingUrl) ? "" : $"<p><a href=\"{i.OnlineMeetingUrl}\">Join Teams meeting</a></p>")}", "Interview", i.Id);
        return Ok(i);
    }

    [HttpPost("interviews/{interviewId:int}/feedback")]
    public async Task<IActionResult> Feedback(int interviewId, FeedbackRequest r)
    {
        if (new[]{r.OverallRating,r.TechnicalSkills,r.CommunicationSkills,r.ProblemSolving}.Any(x=>x<1||x>5)) return BadRequest("Ratings must be 1-5.");
        var i=await db.Interviews.Include(x=>x.Referral).FirstOrDefaultAsync(x=>x.Id==interviewId);if(i is null)return NotFound();
        var user=await currentUser.GetOrCreateAsync();
        if (i.InterviewerUserId.HasValue && i.InterviewerUserId.Value != user.Id && !await currentUser.IsInRoleAsync("HR") && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        var f=await db.InterviewFeedback.FirstOrDefaultAsync(x=>x.InterviewId==interviewId) ?? new InterviewFeedback{InterviewId=interviewId};
        f.OverallRating=r.OverallRating;f.TechnicalSkills=r.TechnicalSkills;f.CommunicationSkills=r.CommunicationSkills;f.ProblemSolving=r.ProblemSolving;f.Strengths=r.Strengths;f.ImprovementAreas=r.ImprovementAreas;f.Comments=r.Comments;f.SubmittedByUserId=user.Id;f.SubmittedAt=DateTime.UtcNow;
        if(f.Id==0)db.InterviewFeedback.Add(f);i.Status="Completed";if(i.Referral!=null)i.Referral.Status=i.RoundNo<3?$"Interview {i.RoundNo} Completed":"Final Approval";
        await db.SaveChangesAsync();
        var hr = await db.Users.AsNoTracking().Where(u => u.IsActive && (u.Role == "HR" || u.Role == "HRHead")).Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync();
        await notifications.SendAsync("InterviewFeedbackSubmitted", hr, $"Interview {i.RoundNo} feedback submitted: {i.Referral!.CandidateName}", $"<p>Feedback for interview <b>{i.RoundNo}</b> has been submitted for <b>{System.Net.WebUtility.HtmlEncode(i.Referral!.CandidateName)}</b>.</p><p>Overall rating: {f.OverallRating}/5</p>", "Interview", i.Id);
        return Ok(f);
    }

    [HttpPost("{id:int}/final-approval/{level}")]
    public async Task<IActionResult> FinalApproval(int id,string level,FinalApprovalRequest r)
    {
        if(level is not ("DivisionHead" or "HRHead")) return BadRequest("Invalid approval level.");
        var normalized=level=="DivisionHead"?"Division Head":"HR Head";
        var x=await db.Referrals.Include(z=>z.FinalApprovals).FirstOrDefaultAsync(z=>z.Id==id);if(x is null)return NotFound();
        var requiredRole = normalized == "Division Head" ? "DivHead" : "HRHead";
        if (!await currentUser.IsInRoleAsync(requiredRole) && !await currentUser.IsInRoleAsync("Admin")) return Forbid();
        if (normalized == "Division Head") { var round3 = await db.Interviews.Include(z=>z.Feedback).FirstOrDefaultAsync(z=>z.ReferralId==id && z.RoundNo==3); if (round3?.Status != "Completed" || round3.Feedback is null) return BadRequest("Interview 3 feedback must be completed before Division Head approval."); }
        if (normalized == "HR Head") { var div = x.FinalApprovals.FirstOrDefault(z=>z.ApprovalLevel=="Division Head"); if (div?.Status != "Approved") return BadRequest("Division Head approval is required before HR Head approval."); }
        var user=await currentUser.GetOrCreateAsync();var a=x.FinalApprovals.FirstOrDefault(z=>z.ApprovalLevel==normalized);if(a is null)return BadRequest("Approval not configured.");
        a.Status=r.Status;a.Comments=r.Comments;a.ApproverUserId=user.Id;a.ActionAt=DateTime.UtcNow;
        if(r.Status=="Rejected")x.Status="Rejected";else if(x.FinalApprovals.All(z=>z.Status=="Approved"))x.Status="Hired";else x.Status="Final Approval";
        x.UpdatedAt=DateTime.UtcNow;await db.SaveChangesAsync();
        var recipients = new List<NotificationRecipient>();
        if (r.Status == "Approved" && normalized == "Division Head") { recipients = await db.Users.AsNoTracking().Where(u => u.IsActive && u.Role == "HRHead").Select(u => new NotificationRecipient(u.Email, u.FullName)).ToListAsync(); }
        if (r.Status == "Approved" && normalized == "HR Head") { var referrer = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == x.ReferrerUserId); if (referrer != null) recipients.Add(new(referrer.Email, referrer.FullName)); recipients.Add(new(x.CandidateEmail, x.CandidateName)); }
        if (r.Status == "Rejected") { var referrer = await db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == x.ReferrerUserId); if (referrer != null) recipients.Add(new(referrer.Email, referrer.FullName)); }
        if (recipients.Count > 0) await notifications.SendAsync("FinalApproval", recipients, $"Referral status: {x.CandidateName} - {x.Status}", $"<p>Referral for <b>{System.Net.WebUtility.HtmlEncode(x.CandidateName)}</b> is now <b>{x.Status}</b>.</p>", "Referral", x.Id);
        return Ok(x);
    }

    [HttpPost("{id:int}/resume"), RequestSizeLimit(10_000_000)]
    public async Task<IActionResult> UploadResume(int id, IFormFile file, CancellationToken ct)
    {
        if (file is null || file.Length == 0) return BadRequest("Resume file is required.");
        if (file.Length > 10_000_000) return BadRequest("Maximum resume size is 10 MB.");
        var allowed = new[] { ".pdf", ".doc", ".docx" };
        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!allowed.Contains(extension)) return BadRequest("Only PDF, DOC and DOCX resumes are allowed.");
        var referral = await db.Referrals.FindAsync([id], ct);
        if (referral is null) return NotFound();
        await using var stream = file.OpenReadStream();
        var result = await sharePoint.UploadResumeAsync(id, file.FileName, stream, file.ContentType, ct);
        referral.ResumeFileName = result.FileName; referral.ResumePath = result.WebUrl; referral.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(ct);
        return Ok(result);
    }

    [HttpPut("{id:int}/status")]
    public async Task<IActionResult> Status(int id,StatusRequest r)
    {
        if(!await currentUser.IsInRoleAsync("HR")&&!await currentUser.IsInRoleAsync("HRHead")&&!await currentUser.IsInRoleAsync("Admin"))return Forbid();
        var x=await db.Referrals.FindAsync(id);if(x is null)return NotFound();x.Status=r.Status;x.UpdatedAt=DateTime.UtcNow;await db.SaveChangesAsync();return Ok(x);
    }
}
