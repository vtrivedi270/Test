namespace EmployeeReferral.Api.Services;

public sealed record FileUploadResult(string FileName, string ServerRelativeUrl, string WebUrl);
public interface IFileStorageService
{
    Task<FileUploadResult> UploadResumeAsync(int referralId, string fileName, Stream content, string? contentType, CancellationToken ct = default);
}

public sealed class LocalFileService(IWebHostEnvironment env) : IFileStorageService
{
    public async Task<FileUploadResult> UploadResumeAsync(int referralId, string fileName, Stream content, string? contentType, CancellationToken ct = default)
    {
        var safe = string.Concat(Path.GetFileNameWithoutExtension(fileName).Where(c => char.IsLetterOrDigit(c) || c is ' ' or '_' or '-')) + Path.GetExtension(fileName).ToLowerInvariant();
        if (string.IsNullOrWhiteSpace(safe) || safe == ".") safe = $"resume_{Guid.NewGuid():N}.pdf";
        var dir = Path.Combine(env.ContentRootPath, "storage", "resumes", $"REF-{referralId}");
        Directory.CreateDirectory(dir);
        var path = Path.Combine(dir, safe);
        await using var output = File.Create(path);
        await content.CopyToAsync(output, ct);
        var relative = $"/storage/resumes/REF-{referralId}/{Uri.EscapeDataString(safe)}";
        return new(safe, relative, relative);
    }
}
