namespace EmployeeReferral.Api.Services;

public sealed record CalendarMeetingResult(string EventId, string JoinUrl);
public interface ICalendarService
{
    Task<CalendarMeetingResult?> CreateInterviewEventAsync(string subject, string htmlBody, DateTime startUtc, DateTime endUtc, IEnumerable<(string Email, string Name)> attendees, CancellationToken ct = default);
}

public sealed class LocalCalendarService : ICalendarService
{
    public Task<CalendarMeetingResult?> CreateInterviewEventAsync(string subject, string htmlBody, DateTime startUtc, DateTime endUtc, IEnumerable<(string Email, string Name)> attendees, CancellationToken ct = default)
        => Task.FromResult<CalendarMeetingResult?>(new($"LOCAL-{Guid.NewGuid():N}", $"http://localhost:5173/local-meeting/{Guid.NewGuid():N}"));
}
