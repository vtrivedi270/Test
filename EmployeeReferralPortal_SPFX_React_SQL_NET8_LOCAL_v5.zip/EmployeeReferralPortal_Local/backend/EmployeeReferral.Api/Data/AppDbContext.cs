using EmployeeReferral.Api.Models;
using Microsoft.EntityFrameworkCore;

namespace EmployeeReferral.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> options) : DbContext(options)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Job> Jobs => Set<Job>();
    public DbSet<JobApproval> JobApprovals => Set<JobApproval>();
    public DbSet<Referral> Referrals => Set<Referral>();
    public DbSet<Interview> Interviews => Set<Interview>();
    public DbSet<InterviewFeedback> InterviewFeedback => Set<InterviewFeedback>();
    public DbSet<FinalApproval> FinalApprovals => Set<FinalApproval>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();
    public DbSet<NotificationLog> NotificationLogs => Set<NotificationLog>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<User>().HasIndex(x => x.Email).IsUnique();
        b.Entity<Job>().HasMany(x => x.Approvals).WithOne(x => x.Job).HasForeignKey(x => x.JobId);
        b.Entity<Referral>().HasMany(x => x.Interviews).WithOne(x => x.Referral).HasForeignKey(x => x.ReferralId);
        b.Entity<Referral>().HasMany(x => x.FinalApprovals).WithOne(x => x.Referral).HasForeignKey(x => x.ReferralId);
        b.Entity<Interview>().HasOne(x => x.Feedback).WithOne(x => x.Interview).HasForeignKey<InterviewFeedback>(x => x.InterviewId);
        b.Entity<InterviewFeedback>().HasIndex(x => x.InterviewId).IsUnique();
    }
}
