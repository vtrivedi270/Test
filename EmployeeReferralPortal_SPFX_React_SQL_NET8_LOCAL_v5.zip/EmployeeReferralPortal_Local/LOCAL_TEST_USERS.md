# Local UAT Users

The standalone React UI can call the local API with these users. Before opening the UI, set values in browser localStorage:

```js
localStorage.setItem('erp.dev.email','manager@local.test');
localStorage.setItem('erp.dev.name','Rahul Manager');
localStorage.setItem('erp.dev.role','Manager');
location.reload();
```

Roles:

- Employee: employee@local.test
- Manager: manager@local.test
- DeptHead: depthead@local.test
- DivHead: divhead@local.test
- HR: hr@local.test
- HRHead: hrhead@local.test
- Interviewer: interviewer@local.test
- Admin: admin@local.test

This is only a local UAT shortcut and is not authentication.
