# Employee Referral Portal - LOCAL MODE

This package removes tenant-specific Entra ID, JWT, Microsoft Graph, and SharePoint dependencies so the application can be run locally.

## What LOCAL mode does

- SPFx React source remains available and has **no webApiPermissionRequests**.
- The local .NET 8 API uses a development authentication handler based on `X-Dev-User` / `X-Dev-Role` headers.
- Email notifications are written to `backend/EmployeeReferral.Api/local-mailbox/` and SQL `NotificationLogs`; no external email is sent.
- Interview calendar/Teams links are generated as local placeholder URLs.
- Resumes are stored in `backend/EmployeeReferral.Api/storage/resumes/` instead of SharePoint.
- SQL Server LocalDB is the default database.

## 1. Requirements

- Windows 10/11
- Node.js 22 LTS
- .NET 8 SDK
- SQL Server Express LocalDB (installed with Visual Studio or SQL Server Express)
- Git optional

## 2. Create database

Open SQL Server Management Studio or `sqlcmd` and run:

1. `database/01_schema.sql`
2. `database/02_seed.sql`

If the database does not exist, create `EmployeeReferralPortalLocal` first or change the connection string in `backend/EmployeeReferral.Api/appsettings.json`.

## 3. Run API

```powershell
cd backend/EmployeeReferral.Api
dotnet restore
dotnet run
```

Swagger will normally be available at the HTTPS/HTTP URL printed by `dotnet run`.

## 4. Run the SPFx source

```powershell
cd spfx/employee-referral-portal
npm install
npm run build
```

The build generates the `.sppkg` under the `sharepoint/solution` output path. No tenant ID, API client ID, audience, Graph secret, or SharePoint library configuration is required to build the package.

> SPFx itself is designed to run inside SharePoint. For a completely standalone local browser preview, use the `frontend` folder below. The generated `.sppkg` can be deployed later to SharePoint after tenant configuration is intentionally reintroduced.

## 5. Run standalone local UI

```powershell
cd frontend
npm install
npm run dev
```

Set the API URL in `frontend/.env` if the API is not using the default local URL.

## Local test users

The API accepts these development roles through request headers. The UI can be extended with a role selector for UAT:

- Vishal Trivedi / vishal@local.test / Employee
- Rahul Manager / manager@local.test / Manager
- Dept Head / depthead@local.test / DeptHead
- Division Head / divhead@local.test / DivHead
- HR User / hr@local.test / HR
- HR Head / hrhead@local.test / HRHead
- Interviewer / interviewer@local.test / Interviewer
- Admin / admin@local.test / Admin

This local authentication is **not secure and must never be used in production**.

## Production later

When ready, reintroduce Entra JWT, Graph, SharePoint, Key Vault, and the real M365 permissions in a separate production configuration.
