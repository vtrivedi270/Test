$ErrorActionPreference = 'Stop'
Write-Host '=== Employee Referral Portal local package build ===' -ForegroundColor Cyan
Write-Host '1. Restoring/building .NET API'
Push-Location "$PSScriptRoot/backend/EmployeeReferral.Api"
dotnet restore
dotnet build -c Release
Pop-Location
Write-Host '2. Building SPFx solution'
Push-Location "$PSScriptRoot/spfx/employee-referral-portal"
npm install
npm run build
Pop-Location
Write-Host 'Build completed.' -ForegroundColor Green
