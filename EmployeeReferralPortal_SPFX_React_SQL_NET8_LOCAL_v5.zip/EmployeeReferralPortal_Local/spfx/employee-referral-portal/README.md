# Employee Referral Portal - SPFx Local Mode

This is a tenant-free local development build.

- No Entra app registration
- No JWT configuration
- No Microsoft Graph
- No SharePoint API permission request
- No client secret
- Local API uses development headers only

Build the `.sppkg` with:

```powershell
npm install
npm run build
```

The package can be generated without a tenant. To actually deploy the `.sppkg` into SharePoint and use secure M365 authentication, create a separate production configuration later.
