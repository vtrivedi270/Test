import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Version } from '@microsoft/sp-core-library';
import { BaseClientSideWebPart, IPropertyPaneConfiguration, PropertyPaneTextField } from '@microsoft/sp-webpart-base';
import { IEmployeeReferralPortalProps } from './components/IEmployeeReferralPortalProps';
import EmployeeReferralPortal from './components/EmployeeReferralPortal';

export interface IEmployeeReferralPortalWebPartProps { apiBaseUrl: string; resumeFolder: string; }

export default class EmployeeReferralPortalWebPart extends BaseClientSideWebPart<IEmployeeReferralPortalWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IEmployeeReferralPortalProps> = React.createElement(EmployeeReferralPortal, {
      context: this.context,
      apiBaseUrl: this.properties.apiBaseUrl || 'https://localhost:7001',
      resumeFolder: this.properties.resumeFolder || 'Shared Documents/EmployeeReferrals'
    });
    ReactDom.render(element, this.domElement);
  }
  protected onDispose(): void { ReactDom.unmountComponentAtNode(this.domElement); }
  protected get dataVersion(): Version { return Version.parse('2.0'); }
  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return { pages: [{ header: { description: 'Employee Referral Portal configuration' }, groups: [{ groupName: 'API / SharePoint', groupFields: [
      PropertyPaneTextField('apiBaseUrl', { label: 'API Base URL', description: 'Example: https://api.contoso.com' }),
      PropertyPaneTextField('resumeFolder', { label: 'Resume folder', description: 'Example: Shared Documents/EmployeeReferrals' })
    ] }] }] };
  }
}
