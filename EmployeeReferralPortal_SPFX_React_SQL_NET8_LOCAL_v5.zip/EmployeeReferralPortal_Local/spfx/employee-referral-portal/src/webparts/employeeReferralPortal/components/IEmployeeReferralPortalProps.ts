import { WebPartContext } from '@microsoft/sp-webpart-base';

export interface IEmployeeReferralPortalProps {
  context: WebPartContext;
  apiBaseUrl: string;
  resumeFolder: string;
}
