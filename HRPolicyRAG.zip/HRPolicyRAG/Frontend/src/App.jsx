import { useState } from "react";
import { uploadPolicy, askQuestion, isLoggedIn, logout } from "./api";
import Login from "./Login";

export default function App() {
  const [loggedIn, setLoggedIn] = useState(isLoggedIn());
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const [asking, setAsking] = useState(false);

  if (!loggedIn) {
    return <Login onLoggedIn={() => setLoggedIn(true)} />;
  }

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await uploadPolicy(file);
      setMessages((m) => [
        ...m,
        { role: "system", text: `Ingested "${result.fileName}" — ${result.chunksCreated} chunks from ${result.pagesProcessed} pages.` }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "system", text: "Upload failed: " + err.message }]);
    } finally {
      setUploading(false);
    }
  };

  const handleAsk = async () => {
    if (!input.trim()) return;
    const question = input;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setAsking(true);
    try {
      const result = await askQuestion(question);
      setMessages((m) => [
        ...m,
        { role: "assistant", text: result.answer, sources: result.sources }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: "Error: " + err.message }]);
    } finally {
      setAsking(false);
    }
  };

  return (
    <div style={{ maxWidth: 720, margin: "40px auto", fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <h2>HR Policy Assistant</h2>
        <button onClick={() => { logout(); setLoggedIn(false); }}>Log out</button>
      </div>

      <div style={{ marginBottom: 20 }}>
        <label>
          Upload HR Policy PDF:{" "}
          <input type="file" accept=".pdf" onChange={handleUpload} disabled={uploading} />
        </label>
        {uploading && <span> Processing...</span>}
      </div>

      <div style={{ border: "1px solid #ddd", borderRadius: 8, padding: 16, minHeight: 300, marginBottom: 12 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ marginBottom: 12 }}>
            <strong>{m.role === "user" ? "You" : m.role === "assistant" ? "Assistant" : "System"}:</strong>
            <div>{m.text}</div>
            {m.sources && m.sources.length > 0 && (
              <div style={{ fontSize: 12, color: "#666" }}>Sources: {m.sources.join(", ")}</div>
            )}
          </div>
        ))}
      </div>

      <div style={{ display: "flex", gap: 8 }}>
        <input
          style={{ flex: 1, padding: 8 }}
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAsk()}
          placeholder="Ask about leave policy, expenses, WFH rules..."
        />
        <button onClick={handleAsk} disabled={asking}>
          {asking ? "Thinking..." : "Ask"}
        </button>
      </div>
    </div>
  );
}
