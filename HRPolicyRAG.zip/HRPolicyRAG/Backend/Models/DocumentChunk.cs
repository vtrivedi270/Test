namespace HRPolicyRAG.Api.Models;

public class DocumentChunk
{
    public int Id { get; set; }
    public string SourceFile { get; set; } = string.Empty;
    public string SectionHint { get; set; } = string.Empty; // e.g. "Leave Policy > Section 4.2"
    public string Text { get; set; } = string.Empty;
    public float[] Embedding { get; set; } = Array.Empty<float>();
}

public class QueryRequest
{
    public string Question { get; set; } = string.Empty;
    public int TopK { get; set; } = 4;
}

public class QueryResponse
{
    public string Answer { get; set; } = string.Empty;
    public List<string> Sources { get; set; } = new();
}
