using System.Text;
using System.Text.Json;

namespace HRPolicyRAG.Api.Services;

public class OllamaService
{
    private readonly HttpClient _http;
    private readonly string _baseUrl;
    private readonly string _embedModel;
    private readonly string _chatModel;

    public OllamaService(IConfiguration config)
    {
        _http = new HttpClient();
        _baseUrl = config["Ollama:BaseUrl"] ?? "http://localhost:11434";
        _embedModel = config["Ollama:EmbedModel"] ?? "nomic-embed-text";
        _chatModel = config["Ollama:ChatModel"] ?? "llama3";
    }

    public async Task<float[]> GetEmbeddingAsync(string text)
    {
        var payload = JsonSerializer.Serialize(new { model = _embedModel, prompt = text });
        var response = await _http.PostAsync($"{_baseUrl}/api/embeddings",
            new StringContent(payload, Encoding.UTF8, "application/json"));
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);
        var arr = doc.RootElement.GetProperty("embedding");

        var result = new float[arr.GetArrayLength()];
        int i = 0;
        foreach (var v in arr.EnumerateArray())
            result[i++] = v.GetSingle();

        return result;
    }

    public async Task<string> ChatAsync(string question, List<string> contextChunks)
    {
        var context = string.Join("\n---\n", contextChunks);
        var prompt = $"""
            You are an HR policy assistant. Answer ONLY using the policy excerpts below.
            If the answer isn't in the excerpts, say you don't have that policy information
            and recommend contacting HR directly. Cite the relevant section when possible.

            Policy excerpts:
            {context}

            Employee question: {question}

            Answer:
            """;

        var payload = JsonSerializer.Serialize(new
        {
            model = _chatModel,
            prompt,
            stream = false
        });

        var response = await _http.PostAsync($"{_baseUrl}/api/generate",
            new StringContent(payload, Encoding.UTF8, "application/json"));
        response.EnsureSuccessStatusCode();

        var json = await response.Content.ReadAsStringAsync();
        using var doc = JsonDocument.Parse(json);
        return doc.RootElement.GetProperty("response").GetString() ?? "";
    }

    public static float CosineSimilarity(float[] a, float[] b)
    {
        float dot = 0, magA = 0, magB = 0;
        for (int i = 0; i < a.Length; i++)
        {
            dot += a[i] * b[i];
            magA += a[i] * a[i];
            magB += b[i] * b[i];
        }
        if (magA == 0 || magB == 0) return 0;
        return dot / (MathF.Sqrt(magA) * MathF.Sqrt(magB));
    }
}
