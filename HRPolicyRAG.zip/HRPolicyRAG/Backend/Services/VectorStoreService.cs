using System.Text.Json;
using HRPolicyRAG.Api.Models;
using Microsoft.Data.Sqlite;

namespace HRPolicyRAG.Api.Services;

/// <summary>
/// Stores chunks + embeddings in SQLite (as JSON blobs). For HR-policy-scale
/// document sets (dozens to a few hundred pages) brute-force cosine search
/// over an in-memory cache is fast enough — no vector DB extension required.
/// </summary>
public class VectorStoreService
{
    private readonly string _dbPath;
    private List<DocumentChunk>? _cache;

    public VectorStoreService(IConfiguration config)
    {
        _dbPath = config["Storage:SqlitePath"] ?? "hrpolicy.db";
        EnsureDb();
    }

    private void EnsureDb()
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            CREATE TABLE IF NOT EXISTS Chunks (
                Id INTEGER PRIMARY KEY AUTOINCREMENT,
                SourceFile TEXT,
                SectionHint TEXT,
                Text TEXT,
                Embedding TEXT
            );
            """;
        cmd.ExecuteNonQuery();
    }

    public void AddChunk(DocumentChunk chunk)
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            INSERT INTO Chunks (SourceFile, SectionHint, Text, Embedding)
            VALUES ($src, $section, $text, $emb);
            """;
        cmd.Parameters.AddWithValue("$src", chunk.SourceFile);
        cmd.Parameters.AddWithValue("$section", chunk.SectionHint);
        cmd.Parameters.AddWithValue("$text", chunk.Text);
        cmd.Parameters.AddWithValue("$emb", JsonSerializer.Serialize(chunk.Embedding));
        cmd.ExecuteNonQuery();

        _cache = null; // invalidate cache
    }

    public List<DocumentChunk> GetAllChunks()
    {
        if (_cache != null) return _cache;

        var chunks = new List<DocumentChunk>();
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT Id, SourceFile, SectionHint, Text, Embedding FROM Chunks;";
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            chunks.Add(new DocumentChunk
            {
                Id = reader.GetInt32(0),
                SourceFile = reader.GetString(1),
                SectionHint = reader.GetString(2),
                Text = reader.GetString(3),
                Embedding = JsonSerializer.Deserialize<float[]>(reader.GetString(4)) ?? Array.Empty<float>()
            });
        }

        _cache = chunks;
        return chunks;
    }

    public List<DocumentChunk> Search(float[] queryEmbedding, int topK)
    {
        return GetAllChunks()
            .Select(c => (Chunk: c, Score: OllamaService.CosineSimilarity(c.Embedding, queryEmbedding)))
            .OrderByDescending(x => x.Score)
            .Take(topK)
            .Select(x => x.Chunk)
            .ToList();
    }
}
