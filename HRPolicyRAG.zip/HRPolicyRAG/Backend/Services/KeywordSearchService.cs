using Microsoft.Data.Sqlite;

namespace HRPolicyRAG.Api.Services;

/// <summary>
/// Pure keyword search over policy chunks using SQLite FTS5 — no embeddings,
/// no LLM, no Ollama dependency. Returns matching excerpts directly instead
/// of a synthesized answer. Use this when "Mode" in appsettings is "KeywordSearch".
/// </summary>
public class KeywordSearchService
{
    private readonly string _dbPath;

    public KeywordSearchService(IConfiguration config)
    {
        _dbPath = config["Storage:SqlitePath"] ?? "hrpolicy.db";
        EnsureTable();
    }

    private void EnsureTable()
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            CREATE VIRTUAL TABLE IF NOT EXISTS ChunksFts USING fts5(
                SourceFile,
                SectionHint,
                Text
            );
            """;
        cmd.ExecuteNonQuery();
    }

    public void AddChunk(string sourceFile, string sectionHint, string text)
    {
        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            INSERT INTO ChunksFts (SourceFile, SectionHint, Text)
            VALUES ($src, $section, $text);
            """;
        cmd.Parameters.AddWithValue("$src", sourceFile);
        cmd.Parameters.AddWithValue("$section", sectionHint);
        cmd.Parameters.AddWithValue("$text", text);
        cmd.ExecuteNonQuery();
    }

    public record SearchHit(string SourceFile, string SectionHint, string Snippet);

    /// <summary>
    /// FTS5 MATCH search with ranking and a highlighted snippet of the hit.
    /// </summary>
    public List<SearchHit> Search(string query, int topK = 5)
    {
        // FTS5 chokes on raw punctuation in queries; keep it to safe tokens.
        var sanitized = string.Join(" ", query.Split(' ', StringSplitOptions.RemoveEmptyEntries)
            .Select(w => "\"" + w.Replace("\"", "") + "\"*"));

        if (string.IsNullOrWhiteSpace(sanitized))
            return new List<SearchHit>();

        using var conn = new SqliteConnection($"Data Source={_dbPath}");
        conn.Open();
        var cmd = conn.CreateCommand();
        cmd.CommandText = """
            SELECT SourceFile, SectionHint,
                   snippet(ChunksFts, 2, '<mark>', '</mark>', '...', 20) AS Snip
            FROM ChunksFts
            WHERE ChunksFts MATCH $q
            ORDER BY rank
            LIMIT $topK;
            """;
        cmd.Parameters.AddWithValue("$q", sanitized);
        cmd.Parameters.AddWithValue("$topK", topK);

        var results = new List<SearchHit>();
        using var reader = cmd.ExecuteReader();
        while (reader.Read())
        {
            results.Add(new SearchHit(reader.GetString(0), reader.GetString(1), reader.GetString(2)));
        }

        return results;
    }
}
