using HRPolicyRAG.Api.Models;
using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HRPolicyRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Microsoft.AspNetCore.Authorization.Authorize]
public class IngestController : ControllerBase
{
    private readonly PdfIngestionService _pdf;
    private readonly ChunkingService _chunker;
    private readonly OllamaService _ollama;
    private readonly VectorStoreService _store;
    private readonly KeywordSearchService _keywordStore;
    private readonly IConfiguration _config;

    public IngestController(PdfIngestionService pdf, ChunkingService chunker,
        OllamaService ollama, VectorStoreService store, KeywordSearchService keywordStore,
        IConfiguration config)
    {
        _pdf = pdf;
        _chunker = chunker;
        _ollama = ollama;
        _store = store;
        _keywordStore = keywordStore;
        _config = config;
    }

    [HttpPost("upload")]
    public async Task<IActionResult> Upload(IFormFile file)
    {
        if (file == null || file.Length == 0)
            return BadRequest("No file uploaded.");

        var mode = _config["Mode"] ?? "AI";
        var tempPath = Path.GetTempFileName();
        await using (var stream = System.IO.File.Create(tempPath))
            await file.CopyToAsync(stream);

        var pages = _pdf.ExtractPages(tempPath);
        int chunkCount = 0;

        foreach (var (pageNumber, text) in pages)
        {
            var chunks = _chunker.Chunk(text);
            foreach (var chunkText in chunks)
            {
                if (mode == "KeywordSearch")
                {
                    // No embeddings, no LLM — just store the raw text for full-text search.
                    _keywordStore.AddChunk(file.FileName, $"Page {pageNumber}", chunkText);
                }
                else
                {
                    var embedding = await _ollama.GetEmbeddingAsync(chunkText);
                    _store.AddChunk(new DocumentChunk
                    {
                        SourceFile = file.FileName,
                        SectionHint = $"Page {pageNumber}",
                        Text = chunkText,
                        Embedding = embedding
                    });
                }
                chunkCount++;
            }
        }

        System.IO.File.Delete(tempPath);

        return Ok(new { file.FileName, PagesProcessed = pages.Count, ChunksCreated = chunkCount, Mode = mode });
    }
}
