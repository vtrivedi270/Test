using HRPolicyRAG.Api.Models;
using HRPolicyRAG.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace HRPolicyRAG.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
[Microsoft.AspNetCore.Authorization.Authorize]
public class QueryController : ControllerBase
{
    private readonly OllamaService _ollama;
    private readonly VectorStoreService _store;
    private readonly KeywordSearchService _keywordStore;
    private readonly IConfiguration _config;

    public QueryController(OllamaService ollama, VectorStoreService store,
        KeywordSearchService keywordStore, IConfiguration config)
    {
        _ollama = ollama;
        _store = store;
        _keywordStore = keywordStore;
        _config = config;
    }

    [HttpPost("ask")]
    public async Task<ActionResult<QueryResponse>> Ask([FromBody] QueryRequest request)
    {
        if (string.IsNullOrWhiteSpace(request.Question))
            return BadRequest("Question cannot be empty.");

        var mode = _config["Mode"] ?? "AI";

        if (mode == "KeywordSearch")
        {
            // No AI/LLM at all: return the matching excerpts directly.
            var hits = _keywordStore.Search(request.Question, request.TopK);

            if (hits.Count == 0)
                return Ok(new QueryResponse
                {
                    Answer = "No matching policy text found. Try different keywords, or contact HR directly.",
                    Sources = new List<string>()
                });

            var combined = string.Join("\n\n", hits.Select(h => $"[{h.SourceFile}, {h.SectionHint}]\n{h.Snippet}"));

            return Ok(new QueryResponse
            {
                Answer = combined,
                Sources = hits.Select(h => $"{h.SourceFile} ({h.SectionHint})").Distinct().ToList()
            });
        }

        // AI mode: embeddings + local LLM synthesized answer
        var queryEmbedding = await _ollama.GetEmbeddingAsync(request.Question);
        var topChunks = _store.Search(queryEmbedding, request.TopK);

        if (topChunks.Count == 0)
            return Ok(new QueryResponse
            {
                Answer = "No HR policy documents have been ingested yet. Please upload a policy PDF first.",
                Sources = new List<string>()
            });

        var answer = await _ollama.ChatAsync(request.Question, topChunks.Select(c => c.Text).ToList());

        return Ok(new QueryResponse
        {
            Answer = answer,
            Sources = topChunks.Select(c => $"{c.SourceFile} ({c.SectionHint})").Distinct().ToList()
        });
    }
}
