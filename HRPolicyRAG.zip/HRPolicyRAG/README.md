# HR Policy RAG Assistant (100% Free, Fully Local)

A local RAG app that answers employee questions from your HR policy PDFs.
No API keys, no cloud calls, no data leaves your machine — powered by Ollama.

## Stack
- Backend: .NET 8 Web API + PdfPig (PDF parsing) + SQLite (chunk/embedding storage)
- LLM: Ollama running locally (embeddings + chat)
- Frontend: React + Vite

## Setup

### 1. Install Ollama (free)
Download from https://ollama.com, then pull the models:
```bash
ollama pull nomic-embed-text
ollama pull llama3
```
Ollama runs a local server at `http://localhost:11434` automatically.

### 2. Run the backend
```bash
cd Backend
dotnet restore
dotnet run
```
API runs at `http://localhost:5000` (check your launch profile — adjust CORS
origin/API_BASE in the frontend if it uses a different port).

### 3. Run the frontend
```bash
cd Frontend
npm install
npm run dev
```
Opens at `http://localhost:5173`.

### 4. Use it
1. Upload an HR policy PDF via the file picker.
2. Wait for "Ingested... chunks created" confirmation.
3. Ask questions like "How many casual leaves do I get per year?"

## Two modes: AI (RAG) or Keyword Search (no AI at all)

Set `"Mode"` in `Backend/appsettings.json` to either:

- **`"AI"`** (default) — embeddings via Ollama + local LLM synthesizes a
  natural-language answer from matched policy chunks. Requires Ollama running.
- **`"KeywordSearch"`** — pure SQLite FTS5 full-text search. No embeddings,
  no LLM, no Ollama dependency at all. Returns the matching policy excerpts
  directly (with `<mark>` highlighted terms) instead of a synthesized answer.
  Zero AI infrastructure required — just the .NET API and SQLite.

Switching modes doesn't require any frontend changes — same upload/ask
endpoints, same response shape. Note: chunks ingested in one mode aren't
visible in the other (they're stored in separate tables), so re-upload your
PDFs after switching modes.

## How it works (RAG pipeline, AI mode)
1. **Ingest** — PdfPig extracts text per page from the uploaded PDF.
2. **Chunk** — text is split into ~350-word overlapping chunks.
3. **Embed** — each chunk is embedded locally via Ollama (`nomic-embed-text`).
4. **Store** — chunks + embeddings are saved in a local SQLite file (`hrpolicy.db`).
5. **Query** — user question is embedded, compared via cosine similarity
   against stored chunks, top-K matches retrieved.
6. **Generate** — matched chunks + question are sent to a local LLM
   (`llama3` via Ollama) which answers strictly from the provided context.

## Keyword Search mode pipeline (no AI)
1. **Ingest** — same PDF/page extraction and chunking as AI mode.
2. **Store** — chunks go straight into a SQLite FTS5 virtual table as plain text.
3. **Query** — the question is tokenized and run as an FTS5 `MATCH` query;
   results are ranked by SQLite's built-in relevance ranking.
4. **Response** — the top matching excerpts are returned as-is (highlighted),
   with source file + page. No generation step, nothing to hallucinate.

## Scaling notes
- Current search is brute-force cosine similarity in C# — fine up to a few
  thousand chunks (dozens of policy documents). Beyond that, swap
  `VectorStoreService` for a dedicated vector DB (Qdrant, Chroma) — the
  interface is already isolated so this is a drop-in replacement.
- Swap `llama3` for a smaller model (e.g. `phi3`) if running on modest hardware.

## Notes
- This scaffold hasn't been build-tested in this environment (no network
  access here to restore NuGet/npm packages) — run `dotnet restore` and
  `npm install` on your machine to pull dependencies before running.
- For production/multi-user HR use, add authentication and role-based
  access before exposing this beyond your local machine.
