import * as React from "react";
import * as ReactDom from "react-dom";
import { Version } from "@microsoft/sp-core-library";
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";

import HrPolicyAssistant, { IHrPolicyAssistantProps } from "./components/HrPolicyAssistant";

export interface IHrPolicyAssistantWebPartProps {
  apiBaseUrl: string;
}

export default class HrPolicyAssistantWebPart extends BaseClientSideWebPart<IHrPolicyAssistantWebPartProps> {
  public render(): void {
    const element: React.ReactElement<IHrPolicyAssistantProps> = React.createElement(
      HrPolicyAssistant,
      {
        apiBaseUrl: this.properties.apiBaseUrl || "http://localhost:5000/api",
        userDisplayName: this.context.pageContext.user.displayName
      }
    );

    ReactDom.render(element, this.domElement);
  }

  protected onDispose(): void {
    ReactDom.unmountComponentAtNode(this.domElement);
  }

  protected get dataVersion(): Version {
    return Version.parse("1.0");
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: { description: "HR Policy Assistant settings" },
          groups: [
            {
              groupName: "API Connection",
              groupFields: [
                PropertyPaneTextField("apiBaseUrl", {
                  label: "Backend API base URL",
                  description: "e.g. https://your-internal-host/api"
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
