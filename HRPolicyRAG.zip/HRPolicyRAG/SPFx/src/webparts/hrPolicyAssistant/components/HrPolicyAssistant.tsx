import * as React from "react";
import styles from "./HrPolicyAssistant.module.scss";

export interface IHrPolicyAssistantProps {
  apiBaseUrl: string;
  userDisplayName: string;
}

interface IMessage {
  role: "user" | "assistant" | "system";
  text: string;
  sources?: string[];
}

const TOKEN_KEY = "hrrag_spfx_token";

const HrPolicyAssistant: React.FC<IHrPolicyAssistantProps> = ({ apiBaseUrl, userDisplayName }) => {
  const [token, setToken] = React.useState<string | null>(sessionStorage.getItem(TOKEN_KEY));
  const [username, setUsername] = React.useState("");
  const [password, setPassword] = React.useState("");
  const [loginError, setLoginError] = React.useState("");
  const [messages, setMessages] = React.useState<IMessage[]>([]);
  const [input, setInput] = React.useState("");
  const [busy, setBusy] = React.useState(false);

  const authHeader = (): Record<string, string> =>
    token ? { Authorization: `Bearer ${token}` } : {};

  const handleLogin = async (e: React.FormEvent): Promise<void> => {
    e.preventDefault();
    setLoginError("");
    try {
      const res = await fetch(`${apiBaseUrl}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      if (!res.ok) throw new Error("Invalid username or password");
      const data = await res.json();
      sessionStorage.setItem(TOKEN_KEY, data.token);
      setToken(data.token);
    } catch (err) {
      setLoginError((err as Error).message);
    }
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    setBusy(true);
    try {
      const res = await fetch(`${apiBaseUrl}/ingest/upload`, {
        method: "POST",
        headers: { ...authHeader() },
        body: formData
      });
      const data = await res.json();
      setMessages((m) => [
        ...m,
        { role: "system", text: `Ingested "${data.fileName}" — ${data.chunksCreated} chunks.` }
      ]);
    } catch (err) {
      setMessages((m) => [...m, { role: "system", text: "Upload failed: " + (err as Error).message }]);
    } finally {
      setBusy(false);
    }
  };

  const handleAsk = async (): Promise<void> => {
    if (!input.trim()) return;
    const question = input;
    setInput("");
    setMessages((m) => [...m, { role: "user", text: question }]);
    setBusy(true);
    try {
      const res = await fetch(`${apiBaseUrl}/query/ask`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeader() },
        body: JSON.stringify({ question, topK: 4 })
      });
      const data = await res.json();
      setMessages((m) => [...m, { role: "assistant", text: data.answer, sources: data.sources }]);
    } catch (err) {
      setMessages((m) => [...m, { role: "assistant", text: "Error: " + (err as Error).message }]);
    } finally {
      setBusy(false);
    }
  };

  if (!token) {
    return (
      <div className={styles.hrPolicyAssistant}>
        <h2>HR Policy Assistant</h2>
        <p>Hi {userDisplayName}, please sign in with your HR-provided credentials.</p>
        <form onSubmit={handleLogin}>
          <input placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          {loginError && <div className={styles.error}>{loginError}</div>}
          <button type="submit">Log in</button>
        </form>
      </div>
    );
  }

  return (
    <div className={styles.hrPolicyAssistant}>
      <h2>HR Policy Assistant</h2>
      <input type="file" accept=".pdf" onChange={handleUpload} disabled={busy} />
      <div className={styles.messages}>
        {messages.map((m, i) => (
          <div key={i} className={styles.message}>
            <strong>{m.role}:</strong> {m.text}
            {m.sources && m.sources.length > 0 && (
              <div className={styles.sources}>Sources: {m.sources.join(", ")}</div>
            )}
          </div>
        ))}
      </div>
      <div className={styles.inputRow}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleAsk()}
          placeholder="Ask about leave, WFH, expenses..."
        />
        <button onClick={handleAsk} disabled={busy}>{busy ? "..." : "Ask"}</button>
      </div>
    </div>
  );
};

export default HrPolicyAssistant;
