import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, Panel, Pivot, PivotItem, PrimaryButton, SearchBox, Spinner, TextField, Toggle } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { card, row, h1, th, td } from './ui';

interface Field { key: string; label: string; type?: 'text' | 'number' | 'select'; req?: boolean; from?: string; idKey?: string; labelKey?: string; options?: string[]; optional?: boolean; }
interface Cfg { title: string; one: string; idKey: string; fields: Field[]; }

const ROLES = ['Requestor', 'ReportingManager', 'DeptHead', 'DivHead', 'HRAD', 'Admin'];
const EMP = { from: 'employees', idKey: 'employeeId', labelKey: 'fullName' };
const CFG: { [k: string]: Cfg } = {
  items: { title: 'Items', one: 'item', idKey: 'itemId', fields: [
    { key: 'itemCode', label: 'Code', req: true }, { key: 'itemName', label: 'Name', req: true },
    { key: 'categoryId', label: 'Category', type: 'select', from: 'categories', idKey: 'categoryId', labelKey: 'categoryName', optional: true },
    { key: 'unit', label: 'Unit', req: true }, { key: 'rate', label: 'Rate', type: 'number' },
    { key: 'stockQty', label: 'Stock qty', type: 'number' }, { key: 'reorderLevel', label: 'Reorder level', type: 'number' }] },
  categories: { title: 'Categories', one: 'category', idKey: 'categoryId', fields: [{ key: 'categoryName', label: 'Category name', req: true }] },
  vendors: { title: 'Vendors', one: 'vendor', idKey: 'vendorId', fields: [
    { key: 'vendorName', label: 'Vendor name', req: true }, { key: 'contactPerson', label: 'Contact person' }, { key: 'email', label: 'Email', req: true },
    { key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address' }, { key: 'gstNo', label: 'GST no' }] },
  divisions: { title: 'Divisions', one: 'division', idKey: 'divisionId', fields: [
    { key: 'divisionName', label: 'Division name', req: true }, { key: 'divisionHeadId', label: 'Division head', type: 'select', ...EMP, optional: true }] },
  departments: { title: 'Departments', one: 'department', idKey: 'departmentId', fields: [
    { key: 'departmentName', label: 'Department name', req: true },
    { key: 'divisionId', label: 'Division', type: 'select', from: 'divisions', idKey: 'divisionId', labelKey: 'divisionName', req: true },
    { key: 'departmentHeadId', label: 'Department head', type: 'select', ...EMP, optional: true }] },
  employees: { title: 'Employees', one: 'employee', idKey: 'employeeId', fields: [
    { key: 'employeeCode', label: 'Code', req: true }, { key: 'fullName', label: 'Full name', req: true }, { key: 'email', label: 'Email (UPN)', req: true },
    { key: 'departmentId', label: 'Department', type: 'select', from: 'departments', idKey: 'departmentId', labelKey: 'departmentName', req: true },
    { key: 'divisionId', label: 'Division', type: 'select', from: 'divisions', idKey: 'divisionId', labelKey: 'divisionName', req: true },
    { key: 'reportingManagerId', label: 'Reporting manager', type: 'select', ...EMP, optional: true },
    { key: 'role', label: 'Role', type: 'select', options: ROLES, req: true }] }
};
const LOOKUPS = ['employees', 'divisions', 'departments', 'categories'];

/** Master data with complete CRUD: list + search, add, edit, activate/deactivate, delete (blocked by the API when in use). */
const Admin: React.FC<{ api: ApiService }> = ({ api }) => {
  const [tab, setTab] = useState('items');
  const [rows, setRows] = useState<any[]>([]);
  const [lk, setLk] = useState<{ [k: string]: any[] }>({});
  const [edit, setEdit] = useState<any>();
  const [q, setQ] = useState('');
  const [showInactive, setShowInactive] = useState(true);
  const [err, setErr] = useState<string>();
  const [ok, setOk] = useState<string>();
  const [busy, setBusy] = useState(false);
  const cfg = CFG[tab];

  const loadLookups = (): void => { LOOKUPS.forEach(k => api.get<any[]>('masters/' + k).then(d => setLk(p => ({ ...p, [k]: d }))).catch(() => undefined)); };
  const load = (): void => { setBusy(true); api.get<any[]>('masters/' + tab).then(setRows).catch((e: Error) => setErr(e.message)).then(() => setBusy(false)); };
  useEffect(() => { loadLookups(); }, []);
  useEffect(() => { setEdit(undefined); setQ(''); load(); }, [tab]);

  const label = (f: Field, v: any): string => {
    if (v === null || v === undefined || v === '') return '-';
    if (f.type !== 'select' || !f.from) return String(v);
    const hit = (lk[f.from] || []).filter(x => x[f.idKey!] === v)[0];
    return hit ? hit[f.labelKey!] : String(v);
  };

  const save = async (): Promise<void> => {
    const miss = cfg.fields.filter(f => f.req && (edit[f.key] === undefined || edit[f.key] === '' || edit[f.key] === null))[0];
    if (miss) { setErr(miss.label + ' is required'); return; }
    try {
      if (edit[cfg.idKey]) await api.put('masters/' + tab + '/' + edit[cfg.idKey], edit); else await api.post('masters/' + tab, edit);
      setOk(cfg.one + ' saved'); setEdit(undefined); setErr(undefined); load(); loadLookups();
    } catch (e) { setErr((e as Error).message); }
  };

  const toggleActive = async (r: any): Promise<void> => {
    try { await api.put('masters/' + tab + '/' + r[cfg.idKey], { ...r, isActive: !r.isActive }); load(); loadLookups(); } catch (e) { setErr((e as Error).message); }
  };

  const remove = async (r: any): Promise<void> => {
    if (!window.confirm('Delete this ' + cfg.one + ' permanently? If it is already used, deactivate it instead.')) return;
    try { await api.del('masters/' + tab + '/' + r[cfg.idKey]); setOk(cfg.one + ' deleted'); load(); loadLookups(); } catch (e) { setErr((e as Error).message); }
  };

  const shown = rows.filter(r => (showInactive || r.isActive) &&
    (!q || cfg.fields.some(f => label(f, r[f.key]).toLowerCase().indexOf(q.toLowerCase()) > -1)));

  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}>
      <h1 style={h1}>Master data</h1>
      <PrimaryButton text={'+ Add ' + cfg.one} onClick={() => { setErr(undefined); setEdit({ isActive: true, ...(tab === 'employees' ? { role: 'Requestor' } : {}) }); }} />
    </div>
    {err && !edit && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    {ok && <MessageBar messageBarType={MessageBarType.success} onDismiss={() => setOk(undefined)}>{ok}</MessageBar>}
    <div style={card}>
      <Pivot selectedKey={tab} onLinkClick={i => setTab(i!.props.itemKey!)}>
        {Object.keys(CFG).map(k => <PivotItem key={k} headerText={CFG[k].title} itemKey={k} />)}
      </Pivot>
      <div style={{ ...row(12), margin: '12px 0' }}>
        <SearchBox placeholder={'Search ' + cfg.title.toLowerCase()} value={q} onChange={(_, v) => setQ(v || '')} styles={{ root: { width: 260 } }} />
        <Toggle label="Show inactive" inlineLabel checked={showInactive} onChange={(_, c) => setShowInactive(!!c)} />
        <span style={{ color: '#5b6275', fontSize: 12 }}>{shown.length} of {rows.length}</span>
      </div>
      {busy ? <Spinner /> : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{cfg.fields.map(f => <th key={f.key} style={th}>{f.label}</th>)}<th style={th}>Active</th><th style={th} /></tr></thead>
            <tbody>
              {shown.length === 0 && <tr><td style={td} colSpan={cfg.fields.length + 2}>No records.</td></tr>}
              {shown.map(r => (
                <tr key={r[cfg.idKey]} style={{ opacity: r.isActive ? 1 : 0.5 }}>
                  {cfg.fields.map(f => <td key={f.key} style={td}>{label(f, r[f.key])}</td>)}
                  <td style={td}><Toggle checked={r.isActive} onChange={() => toggleActive(r)} ariaLabel="Active" /></td>
                  <td style={td}><div style={row(6)}>
                    <DefaultButton text="Edit" onClick={() => { setErr(undefined); setEdit({ ...r }); }} />
                    <DefaultButton text="Delete" styles={{ root: { color: '#dc2626' } }} onClick={() => remove(r)} /></div></td>
                </tr>))}
            </tbody>
          </table>
        </div>)}
    </div>
    <Panel isOpen={!!edit} onDismiss={() => setEdit(undefined)} headerText={edit && edit[cfg.idKey] ? 'Edit ' + cfg.one : 'Add ' + cfg.one} isFooterAtBottom
      onRenderFooterContent={() => (<div style={row(8)}><PrimaryButton text="Save" onClick={save} /><DefaultButton text="Cancel" onClick={() => setEdit(undefined)} /></div>)}>
      {edit && (<div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
        {cfg.fields.map(f => f.type === 'select' ? (
          <Dropdown key={f.key} label={f.label} required={f.req} selectedKey={edit[f.key] === null || edit[f.key] === undefined ? (f.options ? undefined : 0) : edit[f.key]}
            options={f.options ? f.options.map(o => ({ key: o, text: o }))
              : [{ key: 0, text: f.optional ? '(none)' : 'Select' }].concat((lk[f.from!] || []).filter(x => x.isActive !== false).map(x => ({ key: x[f.idKey!], text: x[f.labelKey!] })))}
            onChange={(_, o) => setEdit({ ...edit, [f.key]: f.options ? o!.key : (Number(o!.key) || null) })} />
        ) : (
          <TextField key={f.key} label={f.label} required={f.req} type={f.type === 'number' ? 'number' : 'text'} value={edit[f.key] === null || edit[f.key] === undefined ? '' : String(edit[f.key])}
            onChange={(_, v) => setEdit({ ...edit, [f.key]: f.type === 'number' ? Number(v) || 0 : v })} />
        ))}
        <Toggle label="Active" checked={!!edit.isActive} onChange={(_, c) => setEdit({ ...edit, isActive: !!c })} />
      </div>)}
    </Panel>
  </>);
};
export default Admin;
