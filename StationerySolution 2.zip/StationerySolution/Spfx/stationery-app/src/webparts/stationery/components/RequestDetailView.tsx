import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, PrimaryButton, Spinner, TextField } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { Me, RequestDetail, RouteName, Vendor } from '../models';
import { card, row, h1, h2, mut, th, td, fmt, fmtDate, C, STAGE } from './ui';
import StatusChip from './StatusChip';
import HradTools from './HradTools';
import CancelCard from './CancelCard';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; requestId: number; }

const RequestDetailView: React.FC<Props> = ({ api, me, go, requestId }) => {
  const [r, setR] = useState<RequestDetail>();
  const [err, setErr] = useState<string>();
  const [ok, setOk] = useState<string>();
  const [comment, setComment] = useState('');
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [vendorId, setVendorId] = useState<number>();
  const [hl, setHl] = useState<{ [id: number]: { approved: number; store: number } }>({});
  const [recv, setRecv] = useState<{ [id: number]: number }>({});
  const [busy, setBusy] = useState(false);

  const load = (): void => {
    api.get<RequestDetail>('requests/' + requestId).then(d => {
      setR(d);
      const h: any = {}, rc: any = {};
      d.items.forEach(i => {
        const appr = i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty;
        h[i.requestItemId] = { approved: appr, store: Math.min(appr, i.stockQty) };
        rc[i.requestItemId] = appr;
      });
      setHl(h); setRecv(rc);
    }).catch((e: Error) => setErr(e.message));
  };
  useEffect(() => { load(); }, [requestId]);
  useEffect(() => { if (me.roles.indexOf('HRAD') > -1) api.get<Vendor[]>('masters/vendors?active=true').then(setVendors); }, []);

  const run = async (fn: () => Promise<any>, msg: string): Promise<void> => {
    setErr(undefined); setOk(undefined); setBusy(true);
    try { await fn(); setOk(msg); setComment(''); load(); } catch (e) { setErr((e as Error).message); }
    setBusy(false);
  };

  if (!r) return err ? <MessageBar messageBarType={MessageBarType.error}>{err}</MessageBar> : <Spinner label="Loading request..." />;

  const mine = r.requestorEmail.toLowerCase() === me.email.toLowerCase();
  const myTurn = r.status === 'InReview' && (r.currentApproverEmail || '').toLowerCase() === me.email.toLowerCase();
  const isHrad = me.roles.indexOf('HRAD') > -1;
  const toOrder = r.items.reduce((s, i) => s + Math.max(0, (hl[i.requestItemId] ? hl[i.requestItemId].approved - hl[i.requestItemId].store : 0)), 0);

  return (<>
    <div style={{ ...row(), justifyContent: 'space-between' }}>
      <div style={row()}><DefaultButton text="< Back" onClick={() => go('list')} /><h1 style={h1}>{r.requestNo}</h1><StatusChip status={r.status} /></div>
      <div style={row(8)}>
        {(isHrad || mine) && r.poNumber && <DefaultButton text="Vendor PDF" onClick={() => api.download('hrad/' + r.requestId + '/pdf', r.poNumber + '.pdf')} />}
        {mine && (r.status === 'Draft' || r.status === 'AmendRequired') && <DefaultButton text="Edit" onClick={() => go('edit', r.requestId)} />}
        {mine && (r.status === 'Draft' || r.status === 'AmendRequired') && <PrimaryButton text={r.status === 'Draft' ? 'Submit' : 'Resubmit'} disabled={busy}
          onClick={() => run(() => api.post('requests/' + r.requestId + '/submit'), 'Submitted for approval')} />}
      </div>
    </div>
    {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    {ok && <MessageBar messageBarType={MessageBarType.success} onDismiss={() => setOk(undefined)}>{ok}</MessageBar>}

    <div style={{ ...row(14), alignItems: 'stretch' }}>
      <div style={{ ...card, flex: '2 1 460px', minWidth: 0 }}>
        <div style={{ ...row(24), marginBottom: 12, fontSize: 13 }}>
          <span><span style={mut}>Requestor </span><b>{r.requestorName}</b></span>
          <span><span style={mut}>Department </span><b>{r.departmentName}</b></span>
          <span><span style={mut}>Date </span><b>{fmtDate(r.requestDate)}</b></span>
          {r.vendorName && <span><span style={mut}>Vendor </span><b>{r.vendorName}</b></span>}
          {r.currentStage && <span><span style={mut}>With </span><b>{r.currentApproverName || STAGE[r.currentStage]}</b></span>}
        </div>
        {r.remarks && <div style={{ ...mut, marginBottom: 10 }}>Remarks: {r.remarks}</div>}
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead><tr>{['Item', 'Unit', 'Rate', 'Qty', 'Approved', 'From store', 'To vendor', 'Received', 'Total'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
            <tbody>{r.items.map(i => (
              <tr key={i.requestItemId}><td style={td}>{i.itemName}</td><td style={td}>{i.unit}</td><td style={td}>{fmt(i.rate)}</td><td style={td}>{i.quantity}</td>
                <td style={td}>{i.approvedQty === null || i.approvedQty === undefined ? '-' : i.approvedQty}</td><td style={td}>{i.issuedFromStockQty}</td><td style={td}>{i.orderedQty}</td>
                <td style={td}>{i.receivedQty}</td><td style={td}>{fmt(i.lineTotal)}</td></tr>))}</tbody>
          </table>
        </div>
        <div style={{ textAlign: 'right', marginTop: 12, fontSize: 18 }}><span style={mut}>Total </span><b>{fmt(r.totalAmount)}</b></div>
      </div>

      <div style={{ ...card, flex: '1 1 280px' }}>
        <h2 style={h2}>History</h2>
        {r.history.length === 0 && <span style={mut}>No activity yet</span>}
        {r.history.map((h, i) => (
          <div key={i} style={{ display: 'flex', gap: 12, paddingBottom: 14 }}>
            <div style={{ width: 12, height: 12, borderRadius: '50%', background: h.action === 'Reject' ? '#dc2626' : h.action === 'Amend' ? '#c2410c' : '#15803d', marginTop: 5, flex: 'none' }} />
            <div><b>{h.action}</b> <span style={mut}>({STAGE[h.stage] || h.stage})</span>
              <div style={mut}>{h.actorName} · {fmtDate(h.actionDate)}</div>
              {h.comments && <div style={{ fontStyle: 'italic', color: C.mut }}>&ldquo;{h.comments}&rdquo;</div>}</div>
          </div>))}
      </div>
    </div>

    {myTurn && (<div style={card}>
      <h2 style={h2}>Your decision &middot; {STAGE[r.currentStage || '']}</h2>
      <TextField multiline rows={3} placeholder="Comments (required for Reject / Ask to amend)" value={comment} onChange={(_, v) => setComment(v || '')} />
      <div style={{ ...row(8), marginTop: 10 }}>
        <PrimaryButton text="Approve" disabled={busy} onClick={() => run(() => api.post('requests/' + r.requestId + '/action', { action: 'Approve', comments: comment }), 'Approved')} />
        <DefaultButton text="Ask to amend" disabled={busy} onClick={() => run(() => api.post('requests/' + r.requestId + '/action', { action: 'Amend', comments: comment }), 'Sent back for amendment')} />
        <DefaultButton text="Reject" disabled={busy} styles={{ root: { color: '#dc2626' } }} onClick={() => run(() => api.post('requests/' + r.requestId + '/action', { action: 'Reject', comments: comment }), 'Rejected')} />
      </div></div>)}

    {isHrad && r.status === 'HRApproval' && (<div style={card}>
      <h2 style={h2}>HRAD processing</h2>
      <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr>{['Item', 'Requested', 'In store', 'Approved qty', 'Issue from store', 'To order'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
        <tbody>{r.items.map(i => { const v = hl[i.requestItemId] || { approved: 0, store: 0 }; return (
          <tr key={i.requestItemId}><td style={td}>{i.itemName}</td><td style={td}>{i.quantity}</td><td style={td}>{i.stockQty}</td>
            <td style={{ ...td, width: 120 }}><TextField type="number" value={String(v.approved)} onChange={(_, x) => setHl({ ...hl, [i.requestItemId]: { approved: Number(x) || 0, store: Math.min(v.store, Number(x) || 0) } })} /></td>
            <td style={{ ...td, width: 120 }}><TextField type="number" value={String(v.store)} onChange={(_, x) => setHl({ ...hl, [i.requestItemId]: { approved: v.approved, store: Number(x) || 0 } })} /></td>
            <td style={td}><b>{Math.max(0, v.approved - v.store)}</b></td></tr>); })}</tbody></table></div>
      <div style={{ ...row(12), marginTop: 12 }}>
        {toOrder > 0 && <Dropdown label="Vendor" placeholder="Select vendor" styles={{ root: { width: 280 } }} selectedKey={vendorId}
          options={vendors.map(v => ({ key: v.vendorId, text: v.vendorName }))} onChange={(_, o) => setVendorId(Number(o!.key))} />}
      </div>
      <TextField label="Comments" value={comment} onChange={(_, v) => setComment(v || '')} styles={{ root: { marginTop: 8 } }} />
      <div style={{ ...row(8), marginTop: 10 }}>
        <PrimaryButton disabled={busy || (toOrder > 0 && !vendorId)} text={toOrder > 0 ? 'Send to vendor (PDF + email)' : 'Issue from store and hand over'}
          onClick={() => run(() => api.post('hrad/' + r.requestId + '/process', { vendorId: vendorId, comments: comment,
            lines: r.items.map(i => ({ requestItemId: i.requestItemId, approvedQty: hl[i.requestItemId].approved, issuedFromStockQty: hl[i.requestItemId].store })) }), 'Request processed')} />
      </div></div>)}

    {isHrad && r.status === 'Ordered' && (<div style={card}>
      <h2 style={h2}>Vendor order sent to {r.vendorName}</h2>
      <PrimaryButton text="Mark delivered and hand over to requestor" disabled={busy} onClick={() => run(() => api.post('hrad/' + r.requestId + '/deliver'), 'Requestor notified')} />
    </div>)}

    {mine && r.status === 'Delivered' && (<div style={card}>
      <h2 style={h2}>Verify received items</h2>
      <div style={{ overflowX: 'auto' }}><table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead><tr>{['Item', 'Expected', 'Received'].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
        <tbody>{r.items.map(i => (<tr key={i.requestItemId}><td style={td}>{i.itemName}</td>
          <td style={td}>{i.approvedQty === null || i.approvedQty === undefined ? i.quantity : i.approvedQty}</td>
          <td style={{ ...td, width: 120 }}><TextField type="number" value={String(recv[i.requestItemId])} onChange={(_, x) => setRecv({ ...recv, [i.requestItemId]: Math.max(0, Number(x) || 0) })} /></td></tr>))}</tbody></table></div>
      <TextField label="Comments / query" multiline rows={2} value={comment} onChange={(_, v) => setComment(v || '')} styles={{ root: { marginTop: 8 } }} />
      <div style={{ ...row(8), marginTop: 10 }}>
        <PrimaryButton text="Confirm received (closes or partially closes)" disabled={busy}
          onClick={() => run(() => api.post('requests/' + r.requestId + '/receive', { comments: comment, lines: r.items.map(i => ({ requestItemId: i.requestItemId, receivedQty: recv[i.requestItemId] })) }), 'Delivery verified')} />
        <DefaultButton text="Raise query to HRAD" disabled={busy || !comment.trim()}
          onClick={() => run(() => api.post('requests/' + r.requestId + '/query', { text: comment }), 'Query sent to HRAD')} />
      </div></div>)}
    {isHrad && <HradTools api={api} r={r} onChanged={(m: string) => { setOk(m); setErr(undefined); load(); }} onError={(m: string) => setErr(m)} />}
    {(mine || me.roles.indexOf('Admin') > -1) && <CancelCard api={api} r={r} onChanged={(m: string) => { setOk(m); setErr(undefined); load(); }} onError={(m: string) => setErr(m)} />}
  </>);
};
export default RequestDetailView;
