import * as React from 'react';
import { useEffect, useState } from 'react';
import { DefaultButton, Dropdown, MessageBar, MessageBarType, PrimaryButton, Spinner, TextField } from '@fluentui/react';
import { ApiService } from '../services/ApiService';
import { FormLine, Item, Me, RequestDetail, RouteName } from '../models';
import { card, row, h1, h2, mut, th, td, fmt } from './ui';

interface Props { api: ApiService; me: Me; go: (n: RouteName, id?: number) => void; requestId?: number; }

const RequestForm: React.FC<Props> = ({ api, me, go, requestId }) => {
  const [items, setItems] = useState<Item[]>([]);
  const [lines, setLines] = useState<FormLine[]>([{ itemId: 0, quantity: 1 }]);
  const [remarks, setRemarks] = useState('');
  const [err, setErr] = useState<string>();
  const [busy, setBusy] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const p: Promise<any>[] = [api.get<Item[]>('masters/items?active=true').then(setItems)];
    if (requestId) p.push(api.get<RequestDetail>('requests/' + requestId).then(r => {
      setRemarks(r.remarks || ''); setLines(r.items.map(i => ({ itemId: i.itemId, quantity: i.quantity })));
    }));
    Promise.all(p).then(() => setReady(true)).catch((e: Error) => setErr(e.message));
  }, []);

  const find = (id: number): Item | undefined => items.filter(i => i.itemId === id)[0];
  const total = lines.reduce((s, l) => s + (find(l.itemId) ? find(l.itemId)!.rate * l.quantity : 0), 0);
  const upd = (idx: number, patch: Partial<FormLine>): void => setLines(lines.map((l, i) => i === idx ? { ...l, ...patch } : l));

  const setItem = (idx: number, itemId: number): void => {
    if (lines.some((l, i) => i !== idx && l.itemId === itemId)) { setErr('This item is already in the request'); return; }
    setErr(undefined); upd(idx, { itemId: itemId });
  };

  const save = async (submit: boolean): Promise<void> => {
    setErr(undefined);
    if (lines.length === 0 || lines.some(l => !l.itemId || !(l.quantity > 0))) { setErr('Select an item and enter a quantity greater than zero for every row'); return; }
    setBusy(true);
    try {
      const saved = await api.post<{ requestId: number }>('requests', { requestId: requestId, remarks: remarks, items: lines.map(l => ({ itemId: l.itemId, quantity: l.quantity })) });
      if (submit) await api.post('requests/' + saved.requestId + '/submit');
      go('detail', saved.requestId);
    } catch (e) { setErr((e as Error).message); setBusy(false); }
  };

  if (!ready && !err) return <Spinner label="Loading..." />;
  return (<>
    <h1 style={h1}>{requestId ? 'Edit request' : 'New stationery request'}</h1>
    {err && <MessageBar messageBarType={MessageBarType.error} onDismiss={() => setErr(undefined)}>{err}</MessageBar>}
    <div style={card}>
      <h2 style={h2}>Requestor details</h2>
      <div style={row(14)}>
        {[['Requestor', me.fullName], ['Department', me.departmentName], ['Division', me.divisionName], ['Reporting manager', me.reportingManagerName || '-'], ['Date', new Date().toLocaleDateString('en-GB')]].map(f => (
          <TextField key={f[0]} label={f[0]} value={f[1]} readOnly styles={{ root: { width: 180 } }} />))}
      </div>
      <TextField label="Remarks" multiline rows={2} value={remarks} onChange={(_, v) => setRemarks(v || '')} styles={{ root: { marginTop: 10 } }} />
    </div>
    <div style={card}>
      <h2 style={h2}>Items</h2>
      <div style={{ overflowX: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead><tr>{['#', 'Item', 'Unit', 'Rate', 'Qty', 'Total', ''].map(h => <th key={h} style={th}>{h}</th>)}</tr></thead>
          <tbody>{lines.map((l, i) => { const it = find(l.itemId); return (
            <tr key={i}>
              <td style={td}>{i + 1}</td>
              <td style={{ ...td, minWidth: 280 }}>
                <Dropdown selectedKey={l.itemId || undefined} placeholder="Select item"
                  options={items.map(x => ({ key: x.itemId, text: x.itemCode + ' - ' + x.itemName }))} onChange={(_, o) => setItem(i, Number(o!.key))} />
              </td>
              <td style={td}>{it ? it.unit : ''}</td>
              <td style={td}>{it ? fmt(it.rate) : ''}</td>
              <td style={{ ...td, width: 100 }}>
                <TextField type="number" min={1} value={String(l.quantity)} onChange={(_, v) => upd(i, { quantity: Math.max(0, Number(v) || 0) })} />
              </td>
              <td style={td}><b>{it ? fmt(it.rate * l.quantity) : ''}</b></td>
              <td style={td}><DefaultButton text="Remove" onClick={() => setLines(lines.length > 1 ? lines.filter((_, x) => x !== i) : [{ itemId: 0, quantity: 1 }])} /></td>
            </tr>); })}</tbody>
        </table>
      </div>
      <div style={{ ...row(), justifyContent: 'space-between', marginTop: 14 }}>
        <DefaultButton text="+ Add item" onClick={() => setLines([...lines, { itemId: 0, quantity: 1 }])} />
        <div style={{ fontSize: 18 }}><span style={mut}>Grand total </span><b>{fmt(total)}</b></div>
      </div>
    </div>
    <div style={row(8)}>
      <DefaultButton text="Save as draft" disabled={busy} onClick={() => save(false)} />
      <PrimaryButton text="Submit for approval" disabled={busy} onClick={() => save(true)} />
      <DefaultButton text="Cancel" onClick={() => go('list')} />
    </div>
  </>);
};
export default RequestForm;
