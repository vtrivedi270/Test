import { AadHttpClient } from '@microsoft/sp-http';
import { WebPartContext } from '@microsoft/sp-webpart-base';

export class ApiError extends Error {
  public status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
    (Object as any).setPrototypeOf(this, ApiError.prototype);
  }
}

export interface LoginResult {
  token: string;
  expiresAt: string;
  user: { employeeId: number; fullName: string; email: string; roles: string[] };
}

/**
 * API client with JWT role-based access.
 *
 *  1. login():  production  -> Azure AD token via AadHttpClient is sent to POST /auth/login, API returns the app JWT (with role claims)
 *               local dev   -> (apiResource empty) POST /auth/dev-login { email } using the SharePoint user e-mail
 *  2. Every call then sends  Authorization: Bearer <app JWT>.  The token is cached in memory, refreshed before expiry,
 *     and re-requested once automatically on a 401.
 */
export class ApiService {
  public roles: string[] = [];
  private token?: string;
  private expires = 0;
  private aad?: AadHttpClient;
  private loginPromise?: Promise<LoginResult>;

  constructor(private ctx: WebPartContext, private base: string, private resource: string) {}

  private url(path: string): string { return this.base.replace(/\/$/, '') + '/' + path; }

  public hasRole(role: string): boolean { return this.roles.indexOf(role) > -1; }

  public login(): Promise<LoginResult> {
    if (!this.loginPromise) {
      this.loginPromise = this.doLogin().then(r => { this.loginPromise = undefined; return r; },
        e => { this.loginPromise = undefined; throw e; });
    }
    return this.loginPromise;
  }

  private async doLogin(): Promise<LoginResult> {
    let res: Response;
    if (this.resource) {
      if (!this.aad) this.aad = await this.ctx.aadHttpClientFactory.getClient(this.resource);
      res = (await this.aad.post(this.url('auth/login'), AadHttpClient.configurations.v1,
        { headers: { 'Content-Type': 'application/json' }, body: '{}' })) as any;
    } else {
      res = await fetch(this.url('auth/dev-login'), {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: this.ctx.pageContext.user.email })
      });
    }
    if (!res.ok) throw new ApiError(await this.message(res), res.status);
    const r = (await res.json()) as LoginResult;
    this.token = r.token; this.expires = new Date(r.expiresAt).getTime(); this.roles = r.user.roles;
    return r;
  }

  private async message(res: Response): Promise<string> {
    let msg = 'Request failed (' + res.status + ')';
    if (res.status === 401) msg = 'Your session expired or you are not signed in.';
    if (res.status === 403) msg = 'You do not have permission to do this.';
    try { const e = await res.json(); if (e && e.error) msg = e.error; } catch (x) { /* no body */ }
    return msg;
  }

  private async raw(method: string, path: string, body?: any, retry: boolean = true): Promise<Response> {
    if (!this.token || Date.now() > this.expires - 60000) await this.login();
    const init: any = { method: method, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + this.token } };
    if (body !== undefined) init.body = JSON.stringify(body);
    const res = await fetch(this.url(path), init);
    if (res.status === 401 && retry) { this.token = undefined; return this.raw(method, path, body, false); }
    return res;
  }

  private async req<T>(method: string, path: string, body?: any): Promise<T> {
    const res = await this.raw(method, path, body);
    if (!res.ok) throw new ApiError(await this.message(res), res.status);
    const ct = res.headers.get('content-type') || '';
    return (ct.indexOf('json') > -1 ? await res.json() : undefined) as T;
  }

  public get<T>(path: string): Promise<T> { return this.req<T>('GET', path); }
  public post<T>(path: string, body?: any): Promise<T> { return this.req<T>('POST', path, body === undefined ? {} : body); }
  public put<T>(path: string, body: any): Promise<T> { return this.req<T>('PUT', path, body); }
  public del<T>(path: string): Promise<T> { return this.req<T>('DELETE', path); }

  public async download(path: string, fileName: string): Promise<void> {
    const res = await this.raw('GET', path);
    if (!res.ok) throw new ApiError(await this.message(res), res.status);
    const blob = await res.blob();
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = fileName;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(a.href);
  }
}
