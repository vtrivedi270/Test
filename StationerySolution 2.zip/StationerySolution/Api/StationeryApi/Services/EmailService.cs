using System.Net;
using System.Net.Mail;
using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class EmailService(AppDbContext db, IConfiguration cfg, ILogger<EmailService> log)
{
    public async Task QueueAsync(int? requestId, string to, string subject, string body, byte[]? pdf = null, string? pdfName = null)
    {
        var m = new EmailLog { RequestId = requestId, ToEmail = to, Subject = subject, Body = body };
        db.EmailLogs.Add(m);
        await db.SaveChangesAsync();
        var host = cfg["Smtp:Host"];
        if (string.IsNullOrWhiteSpace(host)) return;           // stays Pending; a worker can retry later
        try
        {
            using var c = new SmtpClient(host, cfg.GetValue("Smtp:Port", 587)) { EnableSsl = true, Credentials = new NetworkCredential(cfg["Smtp:User"], cfg["Smtp:Password"]) };
            using var msg = new MailMessage(cfg["Smtp:From"]!, to, subject, body);
            if (pdf != null) msg.Attachments.Add(new Attachment(new MemoryStream(pdf), pdfName ?? "PO.pdf", "application/pdf"));
            await c.SendMailAsync(msg);
            m.Status = "Sent"; m.SentAt = DateTime.UtcNow;
        }
        catch (Exception ex)
        {
            m.Status = "Failed"; m.ErrorMessage = ex.Message; m.RetryCount++;
            log.LogError(ex, "Mail failed");
        }
        await db.SaveChangesAsync();
    }
}
