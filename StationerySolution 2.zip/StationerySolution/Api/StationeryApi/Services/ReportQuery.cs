using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public static class ReportQuery
{
    /// <summary>Requests counted in cost reports (not Draft/Rejected), scoped by role and filters.</summary>
    public static IQueryable<RequestHeader> Scope(AppDbContext db, Employee me, DateTime? from, DateTime? to, int? deptId)
    {
        var q = db.RequestHeaders.Where(x => x.Status != "Draft" && x.Status != "Rejected");
        if (me.Role is not ("HRAD" or "Admin")) q = q.Where(x => x.DepartmentId == me.DepartmentId);
        if (from != null) q = q.Where(x => x.RequestDate >= from);
        if (to != null) q = q.Where(x => x.RequestDate <= to);
        if (deptId != null) q = q.Where(x => x.DepartmentId == deptId);
        return q;
    }
}
