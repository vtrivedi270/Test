using StationeryApi.Data;
using StationeryApi.Models;
namespace StationeryApi.Services;

public static class AuditExtensions
{
    /// <summary>Queue an AuditLog row (saved with the next SaveChanges).</summary>
    public static void Audit(this AppDbContext db, string entity, string id, string action, string? oldValue, string? newValue, string user) =>
        db.AuditLogs.Add(new AuditLog { EntityName = entity, EntityId = id, Action = action, OldValue = oldValue, NewValue = newValue, UserEmail = user });
}
