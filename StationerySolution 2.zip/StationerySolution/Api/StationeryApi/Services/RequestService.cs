using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class RequestService(AppDbContext db)
{
    public async Task<RequestHeader> SaveAsync(RequestSaveDto dto, Employee me)
    {
        if (dto.Items == null || dto.Items.Count == 0) throw new InvalidOperationException("Add at least one item");
        if (dto.Items.Any(i => i.Quantity <= 0)) throw new InvalidOperationException("Quantity must be greater than zero");
        var ids = dto.Items.Select(i => i.ItemId).ToList();
        if (ids.Count != ids.Distinct().Count()) throw new InvalidOperationException("Duplicate item in request");
        var items = await db.Items.Where(i => ids.Contains(i.ItemId) && i.IsActive).ToDictionaryAsync(i => i.ItemId);
        if (items.Count != ids.Count) throw new InvalidOperationException("Invalid or inactive item");

        RequestHeader h;
        if (dto.RequestId is null)
        {
            var no = new SqlParameter("@RequestNo", System.Data.SqlDbType.NVarChar, 30) { Direction = System.Data.ParameterDirection.Output };
            await db.Database.ExecuteSqlRawAsync("EXEC dbo.usp_NextRequestNo @RequestNo OUTPUT", no);
            h = new RequestHeader { RequestNo = (string)no.Value, RequestorId = me.EmployeeId, DepartmentId = me.DepartmentId, DivisionId = me.DivisionId, Status = "Draft" };
            db.RequestHeaders.Add(h);
        }
        else
        {
            h = await db.RequestHeaders.Include(x => x.Items).FirstOrDefaultAsync(x => x.RequestId == dto.RequestId)
                ?? throw new InvalidOperationException("Request not found");
            if (h.RequestorId != me.EmployeeId) throw new UnauthorizedAccessException();
            if (h.Status is not ("Draft" or "AmendRequired")) throw new InvalidOperationException("Request is not editable");
            db.RequestItems.RemoveRange(h.Items);
            await db.SaveChangesAsync();                       // delete first (unique RequestId+ItemId)
            h.Items.Clear();
        }
        h.Remarks = dto.Remarks;
        foreach (var i in dto.Items)
            h.Items.Add(new RequestItem { ItemId = i.ItemId, Quantity = i.Quantity, Rate = items[i.ItemId].Rate, Unit = items[i.ItemId].Unit, Remarks = i.Remarks });
        h.TotalAmount = h.Items.Sum(x => x.Quantity * x.Rate);
        await db.SaveChangesAsync();
        return h;
    }
}
