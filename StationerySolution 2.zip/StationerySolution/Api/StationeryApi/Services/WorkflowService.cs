using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
namespace StationeryApi.Services;

public class WorkflowService(AppDbContext db, EmailService mail)
{
    /// <summary>Next approval stage after <paramref name="after"/>, skipping empty levels and the requestor. HRAD when done.</summary>
    public async Task<(string Stage, int? ApproverId)> NextStageAsync(RequestHeader h, string? after)
    {
        var req = await db.Employees.FindAsync(h.RequestorId);
        var dept = await db.Departments.FindAsync(h.DepartmentId);
        var div = await db.Divisions.FindAsync(h.DivisionId);
        var chain = new List<(string Stage, int? Id)> {
            ("ReportingManager", req!.ReportingManagerId),
            ("DeptHead", dept!.DepartmentHeadId),
            ("DivHead", div!.DivisionHeadId) };
        int start = after == null ? 0 : chain.FindIndex(c => c.Stage == after) + 1;
        for (int i = start; i < chain.Count; i++)
        {
            var (stage, id) = chain[i];
            if (id != null && id != h.RequestorId && !chain.Take(i).Any(c => c.Id == id)) return (stage, id);
        }
        return ("HRAD", null);
    }

    private static void Move(RequestHeader h, string stage, int? approver)
    {
        h.CurrentStage = stage; h.CurrentApproverId = approver;
        h.Status = stage == "HRAD" ? "HRApproval" : "InReview";
    }

    public void AddHistory(RequestHeader h, string stage, string action, Employee actor, string? comments) =>
        db.ApprovalHistories.Add(new ApprovalHistory { RequestId = h.RequestId, Stage = stage, Action = action, ActorId = actor.EmployeeId, Comments = comments });

    public async Task SubmitAsync(RequestHeader h, Employee actor)
    {
        if (h.RequestorId != actor.EmployeeId) throw new UnauthorizedAccessException("Only the requestor can submit");
        if (h.Status is not ("Draft" or "AmendRequired")) throw new InvalidOperationException("Request cannot be submitted in its current status");
        await db.Entry(h).Collection(x => x.Items).LoadAsync();
        if (h.Items.Count == 0) throw new InvalidOperationException("Add at least one item");
        var again = h.Status == "AmendRequired";
        var (stage, id) = await NextStageAsync(h, null);
        h.SubmittedAt = DateTime.UtcNow;
        Move(h, stage, id);
        AddHistory(h, "Requestor", again ? "Resubmit" : "Submit", actor, null);
        await db.SaveChangesAsync();
        await NotifyAsync(h, "Pending your action");
    }

    public async Task ActAsync(RequestHeader h, Employee actor, ActionDto dto)
    {
        if (h.Status != "InReview" || h.CurrentApproverId != actor.EmployeeId) throw new UnauthorizedAccessException("This request is not pending with you");
        if (dto.Action != "Approve" && string.IsNullOrWhiteSpace(dto.Comments)) throw new InvalidOperationException("Comment is mandatory for Reject / Amend");
        var stage = h.CurrentStage!;
        switch (dto.Action)
        {
            case "Approve": var (next, id) = await NextStageAsync(h, stage); Move(h, next, id); break;
            case "Reject": h.Status = "Rejected"; h.CurrentStage = null; h.CurrentApproverId = null; h.ClosedAt = DateTime.UtcNow; break;
            case "Amend": h.Status = "AmendRequired"; h.CurrentStage = "Requestor"; h.CurrentApproverId = h.RequestorId; break;
            default: throw new InvalidOperationException("Invalid action");
        }
        AddHistory(h, stage, dto.Action, actor, dto.Comments);
        await db.SaveChangesAsync();
        await NotifyAsync(h, dto.Action == "Approve" ? "Approved at " + stage : dto.Action, true);
    }

    public async Task NotifyAsync(RequestHeader h, string subject, bool toRequestor = false)
    {
        var to = new List<string>();
        if (h.Status == "InReview" && h.CurrentApproverId != null)
        { var a = await db.Employees.FindAsync(h.CurrentApproverId); if (a != null) to.Add(a.Email); }
        if (h.Status == "HRApproval")
            to.AddRange(await db.Employees.Where(e => e.Role == "HRAD" && e.IsActive).Select(e => e.Email).ToListAsync());
        if (toRequestor)
        { var r = await db.Employees.FindAsync(h.RequestorId); if (r != null) to.Add(r.Email); }
        foreach (var e in to.Distinct())
            await mail.QueueAsync(h.RequestId, e, $"[Stationery] {h.RequestNo}: {subject}", $"Request {h.RequestNo} - {subject}. Current status: {h.Status}.");
    }
}
