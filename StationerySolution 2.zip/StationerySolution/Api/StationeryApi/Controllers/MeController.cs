using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[Authorize, ApiController, Route("api/me")]
public class MeController(AppDbContext db, CurrentUser user) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var me = await user.GetAsync();
        var e = await db.Employees.AsNoTracking().Include(x => x.Department).Include(x => x.Division).Include(x => x.ReportingManager)
            .FirstAsync(x => x.EmployeeId == me.EmployeeId);
        return Ok(new
        {
            e.EmployeeId, e.FullName, e.Email, e.Role, Roles = User.FindAll("role").Select(c => c.Value).ToArray(),
            DepartmentName = e.Department?.DepartmentName, DivisionName = e.Division?.DivisionName,
            ReportingManagerName = e.ReportingManager?.FullName
        });
    }
}
