using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Dtos;
using StationeryApi.Models;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

/// <summary>Store stock: view, stock-in (receipt) and corrections (adjustment). HRAD and Admin only.</summary>
[Authorize(Roles = "HRAD,Admin"), ApiController, Route("api/stock")]
public class StockController(AppDbContext db, CurrentUser user) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> List() =>
        Ok(await db.Items.AsNoTracking().OrderBy(i => i.ItemName)
            .Select(i => new { i.ItemId, i.ItemCode, i.ItemName, i.Unit, i.Rate, i.StockQty, i.ReorderLevel, i.IsActive, isLow = i.StockQty <= i.ReorderLevel }).ToListAsync());

    [HttpGet("{itemId:int}/history")]
    public async Task<IActionResult> History(int itemId) =>
        Ok(await db.StockTransactions.AsNoTracking().Where(t => t.ItemId == itemId).OrderByDescending(t => t.TxnDate).Take(50)
            .Select(t => new { t.TxnDate, t.TxnType, t.Quantity, t.Note, t.CreatedBy,
                RequestNo = t.RequestId == null ? null : db.RequestHeaders.Where(r => r.RequestId == t.RequestId).Select(r => r.RequestNo).FirstOrDefault() }).ToListAsync());

    [HttpPost("receipt")]
    public async Task<IActionResult> Receipt(StockReceiptDto dto)
    {
        if (dto.Quantity <= 0) throw new InvalidOperationException("Quantity must be greater than zero");
        var item = await db.Items.FindAsync(dto.ItemId) ?? throw new InvalidOperationException("Item not found");
        var me = await user.GetAsync();
        item.StockQty += dto.Quantity;
        db.StockTransactions.Add(new StockTransaction { ItemId = item.ItemId, TxnType = "Receipt", Quantity = dto.Quantity, Note = dto.Note, CreatedBy = me.Email });
        db.Audit("Stock", item.ItemId.ToString(), "Receipt", null, $"+{dto.Quantity} {dto.Note}", me.Email);
        await db.SaveChangesAsync();
        return Ok(new { item.ItemId, item.StockQty });
    }

    [HttpPost("adjust")]
    public async Task<IActionResult> Adjust(StockAdjustDto dto)
    {
        if (dto.NewQty < 0) throw new InvalidOperationException("Stock cannot be negative");
        if (string.IsNullOrWhiteSpace(dto.Reason)) throw new InvalidOperationException("Reason is required for an adjustment");
        var item = await db.Items.FindAsync(dto.ItemId) ?? throw new InvalidOperationException("Item not found");
        var me = await user.GetAsync();
        var delta = dto.NewQty - item.StockQty;
        if (delta == 0) return Ok(new { item.ItemId, item.StockQty });
        db.StockTransactions.Add(new StockTransaction { ItemId = item.ItemId, TxnType = "Adjustment", Quantity = delta, Note = dto.Reason, CreatedBy = me.Email });
        db.Audit("Stock", item.ItemId.ToString(), "Adjust", item.StockQty.ToString("0.##"), dto.NewQty.ToString("0.##") + " - " + dto.Reason, me.Email);
        item.StockQty = dto.NewQty;
        await db.SaveChangesAsync();
        return Ok(new { item.ItemId, item.StockQty });
    }
}
