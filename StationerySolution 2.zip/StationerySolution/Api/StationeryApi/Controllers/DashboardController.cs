using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StationeryApi.Data;
using StationeryApi.Services;
namespace StationeryApi.Controllers;

[Authorize, ApiController, Route("api/dashboard")]
public class DashboardController(AppDbContext db, CurrentUser user) : ControllerBase
{
    [HttpGet("summary")]
    public async Task<IActionResult> Summary(DateTime? from, DateTime? to, int? deptId)
    {
        var me = await user.GetAsync();
        var q = ReportQuery.Scope(db, me, from, to, deptId);
        var pending = await db.RequestHeaders.CountAsync(x => me.Role == "HRAD"
            ? (x.Status == "HRApproval" || x.Status == "Ordered")
            : (x.Status == "InReview" && x.CurrentApproverId == me.EmployeeId));
        return Ok(new
        {
            totalRequests = await q.CountAsync(),
            pending,
            totalCost = await q.SumAsync(x => (decimal?)x.TotalAmount) ?? 0,
            lowStock = await db.Items.CountAsync(i => i.IsActive && i.StockQty <= i.ReorderLevel)
        });
    }

    [HttpGet("monthly")]
    public async Task<IActionResult> Monthly(DateTime? from, DateTime? to, int? deptId)
    {
        var me = await user.GetAsync();
        var raw = await ReportQuery.Scope(db, me, from, to, deptId)
            .GroupBy(x => new { x.RequestDate.Year, x.RequestDate.Month })
            .Select(g => new { g.Key.Year, g.Key.Month, Requests = g.Count(), TotalCost = g.Sum(x => x.TotalAmount) })
            .OrderBy(x => x.Year).ThenBy(x => x.Month).ToListAsync();
        return Ok(raw.Select(x => new { month = $"{x.Year}-{x.Month:00}", x.Requests, x.TotalCost }));
    }

    [HttpGet("by-department")]
    public async Task<IActionResult> ByDepartment(DateTime? from, DateTime? to, int? deptId)
    {
        var me = await user.GetAsync();
        return Ok(await ReportQuery.Scope(db, me, from, to, deptId)
            .GroupBy(x => x.Department!.DepartmentName)
            .Select(g => new { departmentName = g.Key, requests = g.Count(), totalCost = g.Sum(x => x.TotalAmount) })
            .OrderByDescending(x => x.totalCost).ToListAsync());
    }

    [HttpGet("by-item")]
    public async Task<IActionResult> ByItem(DateTime? from, DateTime? to, int? deptId, int top = 10)
    {
        var me = await user.GetAsync();
        var ids = ReportQuery.Scope(db, me, from, to, deptId).Select(x => x.RequestId);
        return Ok(await db.RequestItems.Where(i => ids.Contains(i.RequestId))
            .GroupBy(i => i.Item.ItemName)
            .Select(g => new { itemName = g.Key, qty = g.Sum(i => i.Quantity), totalCost = g.Sum(i => i.Quantity * i.Rate) })
            .OrderByDescending(x => x.totalCost).Take(top).ToListAsync());
    }

    [HttpGet("store")]
    public async Task<IActionResult> Store() =>
        Ok(await db.Items.AsNoTracking().Where(i => i.IsActive).OrderBy(i => i.ItemName)
            .Select(i => new { i.ItemId, i.ItemName, i.Unit, i.StockQty, i.ReorderLevel, isLow = i.StockQty <= i.ReorderLevel }).ToListAsync());
}
