namespace StationeryApi.Dtos;

public record RequestItemDto(int ItemId, decimal Quantity, string? Remarks);
public record RequestSaveDto(int? RequestId, string? Remarks, List<RequestItemDto> Items);
public record ActionDto(string Action, string? Comments);
public record HradLineDto(int RequestItemId, decimal ApprovedQty, decimal IssuedFromStockQty);
public record HradProcessDto(int? VendorId, List<HradLineDto> Lines, string? Comments);
public record ReceiveLineDto(int RequestItemId, decimal ReceivedQty);
public record ReceiveDto(List<ReceiveLineDto> Lines, string? Comments);
public record QueryDto(string Text);
public record DevLoginDto(string Email);
public record HradEditDto(List<RequestItemDto> Items, string Reason);
public record ReorderDto(int VendorId, string? Comments);
public record StockReceiptDto(int ItemId, decimal Quantity, string? Note);
public record StockAdjustDto(int ItemId, decimal NewQty, string Reason);

public class ListFilter
{
    public string? View { get; set; }          // mine | pending | all
    public string? Status { get; set; }
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    public int? DeptId { get; set; }
    public string? Search { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 20;
}
