#!/bin/bash
# Run this after unzipping to restore the original .js filenames.
# Gmail blocks .js attachments, so they were renamed to .js.txt before zipping.

cd "$(dirname "$0")"
mv Frontend/vite.config.js.txt Frontend/vite.config.js
mv Frontend/src/i18n.js.txt Frontend/src/i18n.js
mv Frontend/src/api.js.txt Frontend/src/api.js

echo "Done. .js files restored."
