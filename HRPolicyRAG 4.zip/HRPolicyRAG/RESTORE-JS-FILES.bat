@echo off
REM Run this after unzipping to restore the original .js filenames.
REM Gmail blocks .js attachments, so they were renamed to .js.txt before zipping.

cd Frontend
ren vite.config.js.txt vite.config.js
cd src
ren i18n.js.txt i18n.js
ren api.js.txt api.js
cd ..\..

echo Done. .js files restored.
pause
